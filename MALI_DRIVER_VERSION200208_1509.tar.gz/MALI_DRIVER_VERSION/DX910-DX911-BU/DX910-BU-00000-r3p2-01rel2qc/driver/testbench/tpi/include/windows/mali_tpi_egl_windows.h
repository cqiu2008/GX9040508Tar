/*
 * $Copyright:
 * ----------------------------------------------------------------------------
 *  This confidential and proprietary software may be used only as authorized
 *  by a licensing agreement from ARM Limited.
 *          (C) COPYRIGHT 2009-2010, 2012-2013 ARM Limited , ALL RIGHTS RESERVED
 *  The entire notice above must be reproduced on all authorized copies and
 *  copies may only be made to the extent permitted by a licensing agreement
 *  from ARM Limited.
 * ----------------------------------------------------------------------------
 * $
 */
#ifndef _MALI_TPI_EGL_H_
#define _MALI_TPI_EGL_H_

#include "tpi/include/common/mali_tpi_egl_internal.h"

#endif /* End (_MALI_TPI_EGL_H_) */
