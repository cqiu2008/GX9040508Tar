/*
 * $Copyright:
 * ----------------------------------------------------------------------------
 *  This confidential and proprietary software may be used only as authorized
 *  by a licensing agreement from ARM Limited.
 *          (C) COPYRIGHT 2011-2013 ARM Limited , ALL RIGHTS RESERVED
 *  The entire notice above must be reproduced on all authorized copies and
 *  copies may only be made to the extent permitted by a licensing agreement
 *  from ARM Limited.
 * ----------------------------------------------------------------------------
 * $
 */
#ifndef _MALI_TPI_EGL_ANDROID_H_
#define _MALI_TPI_EGL_ANDROID_H_

#endif /* End (_MALI_TPI_EGL_ANDROID_H_) */
