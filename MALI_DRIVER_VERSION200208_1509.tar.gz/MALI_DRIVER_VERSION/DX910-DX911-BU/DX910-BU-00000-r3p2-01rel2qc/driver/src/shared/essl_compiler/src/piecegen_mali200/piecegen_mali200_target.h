/*
 * This confidential and proprietary software may be used only as
 * authorised by a licensing agreement from ARM Limited
 * (C) COPYRIGHT 2006-2010, 2013 ARM Limited
 * ALL RIGHTS RESERVED
 * The entire notice above must be reproduced on all authorised
 * copies and copies may only be made to the extent permitted
 * by a licensing agreement from ARM Limited.
 */

#ifndef PIECEGEN_MALI200_TARGET_H
#define PIECEGEN_MALI200_TARGET_H

#include "common/essl_target.h"
#include "common/essl_mem.h"

/*@null@*/ target_descriptor *_essl_piecegen_mali200_new_target_descriptor(mempool *pool, target_kind kind);


#endif /* PIECEGEN_MALI200_TARGET_H */
