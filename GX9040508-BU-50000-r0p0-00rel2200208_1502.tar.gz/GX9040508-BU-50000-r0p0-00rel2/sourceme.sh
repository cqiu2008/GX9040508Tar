export MALI_HOME=`pwd`
export MALI_TESTBENCH_PATH="$MALI_HOME/testbench/mali_toplevel/verilog"
# Select one of: vcs modelsim ncsim
export MALI_SIMULATOR=vcs
export VCS_HOME=/edatools/synopsys/vcs-mx_vO-2018.09-SP2/vcs-mx/O-2018.09-SP2

