/*----------------------------------------------------------------------------
*
*The confidential and proprietary information contained in this file may
*only be used by a person authorised under and to the extent permitted
*by a subsisting licensing agreement from ARM Limited.
*
*        (C) COPYRIGHT 2008-2009,2012 ARM Limited.
*             ALL RIGHTS RESERVED
*
*This entire notice must be reproduced on all copies of this file
*and copies of this file may only be made by a person if such person is
*permitted to do so under the terms of a subsisting license agreement
*from ARM Limited.
*Modified  : $Date: 2007-10-22 14:10:23 +0200 (Mon, 22 Oct 2007) $
*Revision  : $Revision: 68554 $
*Release   : $State: $
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Abstract :Implementaion of all functions that are used to access MALI
*-----------------------------------------------------------------------------
* Overview
*----------
*
**************************************************************/

#include "MaliFns.h"
#include <stdio.h>

int *Mali_Address(int unit,int core);

void Mali_Reset(void)
{
  /* Reset Mali GP */
  /*  Mali_WrRegAll(0,MALI_GP_REG_INT_CLEAR,0x1FFF); */
  Mali_WrRegAll(0,MALI_GP_REG_CMD,0x400);

  /* Reset Mali PPs */
  /*  Mali_WrRegAll(1,MALI_PP_REG_MGMT_INT_CLEAR,0x1F); */
  Mali_WrRegAll(1,MALI_PP_REG_MGMT_CTRL,0x80);

  /* Reset L2s */
  Mali_WrRegAll(3,0x10,1);  /* L2 Flushed */
  Mali_WrRegAll(3,0x1C,3);  /* L2 enabled */

  /* Reset MMUs */
  Mali_WrRegAll(2,MALI_MMU_REG_CMD_REG,2); /* stall MMU */
  Mali_WrRegAll(2,MALI_MMU_REG_CMD_REG,6); /* soft-reset MMU */
  Mali_WrRegAll(2,MALI_MMU_REG_CMD_REG,3); /* out of stall mode MMU */
  Mali_WrRegAll(2,MALI_MMU_REG_IRQ_CLEAR,0x0);
};


void Mali_DisplayConf(void)
{
  unsigned int v;
  unsigned int number_of_pps;

  printf ("Mali-450 configuration:\n");
  // Enable all PPs and check which bits of the register stay high. */
  Mali_WrReg(5,0,0x0,0xFF);
  v = Mali_RdReg(5,0,0x0);

  switch (v) {
    case 0x03  : number_of_pps = 2; break;
    case 0x0f  : number_of_pps = 4; break;
    case 0x77  : number_of_pps = 6; break;
    case 0xff  : number_of_pps = 8; break;
    default    : number_of_pps = 0;
  };
  if (number_of_pps != 0)
    printf ("  Number of PPs : %d\n",number_of_pps);
  else
    printf ("  Number of PPs unsupported.\n");

  v = ((Mali_RdReg(3,0,0x4) >> 16) & 0xff);
  printf ("  Size of L2C0  : %d KB\n", 1<<(v-10));

  v = ((Mali_RdReg(3,1,0x4) >> 16) & 0xff);
  printf ("  Size of L2C1  : %d KB\n", 1<<(v-10));

  if (L2_CORES > 2) {
    v = ((Mali_RdReg(3,2,0x4) >> 16) & 0xff);
    printf ("  Size of L2C2  : %d KB\n", 1<<(v-10));
  }
}


void *Mali_LdMem(void *srcptr,int size,int ttb_base) {
  /* Setup MMU to point to data structures for this image */
  Mali_WrRegAll(2,0x8,2); /* stall MMU  */
  Mali_WrRegAll(2,0x0,ttb_base);
  Mali_WrRegAll(2,0x8,4); /* clear MMU  */
  Mali_WrRegAll(2,0x1C,3); /* enable interrupts */
  Mali_WrRegAll(2,0x8,0); /* enable mmu paging */
  Mali_WrRegAll(2,0x8,3); /* un-stall MMU  */

  return srcptr;
};


/* This function checks if we have the required interrupts.
 * It polls the Mali interrupt registers for this.
 * If we do not have the required interrupts, then it remembers which ones we
 * have seen, and then masks them.
 */
int Mali_InterruptCheck(int i_mask, int i_value)
{

  int have_any_int = 0;  /* Set to 1 is any of the interrupts are triggered */
  int ret_int      = 0;  /* Holds the return value to the calling routine */

  static int interrupt_state = 0; /* updated to hold the value of the interrupt triggred */

  int mask_gp        = 0;          /* Indicates if GP INT needs to be masked */
  int mask_pmu       = 0;          /* Indicates if PMU INT needs to be masked */
  int mask_gp_mmu    = 0;          /* Indicates if GP MMU INT needs to be masked */
  int mask_pp[8]     = {0,0,0,0};  /* Indicates if PP INT needs to be masked, one for each core */
  int mask_pp_mmu[8] = {0,0,0,0};  /* Indicates if PP MMU INT needs to be masked, one for each core */

  int core;
  int rd_int        = 0;           /* Holds the status of Interrupt register read for each core */

  printf ("Interrupt Received\n");


  if (((i_mask >> 16) & 1) > 0) {
    rd_int             = Mali_RdReg(0,0,0x68) & 0x1;           /* read GP INT bit */
    if (rd_int !=0){
        interrupt_state |= 0x1 << 16;
        mask_gp = 1;
        have_any_int = 1;
    }
  }

  if (((i_mask >> 17) & 1) > 0) {
    rd_int             = Mali_RdReg(9,0,0x14) & 0x1;           /* read PMU INT bit */
    if (rd_int !=0){
        interrupt_state |= 0x1 << 17;
        mask_pmu = 1;
        have_any_int = 1;
    }
  }

  if (((i_mask >> 20) & 1) > 0) {
    rd_int             = Mali_RdReg(2,0,0x20) & 0x3;           /* read GP MMU INT bit */
    if (rd_int !=0){
        interrupt_state |= 0x1 << 20;
        mask_gp_mmu = 1;
        have_any_int = 1;
    }
  }

  for (core=0; core < PP_CORES; core++) {
    if (((i_mask >> core) & 1) > 0) {
      rd_int     = Mali_RdReg(1,core,0x1008) & (0x1 << 6) ; /* read PPx bit */
      if (rd_int !=0) {
          interrupt_state |= 0x1 << core;
          mask_pp[core] = 1;
          have_any_int = 1;
      }
    }
    // If the PP interrupt overrides of the APB broadcast are used, then the
    // individual interrupts of each PP don't need to be masked.
    if (((i_mask >> 15) & 1) > 0) {
      rd_int     = Mali_RdReg(1,core,0x1008) & (0x1 << 6) ; /* read PPx bit */
      if (rd_int !=0) {
          interrupt_state |= 0x1 << 15;
          have_any_int = 1;
      }
    }
    if (((i_mask >> 20) & 1) > 0) {
      rd_int = Mali_RdReg(2,core+1,0x20) & 0x3;           /* read PPX MMU INT bit */
      if (rd_int !=0){
        interrupt_state |= 0x1 << 20;
        mask_pp_mmu[core] = 1;
        have_any_int = 1;
      }
    }
  }


  /* Update return status of interrupt if conditions matched else mask the triggered interrupts
   * and return false */
  if ((have_any_int && i_mask == 0xFFFFFFFF) || interrupt_state == i_mask ){
      ret_int = 1;
      interrupt_state = 0;
  }
  else
  {
      if (mask_gp) {
           printf ("Masking GP INT\n");
          Mali_WrReg(0x0,0x0,0x2c,0x00000000);
      }

      if (mask_pmu) {
           printf ("Masking PMU INT\n");
          Mali_WrReg(0x9,0x0,0xc,0x00000000);
      }

      if (mask_gp_mmu) {
          printf ("Masking GP MMU INT\n");
          Mali_WrReg(0x2,0x0,0x001c,0x00000000);
      }

      for (core=0; core < PP_CORES; core++) {
          if (mask_pp[core]) {
              printf ("Masking PP%d INT\n", core);
              Mali_WrReg(0x1,core,0x1028,0x00000000);
          }
          if (mask_pp_mmu[core]) {
              printf ("Masking PP%d MMU INT\n", core);
              Mali_WrReg(0x2,core+1,0x001c,0x00000000);
          }
      }
  }
  printf ("Done Processing Interrupt\n");
  return ret_int;

};

void Mali_MaskAllInterrupts (void) {
  int core;
  Mali_WrReg(0x0,0x0,0x2c,0x00000000);
  Mali_WrReg(0x2,0x0,0x001c,0x00000000);
  Mali_WrReg(0x9,0x0,0x000c,0x00000000);  /* PMU */
  for (core=0; core < PP_CORES; core++) {
    Mali_WrReg(0x1,core,0x1028,0x00000000);
    Mali_WrReg(0x2,core+1,0x001c,0x00000000);
  };
};


/* This will write to the register is in all cores */
/* i.e. if MMU - all MMUs */
/*      if PP  - all PPs  */
/*      if L2  - all L2s  */
void Mali_WrRegAll(int unit,int regnum,int value)
{
  int core;

  /* write register to first core */
  Mali_WrReg(unit,0,regnum,value);

  /* write register to all other cores */
  /* For PP (unit == 1) write to any other cores */
  if (unit == 1) {
    for (core=1; core < PP_CORES; core++) {
      Mali_WrReg(unit,core,regnum,value);
    };
  };
  /* For MMU (unit == 2), core 0 is GP MMU, so write to all PP MMUs */
  if (unit == 2) {
    for (core=1; core < (PP_CORES+1); core++) {
      Mali_WrReg(unit,core,regnum,value);
    };
  };
  /* Write to all L2s */
  if (unit == 3) {
    for (core=1; core < L2_CORES; core++) {
      Mali_WrReg(unit,core,regnum,value);
    };
  };
};

int Mali_RdReg(int unit,int core, int regnum)
{
  int *reg_ptr = Mali_Address(unit,core);
  reg_ptr += (regnum/4);

  return *reg_ptr;
};


void Mali_WrReg(int unit,int core,int regnum,int value)
{
  int *reg_ptr = Mali_Address(unit,core);
  reg_ptr += (regnum/4);

  *reg_ptr = value;
};

#define  M450_PP_CORE_OFFSET  0x2000
#define  M450_MMU_CORE_OFFSET 0x1000

int *Mali_Address(int unit,int core)
{
  int *reg_ptr = (int *)0;

  /* Write the appropriate register */
  if (unit == 0) { /* GP */
    reg_ptr = (int *)MALI_BASE;
  };
  if (unit == 1) { /* PP */
    reg_ptr = (int *)(MALI_BASE + 0x20000 + (M450_PP_CORE_OFFSET * core));
  };
  if (unit == 2) { /* MMU first one is for GP */
    if (core == 0)
      /* GP MMU is at offset 0x3000. */
      reg_ptr = (int *)(MALI_BASE + 0x3000);
  else
    /* PP MMUs start at offset 0x18000. */
      reg_ptr = (int *)(MALI_BASE + 0x18000 + (M450_MMU_CORE_OFFSET * (core-1)));
  };
  /* L2 caches:       */
  /* L2C0: 0x001_0000 */
  /* L2C1: 0x000_1000 */
  /* L2C2: 0x001_1000 */
  if (unit == 3) {
    if (core == 0)
      reg_ptr = (int *)(MALI_BASE + 0x10000);
    else {
      if (core == 1)
        reg_ptr = (int *)(MALI_BASE + 0x1000);
      else {
        if (core == 2)
          reg_ptr = (int *)(MALI_BASE + 0x11000);
      }
    }
  };

  if (unit == 4) { /* APB DMA unit */
    reg_ptr = (int *)(MALI_BASE + 0x12000);
  };

  if (unit == 5) { /* APB broadcast unit */
    reg_ptr = (int *)(MALI_BASE + 0x13000);
  };

  if (unit == 6) { /* Dynamic Load Balancing unit */
    reg_ptr = (int *)(MALI_BASE + 0x14000);
  };

  if (unit == 7) { /* MMU PP broadcast */
    reg_ptr = (int *)(MALI_BASE + 0x15000);
  };

  if (unit == 8) { /* PP broadcast */
    reg_ptr = (int *)(MALI_BASE + 0x16000);
  };

  if (unit == 9) { /* PMU */
    reg_ptr = (int *)(MALI_BASE + 0x2000);
  };

  return reg_ptr;
};


