/*----------------------------------------------------------------------------
*
*The confidential and proprietary information contained in this file may
*only be used by a person authorised under and to the extent permitted
*by a subsisting licensing agreement from ARM Limited.
*
*        (C) COPYRIGHT 2008-2009,2012 ARM Limited.
*             ALL RIGHTS RESERVED
*
*This entire notice must be reproduced on all copies of this file
*and copies of this file may only be made by a person if such person is
*permitted to do so under the terms of a subsisting license agreement
*from ARM Limited.
*Modified  : $Date: 2007-10-22 14:10:23 +0200 (Mon, 22 Oct 2007) $
*Revision  : $Revision: 68554 $
*Release   : $State: $
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Abstract :Declaration of Mali functions
*-----------------------------------------------------------------------------
* Overview
*----------
*
**************************************************************/
#include <stdio.h>

#include "MaliFns.h"

#ifdef TESTNAME
#else
#define TESTNAME RunMaliTest_test
#endif

typedef int (*MaliFunctionPtr)(int init);
int TESTNAME (int init);

void enable_irq(void);
void disable_irq(void);
void init_gic(void);
void int_ack(int IntNum);

/* Interrupt call backs */
void MaliIntCallBack (int IntNum, int IntSrc);
void MaliIntMMU (int IntNum, int IntSrc);

static MaliFunctionPtr mali_currentfunction_ptr;
static int Mali_FinishedFlag = 0;
static int Mali_ReturnCode = 0;

/********************************************************************************
 * Main routine for Mali Test.
 *
 * 1. Setup all interrupts
 * 2. Run first part of test. Remainder of test parts operate in interrupt handler.
 * 3. Spin until FinishedFlag is set.
 ********************************************************************************/
int main (void) {
  printf("Installing IRQ Handler\n");

  /* 1. Initialise the system GIC */
  /* 2. Install mali interrupt handlers */
  /* 3. Install the GIC handling at the interrupt vector */
  /* 4. Enable interrupts */
  disable_irq();
  init_and_install_gic();
  MaliInstallIntHandlers(&MaliIntCallBack,&MaliIntCallBack);

  /* 1. Install any tests */
  /* 2. Start running them */
  mali_currentfunction_ptr = &TESTNAME;
  Mali_ReturnCode = (*mali_currentfunction_ptr)(1);
  if (Mali_ReturnCode != 255) {
    Mali_FinishedFlag = 1;
  };
  enable_irq();

  /* Do whatever you like - mali now runs from within interrupt handler
     ............
     ............
   */

  /* Wait for all mali work to be finished */
  while (!Mali_FinishedFlag) {
    Mali_WaitForInterrupt();
  };

  if (Mali_ReturnCode != 0) {
    printf ("TEST FAILED\n");
  } else {
    printf ("TEST PASSED\n");
  };
};

/********************************************************************************
 * This is the mali interrupt handler for expected interrupts
 *
 * 1. acknowledge the interrupt
 * 2. call the next part in this test
 * 3. set finished flag if not returning with wait for interrupt return code
 ********************************************************************************/
void MaliIntCallBack (int IntNum, int IntSrc) {
  int_ack(IntNum);
  Mali_ReturnCode = (*mali_currentfunction_ptr)(0);
  if (Mali_ReturnCode != 255) {
    Mali_FinishedFlag = 1;
  };
};


/********************************************************************************
 * This is the mali interrupt handler for unexpected mmu interrupts
 *
 * 1. acknowledge the interrupt
 * 2. set finished flag if not returning with wait for interrupt return code
 ********************************************************************************/
// This is called by the interrupt handler
void MaliIntMMU (int IntNum, int IntSrc) {
  volatile int *tube = (volatile int *)0x10009000;
  int v;

  int_ack(IntNum);

  Mali_FinishedFlag = 1;
  Mali_ReturnCode = -1;
  printf ("UNEXPECTED MMU INTERRUPT\n");


  v = Mali_RdReg(2,0,0x4);
  printf ("%-24s, %x\n","Mali GP MMU  STATUS",v);
  v = Mali_RdReg(2,0,0xC);
  printf ("%-24s, %x\n","Mali GP MMU  FAULT ADDR",v);

  v = Mali_RdReg(2,1,0x4);
  printf ("%-24s, %x\n","Mali PP0 MMU STATUS",v);
  v = Mali_RdReg(2,1,0xC);
  printf ("%-24s, %x\n","Mali PP0 MMU FAULT ADDR",v);

  if (PP_CORES > 1 ) {
    v = Mali_RdReg(2,2,0x4);
    printf ("%-24s, %x\n","Mali PP1 MMU STATUS",v);
    v = Mali_RdReg(2,2,0xC);
    printf ("%-24s, %x\n","Mali PP1 MMU FAULT ADDR",v);
  }

  if (PP_CORES > 2 ) {
    v = Mali_RdReg(2,3,0x4);
    printf ("%-24s, %x\n","Mali PP2 MMU STATUS",v);
    v = Mali_RdReg(2,3,0xC);
    printf ("%-24s, %x\n","Mali PP2 MMU FAULT ADDR",v);
  }

  if (PP_CORES > 3 ) {
    v = Mali_RdReg(2,4,0x4);
    printf ("%-24s, %x\n","Mali PP3 MMU STATUS",v);
    v = Mali_RdReg(2,4,0xC);
    printf ("%-24s, %x\n","Mali PP3 MMU FAULT ADDR",v);
  }

  if (PP_CORES > 4 ) {
    v = Mali_RdReg(2,5,0x4);
    printf ("%-24s, %x\n","Mali PP4 MMU STATUS",v);
    v = Mali_RdReg(2,5,0xC);
    printf ("%-24s, %x\n","Mali PP4 MMU FAULT ADDR",v);
  }

  if (PP_CORES > 5 ) {
    v = Mali_RdReg(2,6,0x4);
    printf ("%-24s, %x\n","Mali PP5 MMU STATUS",v);
    v = Mali_RdReg(2,6,0xC);
    printf ("%-24s, %x\n","Mali PP5 MMU FAULT ADDR",v);
  }

  if (PP_CORES > 6 ) {
    v = Mali_RdReg(2,7,0x4);
    printf ("%-24s, %x\n","Mali PP6 MMU STATUS",v);
    v = Mali_RdReg(2,7,0xC);
    printf ("%-24s, %x\n","Mali PP6 MMU FAULT ADDR",v);
  }

  if (PP_CORES > 7 ) {
    v = Mali_RdReg(2,8,0x4);
    printf ("%-24s, %x\n","Mali PP7 MMU STATUS",v);
    v = Mali_RdReg(2,8,0xC);
    printf ("%-24s, %x\n","Mali PP7 MMU FAULT ADDR",v);
  }

#ifndef IGNORE_MMU_INTERRUPTS
  printf ("TEST FAILED\n\n");
  *tube = 4;
  while(1);
#endif
};





