/*----------------------------------------------------------------------------
*
*The confidential and proprietary information contained in this file may
*only be used by a person authorised under and to the extent permitted
*by a subsisting licensing agreement from ARM Limited.
*
*        (C) COPYRIGHT 2008-2009,2012 ARM Limited.
*             ALL RIGHTS RESERVED
*
*This entire notice must be reproduced on all copies of this file
*and copies of this file may only be made by a person if such person is
*permitted to do so under the terms of a subsisting license agreement
*from ARM Limited.
*Modified  : $Date: 2007-10-22 14:10:23 +0200 (Mon, 22 Oct 2007) $
*Revision  : $Revision: 68554 $
*Release   : $State: $
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Abstract : System Specific Functions - including interrupts
*----------------------------------------------------------------------------*/

#include "MaliFns.h"
#include <stdio.h>
#include "common.h"
#include "IntHandler.h"

void CPU_EnableInterrupts(void) {
  enable_irq();
};
void CPU_DisableInterrupts(void) {
  disable_irq();
};
void CPU_InitialiseInterrupts(void) {
  init_and_install_gic();
};

void Mali_WaitForInterrupt(void) {
  call_wfi();
};

void Mali_WaitForClk(int cyc)
{
    int count = cyc *4;
    printf ("Mali_WaitForClk: cyc=%d, count=%d\n", cyc, count);
    while (count > 0)
        count--;
};

void Mali_InstallIntHandlers(void (*callback_mali_gp)(void),
                             void (*callback_mali_pp)(void),
                             void (*callback_mali_mmu)(void),
                             void (*callback_mali_pmu)(void)) {

  interrupt_handler_set(32,callback_mali_pp);   // PP0
  interrupt_handler_set(33,callback_mali_pp);   // PP1
  interrupt_handler_set(34,callback_mali_pp);   // PP2
  interrupt_handler_set(35,callback_mali_pp);   // PP3
  interrupt_handler_set(36,callback_mali_pp);   // PP4
  interrupt_handler_set(37,callback_mali_pp);   // PP5
  interrupt_handler_set(38,callback_mali_pp);   // PP6
  interrupt_handler_set(39,callback_mali_pp);   // PP7

  interrupt_handler_set(47,callback_mali_pp);   // PP
  interrupt_handler_set(48,callback_mali_gp);   // GP
  interrupt_handler_set(49,callback_mali_pmu);  // PMU

  interrupt_handler_set(52,callback_mali_mmu);  // GP MMU
  interrupt_handler_set(53,callback_mali_mmu);  // PP0 MMU
  interrupt_handler_set(54,callback_mali_mmu);  // PP1 MMU
  interrupt_handler_set(55,callback_mali_mmu);  // PP2 MMU
  interrupt_handler_set(56,callback_mali_mmu);  // PP3 MMU
  interrupt_handler_set(57,callback_mali_mmu);  // PP4 MMU
  interrupt_handler_set(58,callback_mali_mmu);  // PP5 MMU
  interrupt_handler_set(59,callback_mali_mmu);  // PP6 MMU
  interrupt_handler_set(60,callback_mali_mmu);  // PP7 MMU


  int_enable(32);
  int_enable(33);
  int_enable(34);
  int_enable(35);
  int_enable(36);
  int_enable(37);
  int_enable(38);
  int_enable(39);
  int_enable(47);
  int_enable(48);
  int_enable(49);
  int_enable(52);
  int_enable(53);
  int_enable(54);
  int_enable(55);
  int_enable(56);
  int_enable(57);
  int_enable(58);
  int_enable(59);
  int_enable(60);
};

/* For future use. Called just before a PP job starts */
void Mali_SetupOutputFrame (void) {
};

/* For future used. Called once a job part has recieved its required interrupts */
/* It is not currently used; but would be a suitable place to position CPU cache cleaning */
/* routines - if it was required to clean/invalidate the cpu caches before performing */
/* self checking */
void Mali_JobPartDone (void) {
};

void Mali_Message(char *s) {
  printf("%s",s);
};

