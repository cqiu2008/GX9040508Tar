/*----------------------------------------------------------------------------
*
*The confidential and proprietary information contained in this file may
*only be used by a person authorised under and to the extent permitted
*by a subsisting licensing agreement from ARM Limited.
*
*        (C) COPYRIGHT 2008-2009,2012 ARM Limited.
*             ALL RIGHTS RESERVED
*
*This entire notice must be reproduced on all copies of this file
*and copies of this file may only be made by a person if such person is
*permitted to do so under the terms of a subsisting license agreement
*from ARM Limited.
*Modified  : $Date: 2007-10-22 14:10:23 +0200 (Mon, 22 Oct 2007) $
*Revision  : $Revision: 68554 $
*Release   : $State: $
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Abstract :Toplevel file implementing Main()
*-----------------------------------------------------------------------------
* Overview
*----------
*
**************************************************************/
#include <stdio.h>

#include "MaliFns.h"

#ifdef TESTNAME
#else
#define TESTNAME RunMaliTest_test
#endif

typedef int (*MaliFunctionPtr)(int init);
int TESTNAME (int init);

/* Interrupt call backs */
void MaliIntCallBack (int IntNum, int IntSrc);

static MaliFunctionPtr mali_currentfunction_ptr;

static int Mali_FinishedFlag = 0;
static int Mali_ReturnCode   = 0;

/********************************************************************************
 * Main routine for Mali Test.
 *
 * 1. Setup all interrupts
 * 2. Run first part of test. Remainder of test parts operate in interrupt handler.
 * 3. Spin until FinishedFlag is set.
 ********************************************************************************/
int main (void) {
  printf("Installing interrupt handler\n");

  /* 1. Disable CPU interrupts; and initalise any interrupt controller */
  /* 2. Install mali interrupt handlers */
  /* 3. Install interrupt handlers for mali interrupts */
  CPU_DisableInterrupts();
  CPU_InitialiseInterrupts();
  Mali_InstallIntHandlers(&MaliIntCallBack,
                          &MaliIntCallBack,
                          &MaliIntCallBack,
                          &MaliIntCallBack
                          );

  /* 4. Run the first part of this test. */
  /*    Note this can trigger an interrupt; hence we run this whilst interrupts */
  /*    are disabled. If interrupt masking cannot be done - then create another */
  /*    system to mali interrupts until after this routine has returned.        */
  /* 5. Enable interrupts */
  mali_currentfunction_ptr = &TESTNAME;
  Mali_ReturnCode = (*mali_currentfunction_ptr)(1);
  if (Mali_ReturnCode != 255) {
    Mali_FinishedFlag = 1;
  };
  CPU_EnableInterrupts();

  /* Do whatever you like - mali now runs from within interrupt handler
     For reference we have an infinite loop with a wait for interrupt instruction
     inside - waiting until all Mali jobs are finished.
     ............
   */

  while (!Mali_FinishedFlag) {
    Mali_WaitForInterrupt();
  };

  if (Mali_ReturnCode != 0) {
    printf ("TEST FAILED\n");
  } else {
    printf ("TEST PASSED\n");
  };
};

/********************************************************************************
 * This is the mali interrupt handler for expected interrupts
 *
 * 1. acknowledge the interrupt
 * 2. call the next part in this test
 * 3. set finished flag if not returning with wait for interrupt return code
 ********************************************************************************/
void MaliIntCallBack (int IntNum, int IntSrc) {
  /* Only run next step if we have not finished */
  /* This ensures that if the callback is executed when no mali interrupts */
  /* are actually pending; the test still works */

  if (Mali_FinishedFlag == 0) {
    Mali_ReturnCode = (*mali_currentfunction_ptr)(0);
  };
  if (Mali_ReturnCode != 255) {
    Mali_FinishedFlag = 1;
  };
};

