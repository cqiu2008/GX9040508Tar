/*----------------------------------------------------------------------------
*
*The confidential and proprietary information contained in this file may
*only be used by a person authorised under and to the extent permitted
*by a subsisting licensing agreement from ARM Limited.
*
*        (C) COPYRIGHT 2008-2009,2012 ARM Limited.
*             ALL RIGHTS RESERVED
*
*This entire notice must be reproduced on all copies of this file
*and copies of this file may only be made by a person if such person is
*permitted to do so under the terms of a subsisting license agreement
*from ARM Limited.
*Modified  : $Date: 2007-10-22 14:10:23 +0200 (Mon, 22 Oct 2007) $
*Revision  : $Revision: 68554 $
*Release   : $State: $
*-----------------------------------------------------------------------------
*
*-----------------------------------------------------------------------------
* Abstract : Mali Performance Counters
*-----------------------------------------------------------------------------*/

#include "MaliFns.h"

void Mali_InitPerfCountersFn(int core, int cnt_num, int cnt_id);

/* Defines for Performance Counters - Cores */
#define  GP_PERF 0
#define PP0_PERF 1
#define PP1_PERF 2
#define PP2_PERF 3
#define PP3_PERF 4
#define PP4_PERF 5
#define PP5_PERF 6
#define PP6_PERF 7
#define PP7_PERF 8
#define L2C0_PERF 9
#define L2C1_PERF 10
#define L2C2_PERF 11


void Mali_InitPerfCounters() {

  /* Enable GP Performance counters */
  Mali_InitPerfCountersFn(GP_PERF, 0, 1);
  Mali_InitPerfCountersFn(GP_PERF, 1, 6);

  /* Enable PPs Performance counters */
  Mali_InitPerfCountersFn(PP0_PERF, 0, 0);
  Mali_InitPerfCountersFn(PP0_PERF, 1, 2);

  if (PP_CORES > 1 ) {
    Mali_InitPerfCountersFn(PP1_PERF, 0, 0);
    Mali_InitPerfCountersFn(PP1_PERF, 1, 2);
  }

  if (PP_CORES > 2 ) {
    Mali_InitPerfCountersFn(PP2_PERF, 0, 0);
    Mali_InitPerfCountersFn(PP2_PERF, 1, 2);
  }

  if (PP_CORES > 3 ) {
    Mali_InitPerfCountersFn(PP3_PERF, 0, 0);
    Mali_InitPerfCountersFn(PP3_PERF, 1, 2);
  }

  if (PP_CORES > 4 ) {
    Mali_InitPerfCountersFn(PP4_PERF, 0, 0);
    Mali_InitPerfCountersFn(PP4_PERF, 1, 2);
  }

  if (PP_CORES > 5 ) {
    Mali_InitPerfCountersFn(PP5_PERF, 0, 0);
    Mali_InitPerfCountersFn(PP5_PERF, 1, 2);
  }

  if (PP_CORES > 6 ) {
    Mali_InitPerfCountersFn(PP6_PERF, 0, 0);
    Mali_InitPerfCountersFn(PP6_PERF, 1, 2);
  }

  if (PP_CORES > 7 ) {
    Mali_InitPerfCountersFn(PP7_PERF, 0, 0);
    Mali_InitPerfCountersFn(PP7_PERF, 1, 2);
  }

  /* Enable L2s Performance counters */
  Mali_InitPerfCountersFn(L2C0_PERF, 0, 2);
  Mali_InitPerfCountersFn(L2C0_PERF, 1, 10);

  Mali_InitPerfCountersFn(L2C1_PERF, 0, 2);
  Mali_InitPerfCountersFn(L2C1_PERF, 1, 10);

  if (L2_CORES > 2 ) {
    Mali_InitPerfCountersFn(L2C2_PERF, 0, 2);
    Mali_InitPerfCountersFn(L2C2_PERF, 1, 10);
  }

};


void Mali_InitPerfCountersFn(int core, int cnt_num, int cnt_id) {

    if (core == GP_PERF){
        /* GP */
        Mali_WrReg(0,0,0x3C + cnt_num*4,1);
        Mali_WrReg(0,0,0x44 + cnt_num*4,cnt_id);
    }

    if (core == PP0_PERF){
        /* PP0 */
        Mali_WrReg(1,0,0x1080+cnt_num*0x20,1);
        Mali_WrReg(1,0,0x1084+cnt_num*0x20,cnt_id);
    }

    if (core == PP1_PERF && PP_CORES > 1 ){
        /* PP1 */
        Mali_WrReg(1,1,0x1080+cnt_num*0x20,1);
        Mali_WrReg(1,1,0x1084+cnt_num*0x20,cnt_id);
    }

    if (core == PP2_PERF && PP_CORES > 2){
        /* PP2 */
        Mali_WrReg(1,2,0x1080+cnt_num*0x20,1);
        Mali_WrReg(1,2,0x1084+cnt_num*0x20,cnt_id);
    }

    if (core == PP3_PERF && PP_CORES > 3){
        /* PP3 */
        Mali_WrReg(1,3,0x1080+cnt_num*0x20,1);
        Mali_WrReg(1,3,0x1084+cnt_num*0x20,cnt_id);
    }

    if (core == PP4_PERF && PP_CORES > 4){
        /* PP4 */
        Mali_WrReg(1,4,0x1080+cnt_num*0x20,1);
        Mali_WrReg(1,4,0x1084+cnt_num*0x20,cnt_id);
    }

    if (core == PP5_PERF && PP_CORES > 5){
        /* PP5 */
        Mali_WrReg(1,5,0x1080+cnt_num*0x20,1);
        Mali_WrReg(1,5,0x1084+cnt_num*0x20,cnt_id);
    }

    if (core == PP6_PERF && PP_CORES > 6){
        /* PP6 */
        Mali_WrReg(1,6,0x1080+cnt_num*0x20,1);
        Mali_WrReg(1,6,0x1084+cnt_num*0x20,cnt_id);
    }

    if (core == PP7_PERF && PP_CORES > 7){
        /* PP7 */
        Mali_WrReg(1,7,0x1080+cnt_num*0x20,1);
        Mali_WrReg(1,7,0x1084+cnt_num*0x20,cnt_id);
    }

    if (core == L2C0_PERF){
        /* L2 */
        Mali_WrReg(3,0,0x20 + cnt_num*8,1);
        Mali_WrReg(3,0,0x24 + cnt_num*8,cnt_id);
    }

    if (core == L2C1_PERF){
        /* L2 */
        Mali_WrReg(3,1,0x20 + cnt_num*8,1);
        Mali_WrReg(3,1,0x24 + cnt_num*8,cnt_id);
    }

    if (core == L2C2_PERF && L2_CORES > 2){
        /* L2 */
        Mali_WrReg(3,2,0x20 + cnt_num*8,1);
        Mali_WrReg(3,2,0x24 + cnt_num*8,cnt_id);
    }

};


void Mali_ReadPerfCounters() {

  /* This is an example implementation
   * This function needs to be retargeted to any performance counters
   * you wish to read from any of the cores
   */

  unsigned int v;
  printf ("Reading performance counters\n");

  v = Mali_RdReg(0,0,0x24);
  printf ("%-24s, %x\n","Mali GP      INT_RAWSTAT",v);

  v = Mali_RdReg(1,0,0x1020);
  printf ("%-24s, %x\n","Mali PP0     INT_RAWSTAT",v);

  if (PP_CORES > 1) {
      v = Mali_RdReg(1,1,0x1020);
      printf ("%-24s, %x\n","Mali PP1     INT_RAWSTAT",v);
  }

  if (PP_CORES > 2) {
      v = Mali_RdReg(1,2,0x1020);
      printf ("%-24s, %x\n","Mali PP2     INT_RAWSTAT",v);
  }

  if (PP_CORES > 3) {
      v = Mali_RdReg(1,3,0x1020);
      printf ("%-24s, %x\n","Mali PP3     INT_RAWSTAT",v);
  }

  if (PP_CORES > 4) {
      v = Mali_RdReg(1,4,0x1020);
      printf ("%-24s, %x\n","Mali PP4     INT_RAWSTAT",v);
  }

  if (PP_CORES > 5) {
      v = Mali_RdReg(1,5,0x1020);
      printf ("%-24s, %x\n","Mali PP5     INT_RAWSTAT",v);
  }

  if (PP_CORES > 6) {
      v = Mali_RdReg(1,6,0x1020);
      printf ("%-24s, %x\n","Mali PP6     INT_RAWSTAT",v);
  }

  if (PP_CORES > 7) {
      v = Mali_RdReg(1,7,0x1020);
      printf ("%-24s, %x\n","Mali PP7     INT_RAWSTAT",v);
  }

  v = Mali_RdReg(2,0,0x14);
  printf ("%-24s, %x\n","Mali GP MMU  INT_RAWSTAT",v);

  v = Mali_RdReg(2,1,0x14);
  printf ("%-24s, %x\n","Mali PP0 MMU INT_RAWSTAT",v);

  if (PP_CORES > 1) {
      v = Mali_RdReg(2,2,0x14);
      printf ("%-24s, %x\n","Mali PP1 MMU INT_RAWSTAT",v);
  }

  if (PP_CORES > 2) {
      v = Mali_RdReg(2,3,0x14);
      printf ("%-24s, %x\n","Mali PP2 MMU INT_RAWSTAT",v);
  }

  if (PP_CORES > 3) {
      v = Mali_RdReg(2,4,0x14);
      printf ("%-24s, %x\n","Mali PP3 MMU INT_RAWSTAT",v);
  }

  if (PP_CORES > 4) {
      v = Mali_RdReg(2,5,0x14);
      printf ("%-24s, %x\n","Mali PP4 MMU INT_RAWSTAT",v);
  }

  if (PP_CORES > 5) {
      v = Mali_RdReg(2,6,0x14);
      printf ("%-24s, %x\n","Mali PP5 MMU INT_RAWSTAT",v);
  }

  if (PP_CORES > 6) {
      v = Mali_RdReg(2,7,0x14);
      printf ("%-24s, %x\n","Mali PP6 MMU INT_RAWSTAT",v);
  }

  if (PP_CORES > 7) {
      v = Mali_RdReg(2,8,0x14);
      printf ("%-24s, %x\n","Mali PP7 MMU INT_RAWSTAT",v);
  }

  v = Mali_RdReg(0,0,0x4C);
  printf ("%-24s, %u\n","Mali GP  Active Cycles",v);

  v = Mali_RdReg(1,0,0x108C);
  printf ("%-24s, %u\n","Mali PP0 Active Cycles",v);

  if (PP_CORES > 1) {
      v = Mali_RdReg(1,1,0x108C);
      printf ("%-24s, %u\n","Mali PP1 Active Cycles",v);
  }

  if (PP_CORES > 2) {
      v = Mali_RdReg(1,2,0x108C);
      printf ("%-24s, %u\n","Mali PP2 Active Cycles",v);
  }

  if (PP_CORES > 3) {
      v = Mali_RdReg(1,3,0x108C);
      printf ("%-24s, %u\n","Mali PP3 Active Cycles",v);
  }

  if (PP_CORES > 4) {
      v = Mali_RdReg(1,4,0x108C);
      printf ("%-24s, %u\n","Mali PP4 Active Cycles",v);
  }

  if (PP_CORES > 5) {
      v = Mali_RdReg(1,5,0x108C);
      printf ("%-24s, %u\n","Mali PP5 Active Cycles",v);
  }

  if (PP_CORES > 6) {
      v = Mali_RdReg(1,6,0x108C);
      printf ("%-24s, %u\n","Mali PP6 Active Cycles",v);
  }

  if (PP_CORES > 7) {
      v = Mali_RdReg(1,7,0x108C);
      printf ("%-24s, %u\n","Mali PP7 Active Cycles",v);
  }

  v = Mali_RdReg(3,0,0x24);
  printf ("%-24s, %u\n","Mali L2C0 Active Cycles",v);

  v = Mali_RdReg(3,1,0x24);
  printf ("%-24s, %u\n","Mali L2C1 Active Cycles",v);

  if (L2_CORES > 2) {
    v = Mali_RdReg(3,2,0x24);
    printf ("%-24s, %u\n","Mali L2C2 Active Cycles",v);
  }

  v = Mali_RdReg(0,0,0x50);
  printf ("%-24s, %u\n","Mali  GP 64-bit Reads",v);

  v = Mali_RdReg(1,0,0x10AC);
  printf ("%-24s, %u\n","Mali PP0 64-bit Reads",v);

  if (PP_CORES > 1) {
      v = Mali_RdReg(1,1,0x10AC);
      printf ("%-24s, %u\n","Mali PP1 64-bit Reads",v);
  }

  if (PP_CORES > 2) {
      v = Mali_RdReg(1,2,0x10AC);
      printf ("%-24s, %u\n","Mali PP2 64-bit Reads",v);
  }

  if (PP_CORES > 3) {
      v = Mali_RdReg(1,3,0x10AC);
      printf ("%-24s, %u\n","Mali PP3 64-bit Reads",v);
  }

  if (PP_CORES > 4) {
      v = Mali_RdReg(1,4,0x10AC);
      printf ("%-24s, %u\n","Mali PP4 64-bit Reads",v);
  }

  if (PP_CORES > 5) {
      v = Mali_RdReg(1,5,0x10AC);
      printf ("%-24s, %u\n","Mali PP5 64-bit Reads",v);
  }

  if (PP_CORES > 6) {
      v = Mali_RdReg(1,6,0x10AC);
      printf ("%-24s, %u\n","Mali PP6 64-bit Reads",v);
  }

  if (PP_CORES > 7) {
      v = Mali_RdReg(1,7,0x10AC);
      printf ("%-24s, %u\n","Mali PP7 64-bit Reads",v);
  }

  v = Mali_RdReg(3,0,0x2C);
  printf ("%-24s, %u\n","Mali L2C0 128-bit Reads",v);
  printf ("%-24s, %u\n","Mali L2C0 128-bit Reads * 2",v*2);

  v = Mali_RdReg(3,1,0x2C);
  printf ("%-24s, %u\n","Mali L2C1 128-bit Reads",v);
  printf ("%-24s, %u\n","Mali L2C1 128-bit Reads * 2",v*2);

  if (L2_CORES > 2) {
    v = Mali_RdReg(3,2,0x2C);
    printf ("%-24s, %u\n","Mali L2C2 128-bit Reads",v);
    printf ("%-24s, %u\n","Mali L2C2 128-bit Reads * 2",v*2);
  }

};

