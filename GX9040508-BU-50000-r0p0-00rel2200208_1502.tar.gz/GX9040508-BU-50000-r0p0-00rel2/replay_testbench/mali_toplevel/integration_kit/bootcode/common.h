/*----------------------------------------------------------------------------
*
*The confidential and proprietary information contained in this file may
*only be used by a person authorised under and to the extent permitted
*by a subsisting licensing agreement from ARM Limited.
*
*        (C) COPYRIGHT 2008-2009 ARM Limited.
*             ALL RIGHTS RESERVED
*             
*This entire notice must be reproduced on all copies of this file
*and copies of this file may only be made by a person if such person is
*permitted to do so under the terms of a subsisting license agreement
*from ARM Limited.
*Modified  : $Date: 2007-10-22 14:10:23 +0200 (Mon, 22 Oct 2007) $
*Revision  : $Revision: 68554 $
*Release   : $State: $
*-----------------------------------------------------------------------------
* 
*-----------------------------------------------------------------------------
* Abstract :Common Header File
*-----------------------------------------------------------------------------
* Overview
*----------
* 
*
* 
* 
**************************************************************/
#define write32(addr, val) (*(volatile unsigned int *)(addr) = (val))
#define read32(addr) (*(volatile unsigned int *)(addr))

/* these functions are in cache.s */
extern void clean_dcache(void);  
extern void clean_dcache_line(int);
extern void clean_invalidate_dcache_line(int);
extern void flush_tlb(void);
extern void flush_branch_pred_array(void);
extern void invalidate_icache(void);
extern void invalidate_icache_line(int);
extern void instr_sync_barrier(void);
extern void data_sync_barrier(void);

/* these functions are in helpers.s */
extern void call_wfi(void);
extern void enable_irq(void);
extern void disable_irq(void);

