#include <stdio.h>
#include <rt_misc.h>
#include <time.h>

#include "common.h"

#pragma import(__use_no_semihosting_swi) 

/*-------------------------------------------------------------------------------
 * I/O Routines
 * These need porting to destination platform
 *------------------------------------------------------------------------------*/

volatile char *tube    = (volatile char *)0x10009000;

void uart_init (void) {
  write32(tube + 0x30,0);       /* disable */
  write32(tube + 0x28,0x4);     /* baudrate fraction */
  write32(tube + 0x24,0x27);    /* baudrate divider - 38400 */
  write32(tube + 0x2c,0x70);    /* 8n1, fifo enabled */
  write32(tube + 0x30,0x100 | 0x200 | 0x400 | 0x800 | 1); /* TXE|RXE|DTR|CTS|EN */
  write32(tube,'O');
  write32(tube,'K');
  write32(tube,'\n');
  write32(tube,'\r');
};

void uart_putc (int c)
{
  /* Wait until FIFO is not full */
  while (read32(tube + 0x14) & (1 << 5)) {};
  write32(tube,c);
};


void uart_puts (char *s)
{
  while (*s) {
    /* Wait until FIFO is not full */
    while (read32(tube + 0x14) & (1 << 5)) {};
    write32(tube,*s++);
  };
};

/*-------------------------------------------------------------------------------
 * RVCT - remapping of I/O routines to make printf work 
 *------------------------------------------------------------------------------*/
int fputc(int c, FILE *stream)
{
    /* Only output console data to tube */
    if (stream == stdout || stream == stderr) {
      uart_putc(c);
    }
    return c;
}

void _sys_exit(int c)
{
  uart_putc(4);
  while(1);
}

extern void _ttywrch(int c)
{
    fputc(c, (void *)0);
}

const char __stdin_name[]  = "stdin";
const char __stdout_name[] = "stdout";
const char __stderr_name[] = "stderr";

int _sys_open(const char * name, int openmode) {}
int _sys_close(int fh) {}
int _sys_write(int fh, const unsigned char * buf, unsigned len, int mode) {}
int _sys_seek(int fh, long pos) {}
int _sys_istty(int fh) {}
long _sys_flen(int fh) {}

clock_t clock(void) {}
void _clock_init(void) {}
time_t time(time_t *tt) {}

extern char *_sys_command_string(char *cmd, int l)
{
    *cmd = 0;
    return cmd;
}

