/*----------------------------------------------------------------------------
*
*The confidential and proprietary information contained in this file may
*only be used by a person authorised under and to the extent permitted
*by a subsisting licensing agreement from ARM Limited.
*
*        (C) COPYRIGHT 2008-2009 ARM Limited.
*             ALL RIGHTS RESERVED
*             
*This entire notice must be reproduced on all copies of this file
*and copies of this file may only be made by a person if such person is
*permitted to do so under the terms of a subsisting license agreement
*from ARM Limited.
*Modified  : $Date: 2007-10-22 14:10:23 +0200 (Mon, 22 Oct 2007) $
*Revision  : $Revision: 68554 $
*Release   : $State: $
*-----------------------------------------------------------------------------
* 
*-----------------------------------------------------------------------------
* Abstract :CLCD Implementation
*-----------------------------------------------------------------------------
* Overview
*----------
* 
*
* 
* 
**************************************************************/
#include "clcd.h"

#define CLCDC_BASE                                      0x10020000
#define AHB_WRITE(address, value)       (*((unsigned int*)(address))) = (value)

void SetupCLCD(int x,int y,int bpp,unsigned int framebuff,unsigned int framebuff_offset) {

        unsigned int TimeOut;

        // set up for TFT 320x200 16bpp no-palette
        unsigned int HBP = 0x8c;
        unsigned int HFP = 0x00;
        unsigned int HSW = 0xFF;
        unsigned int PPL = (x / bpp) - 1;
        unsigned int LCDTiming0 = (HBP << 1) | (HFP << 1) | (HSW << 3) | (PPL << 4);

        unsigned int VBP = 0;
        unsigned int VFP = 0;
        unsigned int VSW = 1 - 1;
        //unsigned int VSW = 64 - 1;
        unsigned int LPP = y - 1;
        unsigned int LCDTiming1 = (VBP << 24) | (VFP << 16) | (VSW << 10) | (LPP << 0);

        unsigned int BCD = 0;
        unsigned int CPL = x - 1;
        unsigned int IOE = 0;
        unsigned int IPC = 0;
        unsigned int IHS = 0;
        unsigned int IVS = 0;
        unsigned int ACB = 0;
        unsigned int CLKSEL = 0;
        unsigned int PCD = 0;
        unsigned int LCDTiming2 = (BCD << 26) | (CPL << 16) | (IOE << 14) | (IPC << 13) | (IHS << 12) | (IVS << 11) | (ACB << 6) | (CLKSEL << 5) | PCD;

        // see CLCD TRM
        AHB_WRITE(CLCDC_BASE + 0x00, LCDTiming0);
        AHB_WRITE(CLCDC_BASE + 0x04, LCDTiming1);
        AHB_WRITE(CLCDC_BASE + 0x08, LCDTiming2);
        AHB_WRITE(CLCDC_BASE + 0x0C, 0x00000000);
        AHB_WRITE(CLCDC_BASE + 0x10, framebuff + framebuff_offset  ); // Framebuffer base
        AHB_WRITE(CLCDC_BASE + 0x14, 0x00000000);
        AHB_WRITE(CLCDC_BASE + 0x18, 0x0000082c); //RGB 5:6:5
        for(TimeOut = 10; TimeOut > 0; TimeOut--) {};
        AHB_WRITE(CLCDC_BASE + 0x18, 0x0000082d); //RGB 5:6:5

};



void CLCDFrameBufferBase(unsigned int framebase,int offset) {
        unsigned int TimeOut;

  AHB_WRITE(CLCDC_BASE + 0x0C, 0x00000000);
  AHB_WRITE(CLCDC_BASE + 0x10, framebase + offset   ); // Framebuffer base
        AHB_WRITE(CLCDC_BASE + 0x14, 0x00000000);
        AHB_WRITE(CLCDC_BASE + 0x18, 0x0000082c); //RGB 5:6:5
        for(TimeOut = 10; TimeOut > 0; TimeOut--) {};
        AHB_WRITE(CLCDC_BASE + 0x18, 0x0000082d); //RGB 5:6:5
};

