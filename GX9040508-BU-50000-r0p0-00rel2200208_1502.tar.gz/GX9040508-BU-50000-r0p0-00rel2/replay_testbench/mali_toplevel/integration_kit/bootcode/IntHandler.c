/*----------------------------------------------------------------------------
*
*The confidential and proprietary information contained in this file may
*only be used by a person authorised under and to the extent permitted
*by a subsisting licensing agreement from ARM Limited.
*
*        (C) COPYRIGHT 2008-2009 ARM Limited.
*             ALL RIGHTS RESERVED
*             
*This entire notice must be reproduced on all copies of this file
*and copies of this file may only be made by a person if such person is
*permitted to do so under the terms of a subsisting license agreement
*from ARM Limited.
*Modified  : $Date: 2007-10-22 14:10:23 +0200 (Mon, 22 Oct 2007) $
*Revision  : $Revision: 68554 $
*Release   : $State: $
*-----------------------------------------------------------------------------
* 
*-----------------------------------------------------------------------------
* Abstract :Interrupt Handelling Routines
*-----------------------------------------------------------------------------
* Overview
*----------
* Initialise the GICs
*
* For A9    tested with external and internal gic
* For A1176 tested with external gic
**************************************************************/

#include "IntHandler.h"


struct set_and_clear_regs
{
    volatile unsigned int set[32], clear[32];
};

typedef struct
{
    /* 0x000 */  volatile unsigned int control;
                 volatile unsigned const int controller_type;
                 const char padding1[248];
    /* 0x100 */  struct set_and_clear_regs enable;
    /* 0x200 */  struct set_and_clear_regs pending;
    /* 0x300 */  volatile unsigned const int active[32];
                 const char padding2[128];
    /* 0x400 */  volatile unsigned int priority[256];
    /* 0x800 */  volatile unsigned int target[256];
    /* 0xC00 */  volatile unsigned int configuration[64];
    /* 0xD00 */  const char padding3[512];
    /* 0xF00 */  volatile unsigned int software_interrupt;
                 const char padding4[220];
    /* 0xFE0 */  volatile unsigned const int peripheral_id[4];
    /* 0xFF0 */  volatile unsigned const int primecell_id[4];
} interrupt_distributor;

typedef struct
{
    /* 0x00 */  volatile unsigned int control;
    /* 0x04 */  volatile unsigned int priority_mask;
    /* 0x08 */  volatile unsigned int binary_point;
    /* 0x0c */  volatile unsigned const int interrupt_ack;
    /* 0x10 */  volatile unsigned int end_of_interrupt;
    /* 0x14 */  volatile unsigned const int running_priority;
    /* 0x18 */  volatile unsigned const int highest_pending;
} cpu_interface;

/* DEFAULT ADDRESSES IN MEMORY MAP FOR INTERRUPT CONTROLLER */
/* The defaults are the addresses from the Emulator Baseboard system interrupt controller */
/* */
/* FOR CORTEX-A9 set id to PERIPHBASE + 0x1000, and ci to PERIPHBASE + 0x100 */

#ifndef CORTEXA9INTERNALGIC

static interrupt_distributor * id = (interrupt_distributor *)0x10041000;
static cpu_interface         * ci = (cpu_interface *)0x10040000;

#else

#define PERIPHBASE 0x1f000000
static interrupt_distributor * id = (interrupt_distributor *)((char *)PERIPHBASE+0x1000);
static cpu_interface         * ci = (cpu_interface *)((char *)PERIPHBASE+0x100);

#endif

void int_enable(int i) {
  int word;

  word  = i / 32;
  i    %= 32;
  i     = 1 << i;

  id->enable.set[word] = i;
}

extern void (*wrapped_irq_vector)();

void irq_handler(void);

void init_and_install_gic(void) {
        unsigned int i, max_irq;

        /* Disable the whole thing */
        id->control = 0x00000000;

        max_irq = id->controller_type & 0x1F;
        max_irq = (max_irq + 1) * 32;

        /* Disable all interrupts */
        for (i=0; i < max_irq / 32; i++)
          {
            id->enable.clear[i] = 0xffffffff;
          }

        /* Clear all interrupts */
        for (i=1; i < max_irq / 32; i++)
          {
            id->pending.clear[i] = 0xffffffff;
          }

        /* Reset interrupt priorities */
        for (i=8; i < max_irq / 4; i++)
          {
            id->priority[i] = 0xa0a0a0a0;
          }

        /* Reset interrupt targets */
        for (i=0; i < max_irq / 4; i++)
          {
            id->target[i] = 0x01010101;
          }

        /* Set correct interrupt configuration (level sensitive, 1-N) */
        for (i=2; i < max_irq / 16; i++)
          {
            id->configuration[i] = 0x55555555;
          }

        // Distributor Enable interrupts
        id->control = 0x00000001;


        // Interrupt CPU Interface
        // Set priority mask to enable all interrupts
        ci->priority_mask = 0xF0;

        // Enable interrupts
        ci->control = 0x00000001;

        // Finally install the GIC as the main interrupt handler
        *wrapped_irq_vector = &irq_handler;
}

#define MAX_NO_OF_INTERRUPTS_IMPLEMENTED 128
#define SPURIOUS_INTERRUPT 1023
#define INTERRUPT_MASK 0x000003FF  
#define CPUID_SHIFT    10

static tHandler *IntHandlers[MAX_NO_OF_INTERRUPTS_IMPLEMENTED];

void irq_handler(void) {
    int source, interrupt, raw_interrupt;

    /* service all pending interrupts */
    while (1)
    {
      /* Get the highest priority interrupt */
      raw_interrupt = ci->interrupt_ack;
      source        = raw_interrupt >> CPUID_SHIFT;
      interrupt     = raw_interrupt & INTERRUPT_MASK;

      if (interrupt == SPURIOUS_INTERRUPT) {
        break;
      }

      /* Call the handler function */
      if (IntHandlers[interrupt]) {
        IntHandlers[interrupt](interrupt, source);
      }

      /* Clear the interrupt */
      ci->end_of_interrupt = raw_interrupt;
    }
};


void interrupt_handler_set(int interrupt, tHandler handler)
{
  if (interrupt < 0 || interrupt > MAX_NO_OF_INTERRUPTS_IMPLEMENTED) {
    return;
  }
  IntHandlers[interrupt] = handler;
}

