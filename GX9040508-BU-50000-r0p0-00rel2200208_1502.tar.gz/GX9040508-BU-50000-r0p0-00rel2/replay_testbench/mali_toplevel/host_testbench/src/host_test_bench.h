//----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
// (C) COPYRIGHT 2006 ARM Limited.
// ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
// Filename : $RCSfile$
// Checked In : $Date: 2012-06-06 09:59:08 +0200 (Wed, 06 Jun 2012) $
// Revision : $Revision: 131200 $
//
//----------------------------------------------------------------------------

/**
 * @file host_test_bench.h
 */
#include <stdlib.h>
#include <string.h>
/**/

#ifndef __HOST_TEST_BENCH_H

#define NB_MAX_PP_CORES         8
#define NB_MAX_MMU_CORES        9
#define NB_MAX_L2_CORES         3
#define USE_MMU                 1

struct Mali_core
{
        unsigned long   __mali_phys_addr;

	unsigned long   __mali_phys_addr_gp;

	int             __mali_nb_l2_caches;
	unsigned long   __mali_phys_addr_l2[NB_MAX_L2_CORES];

	int             __mali_nb_gp_cores;
	int             __mali_nb_pp_cores;
	unsigned long   __mali_nb_mmu_cores;

	unsigned long   __mali_phys_addr_pp[NB_MAX_PP_CORES];
	unsigned long   __mali_phys_addr_mmu[NB_MAX_MMU_CORES];
};

struct Mali_core Mali;



/* Size of various registerfiles */
#define MALI_CORE_REGS_SIZE_L2			0x1000
#define MALI_CORE_REGS_SIZE_PP			0x2000
#define MALI_CORE_REGS_SIZE_GP			0x1000
#define MALI_CORE_REGS_SIZE_MMU			0x1000
#define MALI_CORE_REGS_SIZE                    0x30000

/* MALI_L2_REGISTERS */
#define MALI_L2_REG_CMD	                        0x0010
#define MALI_L2_REG_ENABLE                      0x001c


/* MALI_GP_REGISTERS */
#define MALI_GP_REG_CMD                         0x0020
#define MALI_GP_REG_INT_RAWSTAT                 0x0024
#define MALI_GP_REG_INT_CLEAR                   0x0028
#define MALI_GP_REG_INT_STAT                    0x0030

/* MALI_PP_REGISTERS */
#define MALI_PP_REG_MGMT_VERSION                                0x1000
#define MALI_PP_REG_MGMT_CURRENT_REND_LIST_ADDR                 0x1004
#define MALI_PP_REG_MGMT_STATUS                                 0x1008
#define MALI_PP_REG_MGMT_CTRL                                   0x100C
#define MALI_PP_REG_MGMT_INT_RAWSTAT                            0x1020
#define MALI_PP_REG_MGMT_INT_CLEAR                              0x1024
#define MALI_PP_REG_MGMT_INT_MASK                               0x1028
#define MALI_PP_REG_MGMT_INT_STATUS                             0x102C
#define MALI_PP_REG_MGMT_WRITE_BOUNDARY_ENABLE                  0x1040
#define MALI_PP_REG_MGMT_WRITE_BOUNDARY_LOW                     0x1044
#define MALI_PP_REG_MGMT_WRITE_BOUNDARY_HIGH                    0x1048
#define MALI_PP_REG_MGMT_WRITE_BOUNDARY_ADDRESS                 0x104c
#define MALI_PP_REG_MGMT_BUS_ERROR_STATUS			0x1050
#define MALI_PP_REG_MGMT_WATCHDOG_DISABLE			0x1060
#define MALI_PP_REG_MGMT_WATCHDOG_TIMEOUT			0x1064
#define MALI_PP_REG_MGMT_PERF_CNT_0_ENABLE			0x1080
#define MALI_PP_REG_MGMT_PERF_CNT_0_SRC				0x1084
#define MALI_PP_REG_MGMT_PERF_CNT_0_LIMIT			0x1088
#define MALI_PP_REG_MGMT_PERF_CNT_0_VALUE			0x108C
#define MALI_PP_REG_MGMT_PERF_CNT_1_ENABLE			0x10A0
#define MALI_PP_REG_MGMT_PERF_CNT_1_SRC				0x10A4
#define MALI_PP_REG_MGMT_PERF_CNT_1_LIMIT			0x10A8
#define MALI_PP_REG_MGMT_PERF_CNT_1_VALUE			0x10AC
#define MALI_PP_REG_MGMT_DEBUG_0                                0x10E0
#define MALI_PP_REG_MGMT_DEBUG_1                                0x10E4
#define MALI_PP_REG_MGMT_BUILD_DATE                             0x10F0


/** Defines for writeback registers (only Mali200)  **/
#define MALI_PP_REG_WB0_SOURCE_SELECT                  0x0100
#define MALI_PP_REG_WB0_TARGET_ADDR                    0x0104
#define MALI_PP_REG_WB0_TARGET_PIXEL_FORMAT            0x0108
#define MALI_PP_REG_WB0_TARGET_AA_FORMAT               0x010C
#define MALI_PP_REG_WB0_TARGET_LAYOUT                  0x0110
#define MALI_PP_REG_WB0_TARGET_SCANLINE_LENGTH         0x0114
#define MALI_PP_REG_WB0_TARGET_FLAGS                   0x0118
#define MALI_PP_REG_WB0_MRT_COUNT                      0x011c
#define MALI_PP_REG_WB0_MRT_OFFSET                     0x0120
#define MALI_PP_REG_WB0_GLOBAL_TEST_ENABLE             0x0124
#define MALI_PP_REG_WB0_GLOBAL_TEST_REF_VALUE          0x0128
#define MALI_PP_REG_WB0_GLOBAL_TEST_CMP_FUNC           0x012c

#define MALI_PP_REG_WB1_SOURCE_SELECT                  0x0200
#define MALI_PP_REG_WB1_TARGET_ADDR                    0x0204
#define MALI_PP_REG_WB1_TARGET_PIXEL_FORMAT            0x0208
#define MALI_PP_REG_WB1_TARGET_AA_FORMAT               0x020C
#define MALI_PP_REG_WB1_TARGET_LAYOUT                  0x0210
#define MALI_PP_REG_WB1_TARGET_SCANLINE_LENGTH         0x0214
#define MALI_PP_REG_WB1_TARGET_FLAGS                   0x0218
#define MALI_PP_REG_WB1_MRT_COUNT                      0x021c
#define MALI_PP_REG_WB1_MRT_OFFSET                     0x0220
#define MALI_PP_REG_WB1_GLOBAL_TEST_ENABLE             0x0224
#define MALI_PP_REG_WB1_GLOBAL_TEST_REF_VALUE          0x0228
#define MALI_PP_REG_WB1_GLOBAL_TEST_CMP_FUNC           0x022c

#define MALI_PP_REG_WB2_SOURCE_SELECT                  0x0300
#define MALI_PP_REG_WB2_TARGET_ADDR                    0x0304
#define MALI_PP_REG_WB2_TARGET_PIXEL_FORMAT            0x0308
#define MALI_PP_REG_WB2_TARGET_AA_FORMAT               0x030C
#define MALI_PP_REG_WB2_TARGET_LAYOUT                  0x0310
#define MALI_PP_REG_WB2_TARGET_SCANLINE_LENGTH         0x0314
#define MALI_PP_REG_WB2_TARGET_FLAGS                   0x0318
#define MALI_PP_REG_WB2_MRT_COUNT                      0x031c
#define MALI_PP_REG_WB2_MRT_OFFSET                     0x0320
#define MALI_PP_REG_WB2_GLOBAL_TEST_ENABLE             0x0324
#define MALI_PP_REG_WB2_GLOBAL_TEST_REF_VALUE          0x0328
#define MALI_PP_REG_WB2_GLOBAL_TEST_CMP_FUNC           0x032c


/* MALI_MMU_REGISTERS */
#define MALI_MMU_REG_PAGE_TABLE_ADDR    0x0000
#define MALI_MMU_REG_STATUS             0x0004
#define MALI_MMU_REG_CMD_REG            0x0008
#define MALI_MMU_REG_LAST_PFAULT_VADDR  0x000C
#define MALI_MMU_REG_INVALIDATE_PAGE    0x0010
#define MALI_MMU_REG_IRQ_RAW_STAT       0x0014
#define MALI_MMU_REG_IRQ_CLEAR          0x0018
#define MALI_MMU_REG_IRQ_MASK           0x001C
#define MALI_MMU_REG_IRQ_STATUS         0x0020

/* PMU */
#define MALI_PMU_REG_POWER_UP        0x2000
#define MALI_PMU_REG_POWER_DOWN      0x2004
#define MALI_PMU_REG_STATUS          0x2008
#define MALI_PMU_REG_INT_MASK        0x200c
#define MALI_PMU_REG_INT_RAW         0x2010
#define MALI_PMU_REG_INT_STAT        0x2014
#define MALI_PMU_REG_NT_CLEAR        0x2018
#define MALI_PMU_REG_SW_DELAY        0x201c
#define MALI_PMU_REG_MASTER_PWR_UP   0x2024

/* Broadcast */
#define MALI_BROADCAST_REG_MASK       0x13000
#define MALI_BROADCAST_REG_IRQ_MASK   0x13004

/* Various core-types */
#define MALI_CORE_TYPE_PP	0x0
#define MALI_CORE_TYPE_GP	0x1
#define MALI_CORE_TYPE_MMU	0x2
#define MALI_CORE_TYPE_L2	0x3
#define MALI_ORIGINAL_REG_MAP    0x4

/* Other defines */
#define WAIT_CYCLES_USLEEP	1
#define WAIT_IRQ_USLEEP         1000

/* Types */
typedef volatile void * (* get_mem_area_func)(unsigned long, unsigned long); /**< (phys_addr, area_size) **/
typedef void (* usleep_func)(unsigned long); /**< (sleep_time) **/
typedef void (* irq_callback_func)(unsigned long, unsigned long); /**< (coretype, rawstat) **/

typedef struct {
	unsigned long regnum;
	unsigned long value;
} register_struct;

typedef struct {
	unsigned long mali_mem_start;
	unsigned long size;
	unsigned long *data;
} dump_struct;

typedef struct {
	unsigned long core_num;
	unsigned long ctrl_reg_value;
	unsigned char done;  				/**< Status-flag used internally **/
	unsigned long rawstat_mask;  		/**< This is masked on the RAWSTAT-register **/
	unsigned long rawstat_value; 		/**< This is compared to the result from the above mask **/
} core_start_struct;

/* The remap-area needs to be aligned with pagesize, and located within mali-mem */
typedef struct {
	unsigned long remap_area_to;		/**< "Fake"-address to remap **/
	unsigned long remap_area_from;		/**< Where is it really located, this have to be somewhere in mali-mem **/
} remap_area_struct;

/**
 * Enable PMU.
 */
int enable_pmu( unsigned long pmu );

/**
 * Set the function-pointer to get a specific memory area.
 */
int set_func_get_mem_area( get_mem_area_func __get_mem_area );

/**
 * Set the function-pointer to get usleep-functionality in library
 */
int set_func_usleep( usleep_func __usleep );

/**
 * Set the function-pointer to use for irq-callback (rawstat-reads9
 */
int set_func_irq_callback( irq_callback_func __irq_cb );

/**
 * Set physical address for where to find mali-addressable
 * memory.
 */
int set_phys_addr_mali_mem(unsigned long phys_addr);

/** 
 * Set physical address for where to find the mali mmu table
 */
int set_phys_addr_mali_mmu_table(unsigned long phys_addr);


/**
 * Set size of malimem
 */
int set_mali_mem_info(unsigned long mali_mem, unsigned long pagesize);

/**
 * Set number of pp-cores
 */
int set_num_cores_pp(unsigned char num_cores);

/**
 * Set number of gp-cores
 */
int set_num_cores_gp(unsigned num_cores);

/**
 * Set physical address for where to find registers to
 * control mali L2.
 */
int set_phys_addr_core_regs_l2(unsigned core_num, unsigned long phys_addr);

/**
 * Set physical address for where to find Mali.
 */
int set_phys_addr_mali(unsigned long phys_addr);

/**
 * Set physical address for where to find registers to
 * control mali PP.
 */
int set_phys_addr_core_regs_pp(unsigned core_num, unsigned long phys_addr);

/**
 * Set physical address for where to find registers to
 * control mali GP
 */
int set_phys_addr_core_regs_gp(unsigned long core_num, unsigned long phys_addr);

/**
 * Set interrupt-received-status for GP-core
 */
int set_interrupt_received_gp(unsigned long core_num);

/**
 * Set interrupt-received-status for PP-core
 */
int set_interrupt_received_pp(unsigned long core_num);

/**
 * Add a remapping-area. This needs to be done *before* configuring the
 * mmu.  The area needs to be within mali-mem, and area_remap_from-address
 * needs to be on a pagesize-boundry.  This is just a mmu-trick so that each
 * entry in the remapping-table will give one or more pages in the "ordinary"
 * table another pointer from a different location in "real" mali-address-space.
 */
int add_remapping_area(unsigned long area_remap_to, unsigned long area_remap_from);

int set_mmu_table(unsigned long mmu_offset);

/**
 * If you want the library to configure the mmu, in most
 * cases this is what you want. However, if you're running
 * with a mali-devicedriver that already setup the mmu
 * you don't need to call this function.
 */
//int configure_mmu(unsigned long core_num, unsigned long mmu_offset);
int configure_mmu(unsigned long core_num);

/**
 * Set physical address for where to find registers to
 * control MMU
 */
int set_phys_addr_core_regs_mmu(unsigned long core_num, unsigned long phys_addr);

/**
 * Load mem_data into mali-accessible memory.
 */
int mali_load_data(unsigned long mali_mem_start, unsigned long size, void *mem_data);

/**
 * Write core_num's [which is of core_type] regnum with regvalue.
 * @param regnum
 */
int mali_writereg(unsigned long core_type, unsigned long core_num, unsigned long regnum, unsigned long regvalue);

/**
 * Read core_num's [which is of core_type] regnum.
 * @param regnum
 */
int mali_readreg(unsigned long core_type, unsigned long core_num, unsigned long regnum, unsigned long *regvalue);

/**
 * Wait for cycles, and return
 */
int mali_wait_cycles(unsigned long cycles);

/**
 * Wait for irq (or specified timeout, if nonzero), run callback-function (if set)
 * and return.  If num_cores_running is nonzero, it'll loop until all cores have
 * generated irq (or, again, if it reaches specified nonzero timeout).
 * @NOTE This function will read RAWSTAT, if you want to check by using actual
 *       interrupts, you need to implement that yourself.
 */
int mali_wait_irq_by_rawstat(unsigned long max_core_wait_timeout_ms, unsigned long num_cores_running);

/**
 * same as rawstat (above), but poll status register in stead 
 */
int mali_wait_irq_by_intstat(unsigned long max_core_wait_timeout_ms, unsigned long num_cores_running);

/**
 * Wait for irq (specified by irqmask) on specified core(s).
 * @NOTE This function will read RAWSTAT, if you want to check by using actual
 *       interrupts, you need to implement that yourself.
 */
int mali_wait_irqmask(unsigned long max_core_wait_timeout_ms, unsigned long irq_mask, unsigned long core_mask);

/**
 * Returns mali_mem-region.
 * @NOTE buffer needs to be of at least specified size.
 */
int mali_read_mali_mem(unsigned long addr, unsigned long size, unsigned char *buffer);

/**
 * Compares mali_mem-data with data pointed to by original_data.
 * @return Integer less than, equal to, or greater than zero based
 *         on mali_mem <,==,> original_data.
 */
int mali_mem_compare(unsigned long mali_mem_start_addr, unsigned long size, void * original_data);

/**
 * Compares two sets of mali_mem-data.
 * @return Integer less than, equal to, or greater than zero based on
 *         new_mali_mem <, ==, > original_mali_mem.
 */
int mali_mem_compare_mali_regions( unsigned long mali_mem_original_start_addr, unsigned long mali_mem_new_start_addr, unsigned long size );

/**
 * Fill memory region with value.
 */
void mali_mem_set_region(unsigned long mali_mem_start_addr, unsigned long size, unsigned int fill_value);



#endif /* __HOST_TEST_BENCH_H */

