//----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
// (C) COPYRIGHT 2006 ARM Limited.
// ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
// Filename : $RCSfile$
// Checked In : $Date: 2012-06-06 09:59:08 +0200 (Wed, 06 Jun 2012) $
// Revision : $Revision: 131200 $
//
//----------------------------------------------------------------------------

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include "host_test_bench.h"

/* Types */
/* (phys_addr, area_size) */
//typedef volatile void * (* get_mem_area_func)(unsigned long, unsigned long);
//typedef void (* usleep_func)(unsigned long);

/* statics */
static get_mem_area_func __get_mem_ptr;
static usleep_func __internal_usleep;
static irq_callback_func __irq_rawstat_callback_ptr;
static unsigned long __phys_addr_mali_mem = 0;
static unsigned long __mali_mem_size = 0;
static unsigned long __mali_mem_pagesize = 0;
static unsigned long __mali_mem_pagesize_bits = 0; /* this is calc. by lib */
static volatile void * __mali_mem_ptr;
static unsigned long __mali_pmu = 0;

/* Mali parameters */
static unsigned long __phys_addr_mali = 0;
static unsigned long __mali_core_regs_size = MALI_CORE_REGS_SIZE; /* FEATURE: This could be configurable through API */
static unsigned long *__mali_core_regs_ptr;

/* L2 cache parameters */
static unsigned long __phys_addr_core_regs_l2[NB_MAX_L2_CORES] = {0, 0, 0};;
static unsigned long __mali_core_regs_size_l2 = MALI_CORE_REGS_SIZE_L2; /* FEATURE: This could be configurable through API */
static unsigned long *__mali_core_regs_ptr_l2[NB_MAX_L2_CORES];

/* PP-cores specific statics */
static unsigned long __phys_addr_core_regs_pp[NB_MAX_PP_CORES] = {0, 0, 0, 0};
static unsigned long __mali_core_interrupt_pp[NB_MAX_PP_CORES] = {0, 0, 0, 0};
static unsigned long __mali_core_regs_size_pp = MALI_CORE_REGS_SIZE_PP; /* FEATURE: This could be configurable through API */
static unsigned long *__mali_core_regs_ptr_pp[NB_MAX_PP_CORES];

/* Pointer to registers/settings for gp-cores */
static unsigned long __phys_addr_core_regs_gp[1] = { 0 };
static unsigned long __mali_core_interrupt_gp[1] = { 0 };
static unsigned long __mali_core_regs_size_gp = MALI_CORE_REGS_SIZE_GP; /* FEATURE: This could be configurable through API */
static unsigned long *__mali_core_regs_ptr_gp[1];

/* Pointer to registers/settings for mmu */
static unsigned long *__mali_core_regs_ptr_mmu[NB_MAX_MMU_CORES];
static unsigned long __mali_core_regs_size_mmu = MALI_CORE_REGS_SIZE_MMU; /* FEATURE: This could be configurable through API */
static unsigned long __phys_addr_core_regs_mmu[NB_MAX_MMU_CORES] = {0, 0, 0, 0, 0}; /* MMU-registers */

static unsigned long __phys_addr_mali_mmu_table = 0; /* MMU-table */
static unsigned long __num_remap_areas = 0; /* Number of "outside" areas remapped inside reg. mali_mem-area */
static remap_area_struct *__remap_areas;  /* Holds the remap areas to be added by configure_mmu() */

/**
 * Enable PMU.
 */
int enable_pmu( unsigned long pmu )
{
    __mali_pmu = pmu;
    return 0;
}

/**
 * Set the function-pointer to get a specific memory area.
 */
int set_func_get_mem_area( get_mem_area_func __get_mem_area )
{
    __get_mem_ptr = __get_mem_area;
    return 0;
}

/**
 * Set the function-pointer to get usleep-functionality in library
 */
int set_func_usleep( usleep_func __usleep )
{
    __internal_usleep = __usleep;
    return 0;
}

/**
 * Set the function-pointer to use for irq-callback (rawstat-reads9
 */
int set_func_irq_callback( irq_callback_func __irq_cb )
{
    __irq_rawstat_callback_ptr = __irq_cb;
    return 0;
}

/**
 * Set physical address for where to find mali-addressable
 * memory.
 */
int set_phys_addr_mali_mem(unsigned long phys_addr)
{
    __phys_addr_mali_mem = phys_addr;
    return 0;
}

/**
 * Set size of malimem and pagesize
 */
int set_mali_mem_info(unsigned long mali_mem, unsigned long pagesize)
{
     unsigned tmp;

     __mali_mem_size = mali_mem;
     __mali_mem_pagesize = pagesize;

     __mali_mem_pagesize_bits = 0;
     tmp=pagesize;
     while (tmp)
     {
         __mali_mem_pagesize_bits++;
         tmp = tmp>>1;
     }
     if (__mali_mem_pagesize_bits >0)
         __mali_mem_pagesize_bits--;

     return 0;
}


int set_phys_addr_core_regs_l2(unsigned core_num, unsigned long phys_addr)
{
    __phys_addr_core_regs_l2[core_num] = phys_addr;

    return 0;
}

/**
 * Set physical address for where to find Mali.
 */
int set_phys_addr_mali(unsigned long phys_addr)
{
    __phys_addr_mali  = phys_addr;

    return 0;
}

/**
 * Set physical address for where to find registers to
 * control mali PP.
 */
int set_phys_addr_core_regs_pp(unsigned core_num, unsigned long phys_addr)
{
//    assert( core_num < Mali.__mali_nb_pp_cores );
    __phys_addr_core_regs_pp[core_num] = phys_addr;

    return 0;
}

/**
 * Set physical address for where to find registers to
 * control mali GP
 */
int set_phys_addr_core_regs_gp(unsigned long core_num, unsigned long phys_addr)
{
    assert( core_num < Mali.__mali_nb_pp_cores );
    __phys_addr_core_regs_gp[core_num] = phys_addr;

    return 0;
}

/**
 * Set physical address for where to find registers to
 * control MMU
 */
int set_phys_addr_core_regs_mmu(unsigned long core_num, unsigned long phys_addr)
{
    __phys_addr_core_regs_mmu[core_num] = phys_addr;
//    __phys_addr_core_regs_mmu = phys_addr;
    return 0;
}

/**
 * Set physical address for where to set the MMU-table
 */
int set_phys_addr_mali_mmu_table(unsigned long phys_addr)
{
    __phys_addr_mali_mmu_table = phys_addr;
    return 0;
}

/**
 * Set interrupt-received-status for GP-core
 */
int set_interrupt_received_gp(unsigned long core_num)
{
    assert( core_num < Mali.__mali_nb_gp_cores );

    __mali_core_interrupt_gp[core_num] = 1;

    return 0;
}

/**
 * Set interrupt-received-status for PP-core
 */
int set_interrupt_received_pp(unsigned long core_num)
{
    assert( core_num < Mali.__mali_nb_pp_cores );

    __mali_core_interrupt_pp[core_num] = 1;

    return 0;
}

/**
 * Add a remapping-area. This needs to be done *before* configuring the
 * mmu.
 */
int add_remapping_area(unsigned long area_remap_to, unsigned long area_remap_from)
{
    remap_area_struct *tmp;

    /* area_remap_from have to be located within mali_mem */
    assert( area_remap_from >= __phys_addr_mali_mem );
    assert( area_remap_from < (__phys_addr_mali_mem + __mali_mem_size) );

    __num_remap_areas++;

    tmp = (remap_area_struct *) realloc(__remap_areas, __num_remap_areas * sizeof(remap_area_struct));
    if (tmp == NULL)
    {
        return 1;
    }

    /* realloc was successfull */
    __remap_areas = tmp;

    __remap_areas[__num_remap_areas-1].remap_area_to = area_remap_to;
    __remap_areas[__num_remap_areas-1].remap_area_from = area_remap_from;

    return 0;
}


int set_mmu_table(unsigned long mmu_offset)
{
    unsigned long page_entries;
    unsigned long level2_entries;
    unsigned long level1_entries;
    unsigned long page_table_size;

    unsigned long *page_ptr;
    unsigned long *level1_ptr;
    unsigned long *level2_ptr;
    unsigned long level2_addr;
    unsigned long page_addr;
    unsigned long counter;

    unsigned long cur_dte_idx;
//    unsigned long cur_pte_idx;
    unsigned long offset_start;
    unsigned long offset_stop;

    assert( __mali_mem_size  );
    assert( __get_mem_ptr != NULL );
    assert( __mali_mem_pagesize );
    assert( __mali_mem_pagesize_bits );

    offset_start = mmu_offset & 0xFFC00000;
    offset_stop = (mmu_offset + __mali_mem_size) & 0xFFC00000;

    page_entries = (mmu_offset + __mali_mem_size) >> __mali_mem_pagesize_bits;
    level2_entries = (page_entries+1023)/1024; /* Number page_tbl2_blocks */
    level1_entries = (level2_entries+1023)/1024; /* Number page_tbl1_blocks -- current MMU => 1 */
    page_table_size = (level2_entries+level1_entries) * __mali_mem_pagesize;

    page_ptr = (unsigned long *) __get_mem_ptr(__phys_addr_mali_mmu_table, page_table_size);
    assert( page_ptr != NULL );
    memset(page_ptr, 0, page_table_size / 4);

    /* DTE-table */
    level1_ptr = page_ptr;
    level2_addr = __phys_addr_mali_mmu_table + (level1_entries * __mali_mem_pagesize);
    counter = level2_entries;
    while(counter--)
    {
        cur_dte_idx = ((unsigned long)level1_ptr - __phys_addr_mali_mmu_table) & 0xFFC00000;
        /* Only fill matching DTE-entries */
        if ((cur_dte_idx >= offset_start) || (cur_dte_idx <= offset_stop))
        {
            *level1_ptr++ = level2_addr | 0x1;
            level2_addr += __mali_mem_pagesize;
        }
		/*
        else
        {
            *level1_ptr++;
        } 
		*/
    }

    /* If we have any remappings, add those to correct index in DTE-table as well*/
    if (__num_remap_areas)
    {
        counter = __num_remap_areas;
        while (counter--)
        {
            page_ptr[__remap_areas[counter].remap_area_to >> 22] =
                    __phys_addr_mali_mmu_table + (level1_entries * __mali_mem_pagesize) +
                    ( __mali_mem_pagesize * (__remap_areas[counter].remap_area_from >> 22) );
        }
    }

    /* PTE-table */
    level2_ptr = (unsigned long *) ((unsigned long)page_ptr + (level1_entries * __mali_mem_pagesize)) ;
    page_addr = __phys_addr_mali_mem;
    counter = page_entries;
    while(counter--)
    {
        cur_dte_idx = ((unsigned long)level2_ptr - __phys_addr_mali_mmu_table - (level1_entries * __mali_mem_pagesize)) & 0xFFC00000;
        /* Only fill matching PTE-entries */
        if ((cur_dte_idx >= offset_start) || (cur_dte_idx <= offset_stop))
        {
            *level2_ptr++ = page_addr | 0x7;
            page_addr += __mali_mem_pagesize;
        }
		/*
        else
        {
            *level1_ptr++;
        }
		*/
    }

	return 0;
}



/**
 * If you want the library to configure the mmu, in most
 * cases this is what you want. However, if you're running
 * with a mali-devicedriver that already setup the mmu
 * you don't need to call this function.
 *
 * This configures the MMU#core_num
 */
int configure_mmu(unsigned long core_num)
{
    /* Set MMU-registers */
    mali_writereg(MALI_CORE_TYPE_MMU, core_num, MALI_MMU_REG_PAGE_TABLE_ADDR, __phys_addr_mali_mmu_table);
    mali_writereg(MALI_CORE_TYPE_MMU, core_num, MALI_MMU_REG_CMD_REG, 0); /* Enable MMU */
    mali_writereg(MALI_CORE_TYPE_MMU, core_num, MALI_MMU_REG_IRQ_CLEAR, 0x3);

    return 0;
}


int mali_load_data(unsigned long mali_mem_start, unsigned long size, void *mem_data)
{
    assert( __mali_mem_size );
    assert( __get_mem_ptr != NULL );

    /* Initialize mali_mem_ptr if not done already */
	if (__mali_mem_ptr == NULL)
	{
		__mali_mem_ptr = (unsigned long *) __get_mem_ptr(__phys_addr_mali_mem, __mali_mem_size);
	}
	assert( __mali_mem_ptr != NULL );

    /* Load all memory regions */
    memcpy( ((unsigned char *)__mali_mem_ptr) + mali_mem_start, mem_data, size);

    return 0;
}

/**
 * Write core_num's [which is of core_type] regnum with regvalue.
 * @param regnum
 */
int mali_writereg(unsigned long core_type,
                unsigned long core_num,
                unsigned long regnum,
                unsigned long regvalue)
{
    unsigned long *phys_reg_addr;
    

    switch (core_type)
    {
        case MALI_CORE_TYPE_L2:
            /* Get reg-pointer, if not there already */
            if (__mali_core_regs_ptr_l2[core_num] == NULL)
            {
                __mali_core_regs_ptr_l2[core_num] = (unsigned long *) __get_mem_ptr(__phys_addr_core_regs_l2[core_num], __mali_core_regs_size_l2);
            }
            phys_reg_addr = __mali_core_regs_ptr_l2[core_num];
        break;

        case MALI_CORE_TYPE_PP:
            /* Get reg-pointer, if not there already */
            if (__mali_core_regs_ptr_pp[core_num] == NULL)
            {
                __mali_core_regs_ptr_pp[core_num] = (unsigned long *) __get_mem_ptr(__phys_addr_core_regs_pp[core_num], __mali_core_regs_size_pp);
            }

            phys_reg_addr = __mali_core_regs_ptr_pp[core_num];
        break;

        case MALI_CORE_TYPE_GP:
            /* Get reg-pointer, if not there already */
            if (__mali_core_regs_ptr_gp[core_num] == NULL)
            {
                __mali_core_regs_ptr_gp[core_num] = (unsigned long *) __get_mem_ptr(__phys_addr_core_regs_gp[core_num], __mali_core_regs_size_gp);
            }

            phys_reg_addr = __mali_core_regs_ptr_gp[core_num];
        break;

        case MALI_CORE_TYPE_MMU:
            /* Get reg-pointer, if not there already */
            if (__mali_core_regs_ptr_mmu[core_num] == NULL)
            {
                __mali_core_regs_ptr_mmu[core_num] = (unsigned long *) __get_mem_ptr(__phys_addr_core_regs_mmu[core_num], __mali_core_regs_size_mmu);
            }

            phys_reg_addr = __mali_core_regs_ptr_mmu[core_num];
        break;

        case MALI_ORIGINAL_REG_MAP:
            /* Get reg-pointer, if not there already */
            if (__mali_core_regs_ptr == NULL)
            {
                 __mali_core_regs_ptr = (unsigned long *) __get_mem_ptr(__phys_addr_mali, __mali_core_regs_size);
            }
            
            phys_reg_addr = __mali_core_regs_ptr;
        break;

        default:
            assert( ! "Unknown core_type, aborting..." );
        break;
    }

    /* Set actual register */
    phys_reg_addr = phys_reg_addr + (regnum>>2);
    memcpy( (void *) phys_reg_addr, &regvalue, 4); /* all registers are 32bits */

    return 0;
}

/**
 * Read core_num's [which is of core_type] regnum.
 * @param regnum
 */
int mali_readreg(unsigned long core_type,
                unsigned long core_num,
                unsigned long regnum,
                unsigned long *regvalue)
{
    unsigned long *phys_reg_addr;

    switch (core_type)
    {
        case MALI_CORE_TYPE_L2:
            /* Get reg-pointer, if not there already */
            if (__mali_core_regs_ptr_l2 == NULL)
            {
                __mali_core_regs_ptr_l2[core_num] = (unsigned long *) __get_mem_ptr(__phys_addr_core_regs_l2[core_num], __mali_core_regs_size_l2);
            }
            phys_reg_addr = __mali_core_regs_ptr_l2[core_num];
        break;

        case MALI_CORE_TYPE_PP:
            /* Get reg-pointer, if not there already */
            if (__mali_core_regs_ptr_pp[core_num] == NULL)
            {
                __mali_core_regs_ptr_pp[core_num] = (unsigned long *) __get_mem_ptr(__phys_addr_core_regs_pp[core_num], __mali_core_regs_size_pp);
            }

            phys_reg_addr = __mali_core_regs_ptr_pp[core_num];
        break;

        case MALI_CORE_TYPE_GP:
            /* Get reg-pointer, if not there already */
            if (__mali_core_regs_ptr_gp[core_num] == NULL)
            {
                __mali_core_regs_ptr_gp[core_num] = (unsigned long *) __get_mem_ptr(__phys_addr_core_regs_gp[core_num], __mali_core_regs_size_gp);
            }

            phys_reg_addr = __mali_core_regs_ptr_gp[core_num];
        break;

        case MALI_CORE_TYPE_MMU:
            /* Get reg-pointer, if not there already */
            if (__mali_core_regs_ptr_mmu[core_num] == NULL)
            {
                __mali_core_regs_ptr_mmu[core_num] = (unsigned long *) __get_mem_ptr(__phys_addr_core_regs_mmu[core_num], __mali_core_regs_size_mmu);
            }

            phys_reg_addr = __mali_core_regs_ptr_mmu[core_num];
        break;

        case MALI_ORIGINAL_REG_MAP:
            /* Get reg-pointer, if not there already */
            if (__mali_core_regs_ptr == NULL)
            {
                 __mali_core_regs_ptr = (unsigned long *) __get_mem_ptr(__phys_addr_mali, __mali_core_regs_size);
            }

            phys_reg_addr = __mali_core_regs_ptr;

        break;

        default:
            assert( ! "Unknown core_type, aborting..." );
        break;
    }

    /* Get actual register */
    phys_reg_addr = phys_reg_addr + (regnum>>2);
    memcpy( regvalue, (void *) phys_reg_addr, 4); /* all registers are 32bits */

    return 0;
}

/**
 * Wait for cycles, and return
 */
int mali_wait_cycles(unsigned long cycles)
{
    assert( __internal_usleep != NULL );

    __internal_usleep(cycles * WAIT_CYCLES_USLEEP);

    return 0;
}

/**
 * Wait for irq (or specified timeout, if nonzero), run callback-function (if set)
 * and return.  If num_cores_running is nonzero, it'll loop until all cores have
 * generated irq (or, again, if it reaches specified nonzero timeout).
 */
int mali_wait_irq_by_intstat(unsigned long max_core_wait_timeout_ms,
                unsigned long num_cores_running)
{
    unsigned long cur_wait_us;
    unsigned long regvalue;
    unsigned long core_num;
    unsigned long got_irq = 0;
    unsigned long broadcast_irq_mask;
    unsigned long pp_irq = 0;

    // Get broadcast mask to know which PPs to wait for.
    mali_readreg(MALI_ORIGINAL_REG_MAP, 0, MALI_BROADCAST_REG_IRQ_MASK, &broadcast_irq_mask);

    cur_wait_us = 0;

    /* All cores started, check for done... */
    while (((cur_wait_us / 1000) < max_core_wait_timeout_ms) && !got_irq)
    {
        /* Check MMU-core for IRQ */
        for (core_num = 0; core_num < Mali.__mali_nb_mmu_cores; core_num++)
        {
            mali_readreg(MALI_CORE_TYPE_GP, core_num, MALI_MMU_REG_IRQ_STATUS, &regvalue);
            if (regvalue != 0)
            {
                __irq_rawstat_callback_ptr(MALI_CORE_TYPE_MMU, regvalue);
                got_irq = 1;
                break;
	    }
	}

        /* Check GP-cores for IRQ */
        for (core_num = 0; core_num < Mali.__mali_nb_gp_cores; core_num++)
        {
            mali_readreg(MALI_CORE_TYPE_GP, core_num, MALI_GP_REG_INT_STAT, &regvalue);
            if (regvalue != 0)
            {
                __irq_rawstat_callback_ptr(MALI_CORE_TYPE_GP, regvalue);
                got_irq = 1;
                break;
            }
        }

         /* Check PMU for IRQ */
        if (__mali_pmu)
        {
            mali_readreg(MALI_ORIGINAL_REG_MAP, core_num, MALI_PMU_REG_INT_STAT, &regvalue);
            if (regvalue != 0)
            {
                __irq_rawstat_callback_ptr(MALI_ORIGINAL_REG_MAP, regvalue);
                got_irq = 1;
                break;
            }
        }

        /* Check PP-cores for IRQ */
        for (core_num = 0; core_num < Mali.__mali_nb_pp_cores; core_num++)
        {   
            mali_readreg(MALI_CORE_TYPE_PP, core_num, MALI_PP_REG_MGMT_INT_STATUS, &regvalue);
            if (regvalue != 0)
            {
                if (broadcast_irq_mask) {
                  // Gather IRQ status for all PP cores.
                  pp_irq = pp_irq | (0x00000001 << core_num);
                }
                else {
                  got_irq = 1;
                  __irq_rawstat_callback_ptr(MALI_CORE_TYPE_PP, regvalue);
                  break;
                }
            }
        }

        /* */
        cur_wait_us += WAIT_IRQ_USLEEP;
        __internal_usleep(WAIT_IRQ_USLEEP);
	if (broadcast_irq_mask && (pp_irq == broadcast_irq_mask)) {
          got_irq = 1;
          __irq_rawstat_callback_ptr(MALI_CORE_TYPE_PP, regvalue);
        }
    }

    return cur_wait_us;

}

/**
 * Wait for irq (specified by irqmask) on specified core(s). It will abort
 * if it reaches max_core_wait_timeout_ms before any irq is triggered.
 */
int mali_wait_irqmask(unsigned long max_core_wait_timeout_ms, unsigned long irq_mask, unsigned long core_mask)
{
    unsigned long cur_wait_us;
    unsigned long regvalue;
    unsigned long counter;
    unsigned long core_num;
    unsigned long irq_hit;


#define MMU_MASK      0x01000000
#define MMU_SHR       24

#define GP_MASK       0x00ff0000
#define GP_SHR        16

#define PP_MASK       0x0000ffff
#define PP_SHR        0

#define PMU_MASK      0x00020000
#define PMU_SHR       17

    /* All cores started, check for done... */
    cur_wait_us = 0;
    irq_hit = 0;
    while ((cur_wait_us / 1000) < max_core_wait_timeout_ms)
    {
        /* Check MMU-core for IRQ */
       for (core_num = 0; core_num < Mali.__mali_nb_mmu_cores; core_num++)
        {
			if (__mali_core_regs_ptr_mmu[core_num] && ((core_mask & MMU_MASK) >> MMU_SHR) )
			{
				memcpy(&regvalue, (void *) (__mali_core_regs_ptr_mmu[core_num] + (MALI_MMU_REG_IRQ_STATUS >> 2)), 4);

				if ( regvalue != 0 ) irq_hit |= 1 << (core_num + MMU_SHR);
			}
		}

        /* Check GP-cores for IRQ */
        for (counter = 0; counter < Mali.__mali_nb_gp_cores; counter++)
        {
            if (((1<<counter) & ((irq_mask & GP_MASK) >> GP_SHR)) > 0)
            {
                /* Core selected for check... */
                memcpy(&regvalue, (void *) (__mali_core_regs_ptr_gp[counter] + (MALI_GP_REG_INT_STAT >> 2)), 4);

				if ( regvalue != 0 ) irq_hit |= 1 << (counter + GP_SHR);
            }
        }

         /* Check PMU for IRQ */
        if (__mali_pmu){
            mali_readreg(MALI_ORIGINAL_REG_MAP, 0, MALI_PMU_REG_INT_STAT, &regvalue);
            if ((regvalue & PMU_MASK)!= 0)
                irq_hit |= 1 << PMU_SHR;
        }


        /* Check PP-cores for IRQ */
        for (counter = 0; counter < Mali.__mali_nb_pp_cores; counter++)
        {
            if (((1<<counter) & ((irq_mask & PP_MASK) >> PP_SHR)) > 0)
            {
                memcpy(&regvalue, (void *) (__mali_core_regs_ptr_pp[counter] + (MALI_PP_REG_MGMT_INT_STATUS >> 2)), 4);

				if ( regvalue != 0 ) irq_hit |= 1 << (counter + PP_SHR);
            }
        }

        /* Have all the cores we want trigged an interrupt? */
        if ( irq_hit != 0 && core_mask == 0 ) return 0;
		else if ( irq_hit == core_mask && core_mask != 0 ) return 0;

        /* */
        cur_wait_us += WAIT_IRQ_USLEEP;
        __internal_usleep(WAIT_IRQ_USLEEP);
    }

    return cur_wait_us;
}


/**
 * Returns mali_mem-region.
 * @NOTE buffer needs to be of at least specified size.
 */
int mali_read_mali_mem(unsigned long addr, unsigned long size, unsigned char *buffer)
{
    assert( __mali_mem_size );
    assert( __get_mem_ptr != NULL );

    /* Initialize mali_mem_ptr if not done already */
    if (__mali_mem_ptr == NULL)
    {
        __mali_mem_ptr = (unsigned long *) __get_mem_ptr(__phys_addr_mali_mem, __mali_mem_size);
    }
    assert( __mali_mem_ptr != NULL );
    assert( buffer != NULL );

    memcpy(buffer, (void *) ((unsigned long)__mali_mem_ptr + addr), size);

    return size;
}

/**
 * Compares mali_mem-data with data pointed to by original_data.
 * @return Integer less than, equal to, or greater than zero based
 *         on mali_mem <,==,> original_data.
 */
int mali_mem_compare(unsigned long mali_mem_start_addr,
                unsigned long size,
                void * original_data)
{
    assert( __mali_mem_size );
    assert( __get_mem_ptr != NULL );

    /* Initialize mali_mem_ptr if not done already */
    if (__mali_mem_ptr == NULL)
    {
        __mali_mem_ptr = (unsigned long *) __get_mem_ptr(__phys_addr_mali_mem, __mali_mem_size);
    }
    assert( __mali_mem_ptr != NULL );
    assert( original_data != NULL );

    return memcmp( ((unsigned char*) __mali_mem_ptr + mali_mem_start_addr), original_data, size);
}

/**
 * Compares two sets of mali_mem-data.
 * @return Integer less than, equal to, or greater than zero based on
 *         new_mali_mem <, ==, > original_mali_mem.
 */
int mali_mem_compare_mali_regions( unsigned long mali_mem_original_start_addr,
                unsigned long mali_mem_new_start_addr,
                unsigned long size )
{
    assert( __mali_mem_size );
    assert( __get_mem_ptr != NULL );

    /* Initialize mali_mem_ptr if not done already */
    if (__mali_mem_ptr == NULL)
    {
        __mali_mem_ptr = (unsigned long *) __get_mem_ptr(__phys_addr_mali_mem, __mali_mem_size);
    }
    assert( __mali_mem_ptr != NULL );

    return memcmp( ((unsigned char*) __mali_mem_ptr + mali_mem_new_start_addr),
                   ((unsigned char*) __mali_mem_ptr + mali_mem_original_start_addr),
                    size);
}

/**
 * Fill memory region with value.
 */
void mali_mem_set_region(unsigned long mali_mem_start_addr,
                unsigned long size,
                unsigned int fill_value)
{
    assert( __mali_mem_size );
    assert( __get_mem_ptr != NULL );

    /* Initialize mali_mem_ptr if not done already */
    if (__mali_mem_ptr == NULL)
    {
        __mali_mem_ptr = (unsigned long *) __get_mem_ptr(__phys_addr_mali_mem, __mali_mem_size);
    }
    assert( __mali_mem_ptr != NULL );

    memset( ((unsigned char*) __mali_mem_ptr + mali_mem_start_addr), fill_value, size);
}

