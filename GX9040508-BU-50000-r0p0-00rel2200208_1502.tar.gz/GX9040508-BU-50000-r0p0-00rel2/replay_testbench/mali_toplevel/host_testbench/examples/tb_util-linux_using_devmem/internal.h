//----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
// (C) COPYRIGHT 2006 ARM Limited.
// ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
// Checked In : $Date: 2008-09-25 15:04:59 +0200 (Thu, 25 Sep 2008) $
// Revision : $Revision: 66744 $
//
//----------------------------------------------------------------------------

#include "tb_util.h"

#ifndef __INTERNAL_H
#define __INTERNAL_H

#define _INTERNAL_STR_TRUE      "TRUE"
#define _INTERNAL_STR_FALSE     "FALSE"

mali_error_code _internal_parse_arg_int(char*buf_in, char**buf_out, unsigned long *val_out, unsigned int base, unsigned int align_mask);
mali_error_code _internal_parse_arg_str(char*buf_in, char**buf_out, char **val_out);
mali_error_code _internal_parse_arg_redirect(char *buf_in, char **buf_out, char **filename_out, int *append);
mali_error_code _internal_parse_dump_line(char *line, unsigned long *mem_addr, unsigned long *words, unsigned long *mask);
int _internal_dump_write_line(char *buf_in, char **buf_out, unsigned long mem_addr, unsigned long *values, unsigned long mask);

#endif //__INTERNAL_H

