//----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
// (C) COPYRIGHT 2006 ARM Limited.
// ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
// Checked In : $Date: 2012-06-06 09:59:08 +0200 (Wed, 06 Jun 2012) $
// Revision : $Revision: 131200 $
//
//----------------------------------------------------------------------------

#include <stdio.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <assert.h>
#include <string.h>
#include <strings.h>

//#include <sys/ioctl.h>
//#include <errno.h>
//#include <string.h>
//#include <ctype.h>

#include <host_test_bench.h>


#include "tb_util.h"
#include "backend.h"

#include <time.h>
#include <unistd.h>



#define LINUX_DEV_MEM "/dev/mem"

#define MALI_MEM_PAGESIZE           4096

// Mali core type
unsigned int	mali_design					= M450; //Default to MALI450, set later to what user specifices with -c. 

unsigned long __mali_mem_size               = MALI_MEM_SIZE;
unsigned long __mali_phys_addr_mem          = MALI_MEM_PHYS_ADDR;  /* 384MB SDRAM; @ 0xc0200000 for EB, 0xc8000000 for PB11MPCore */
unsigned long __mali_phys_addr_mmu_table    = MALI_MMU_TABLE_ADDR;

//Common addresses
unsigned long __mali_core_phys_base_addr	= 0xfc040000;

// Mali200
unsigned long __mali200_offset_phys_addr_pp        = 0x00000000;
unsigned long __mali200_offset_phys_addr_gp        = 0x00002000;
unsigned long __mali200_offset_phys_addr_mmu       = 0x00003000;

// Mali400 / Mali300
unsigned long __offset_phys_addr_gp        = 0x00000000;
unsigned long __offset_phys_addr_l2        = 0x00001000;
unsigned long __offset_phys_addr_mmu_gp    = 0x00003000;
unsigned long __offset_phys_addr_mmu_pp0   = 0x00004000;
unsigned long __offset_phys_addr_mmu_pp1   = 0x00005000;
unsigned long __offset_phys_addr_mmu_pp2   = 0x00006000;
unsigned long __offset_phys_addr_mmu_pp3   = 0x00007000;
unsigned long __offset_phys_addr_pp0       = 0x00008000;
unsigned long __offset_phys_addr_pp1       = 0x0000a000;
unsigned long __offset_phys_addr_pp2       = 0x0000c000;
unsigned long __offset_phys_addr_pp3       = 0x0000e000;

// Mali450
unsigned long __mali450_phys_addr_gp        = 0x00000000;
unsigned long __mali450_phys_addr_l2_1      = 0x00001000;
unsigned long __mali450_phys_addr_mmu_gp    = 0x00003000;
unsigned long __mali450_phys_addr_mmu_pp0   = 0x00004000;
unsigned long __mali450_phys_addr_mmu_pp1   = 0x00005000;
unsigned long __mali450_phys_addr_mmu_pp2   = 0x00006000;
unsigned long __mali450_phys_addr_mmu_pp3   = 0x00007000;
unsigned long __mali450_phys_addr_pp0       = 0x00008000;
unsigned long __mali450_phys_addr_pp1       = 0x0000a000;
unsigned long __mali450_phys_addr_pp2       = 0x0000c000;
unsigned long __mali450_phys_addr_pp3       = 0x0000e000;
unsigned long __mali450_phys_addr_l2_0      = 0x00010000;
unsigned long __mali450_phys_addr_l2_2      = 0x00011000;
unsigned long __mali450_phys_addr_mmu_pp4   = 0x0001c000;
unsigned long __mali450_phys_addr_mmu_pp5   = 0x0001d000;
unsigned long __mali450_phys_addr_mmu_pp6   = 0x0001e000;
unsigned long __mali450_phys_addr_mmu_pp7   = 0x0001f000;
unsigned long __mali450_phys_addr_pp4       = 0x00028000;
unsigned long __mali450_phys_addr_pp5       = 0x0002a000;
unsigned long __mali450_phys_addr_pp6       = 0x0002c000;
unsigned long __mali450_phys_addr_pp7       = 0x0002e000;


int __mem_fd;


void initialize_mali_core(char *mali_core, unsigned char nb_pp)
{
    Mali.__mali_phys_addr = __mali_core_phys_base_addr;

    if (!strncasecmp(mali_core, "mali200", 7))
    {
        Mali.__mali_phys_addr_gp        = __mali_core_phys_base_addr + __mali200_offset_phys_addr_gp;
        Mali.__mali_nb_l2_caches        = 0;
        Mali.__mali_phys_addr_l2[0]     = 0x0;
        Mali.__mali_nb_gp_cores         = 1;
        Mali.__mali_nb_pp_cores         = 1;
        Mali.__mali_phys_addr_pp[0]     = __mali_core_phys_base_addr + __mali200_offset_phys_addr_pp;
        Mali.__mali_nb_mmu_cores        = 1;
        Mali.__mali_phys_addr_mmu[0]    = __mali_core_phys_base_addr + __mali200_offset_phys_addr_mmu;
    }

	else if (!strncasecmp(mali_core, "mali300", 7))
	{
	Mali.__mali_nb_l2_caches        = 1;
        Mali.__mali_nb_gp_cores         = 1;
        Mali.__mali_nb_pp_cores         = 1;
        Mali.__mali_nb_mmu_cores        = 2;
        Mali.__mali_phys_addr_l2[0]     = __mali_core_phys_base_addr + __offset_phys_addr_l2;
        Mali.__mali_phys_addr_gp        = __mali_core_phys_base_addr + __offset_phys_addr_gp;
        Mali.__mali_phys_addr_mmu[0]    = __mali_core_phys_base_addr + __offset_phys_addr_mmu_gp;
        Mali.__mali_phys_addr_mmu[1]    = __mali_core_phys_base_addr + __offset_phys_addr_mmu_pp0;
        Mali.__mali_phys_addr_pp[0]     = __mali_core_phys_base_addr + __offset_phys_addr_pp0;
	}

    else if (!strncasecmp(mali_core, "mali400", 7))
    {
        Mali.__mali_nb_l2_caches        = 1;
        Mali.__mali_phys_addr_l2[0]     = __mali_core_phys_base_addr + __offset_phys_addr_l2;
        Mali.__mali_nb_gp_cores         = 1;
        Mali.__mali_phys_addr_gp        = __mali_core_phys_base_addr + __offset_phys_addr_gp;
        Mali.__mali_phys_addr_mmu[0]    = __mali_core_phys_base_addr + __offset_phys_addr_mmu_gp;

        if (nb_pp < 1 || nb_pp > 4)
        {
            printf ("Error: bad value of nb_pp\n");
        }
        else
        {
            Mali.__mali_nb_pp_cores         = 1;
            Mali.__mali_nb_mmu_cores        = 2;
            Mali.__mali_phys_addr_pp[0]     = __mali_core_phys_base_addr + __offset_phys_addr_pp0;
            Mali.__mali_phys_addr_mmu[1]    = __mali_core_phys_base_addr + __offset_phys_addr_mmu_pp0;

            if (nb_pp >= 2)
            {
                Mali.__mali_nb_pp_cores         ++;
                Mali.__mali_nb_mmu_cores        ++;
                Mali.__mali_phys_addr_pp[1]     = __mali_core_phys_base_addr + __offset_phys_addr_pp1;
                Mali.__mali_phys_addr_mmu[2]    = __mali_core_phys_base_addr + __offset_phys_addr_mmu_pp1;
            }
            if (nb_pp >= 3)
            {
                Mali.__mali_nb_pp_cores         ++;
                Mali.__mali_nb_mmu_cores        ++;
                Mali.__mali_phys_addr_pp[2]     = __mali_core_phys_base_addr + __offset_phys_addr_pp2;
                Mali.__mali_phys_addr_mmu[3]    = __mali_core_phys_base_addr + __offset_phys_addr_mmu_pp2;
 
            }
            if (nb_pp >= 4)
            {
                Mali.__mali_nb_pp_cores         ++;
                Mali.__mali_nb_mmu_cores        ++;
                Mali.__mali_phys_addr_pp[3]     = __mali_core_phys_base_addr + __offset_phys_addr_pp3;
                Mali.__mali_phys_addr_mmu[4]    = __mali_core_phys_base_addr + __offset_phys_addr_mmu_pp3;
 
            }
        }
    }
  else if (!strncasecmp(mali_core, "mali450", 7))
    {   
        Mali.__mali_phys_addr           = __mali_core_phys_base_addr;
        Mali.__mali_nb_l2_caches        = 2;
        Mali.__mali_phys_addr_l2[0]     = __mali450_phys_addr_l2_0 | __mali_core_phys_base_addr;
        Mali.__mali_phys_addr_l2[1]     = __mali450_phys_addr_l2_1 | __mali_core_phys_base_addr;
        Mali.__mali_nb_gp_cores         = 1;
        Mali.__mali_phys_addr_gp        = __mali450_phys_addr_gp | __mali_core_phys_base_addr;
        Mali.__mali_phys_addr_mmu[0]    = __mali450_phys_addr_mmu_gp | __mali_core_phys_base_addr;

        if (nb_pp < 1 || nb_pp > 8)
        {
            printf ("Error: bad value of nb_pp\n");
        }
        else
        {
            Mali.__mali_nb_pp_cores         = 1;
            Mali.__mali_nb_mmu_cores        = 2;
            Mali.__mali_phys_addr_pp[0]     = __mali450_phys_addr_pp0 | __mali_core_phys_base_addr;
            Mali.__mali_phys_addr_mmu[1]    = __mali450_phys_addr_mmu_pp0 | __mali_core_phys_base_addr;

            if (nb_pp >= 2)
            {
                Mali.__mali_nb_pp_cores         ++;
                Mali.__mali_nb_mmu_cores        ++;
                Mali.__mali_phys_addr_pp[1]     = __mali450_phys_addr_pp1 | __mali_core_phys_base_addr;
                Mali.__mali_phys_addr_mmu[2]    = __mali450_phys_addr_mmu_pp1 | __mali_core_phys_base_addr;
            }
            if (nb_pp >= 3)
            {
                Mali.__mali_nb_pp_cores         ++;
                Mali.__mali_nb_mmu_cores        ++;
                Mali.__mali_phys_addr_pp[2]     = __mali450_phys_addr_pp2 | __mali_core_phys_base_addr;
                Mali.__mali_phys_addr_mmu[3]    = __mali450_phys_addr_mmu_pp2 | __mali_core_phys_base_addr;
            }
            if (nb_pp >= 4)
            {
                Mali.__mali_nb_pp_cores         ++;
                Mali.__mali_nb_mmu_cores        ++;
                Mali.__mali_phys_addr_pp[3]     = __mali450_phys_addr_pp3 | __mali_core_phys_base_addr;
                Mali.__mali_phys_addr_mmu[4]    = __mali450_phys_addr_mmu_pp3 | __mali_core_phys_base_addr;
            }
            if (nb_pp >= 5)
            {
                Mali.__mali_nb_pp_cores         ++;
                Mali.__mali_nb_mmu_cores        ++;
                Mali.__mali_nb_l2_caches            ++;
                Mali.__mali_phys_addr_pp[4]     = __mali450_phys_addr_pp4 | __mali_core_phys_base_addr;
                Mali.__mali_phys_addr_mmu[5]    = __mali450_phys_addr_mmu_pp4 | __mali_core_phys_base_addr;
                Mali.__mali_phys_addr_l2[2]     = __mali450_phys_addr_l2_2 | __mali_core_phys_base_addr;
            }
            if (nb_pp >= 6)
            {
                Mali.__mali_nb_pp_cores         ++;
                Mali.__mali_nb_mmu_cores        ++;
                Mali.__mali_phys_addr_pp[5]     = __mali450_phys_addr_pp5 | __mali_core_phys_base_addr;
                Mali.__mali_phys_addr_mmu[6]    = __mali450_phys_addr_mmu_pp5 | __mali_core_phys_base_addr;
            }
            if (nb_pp >= 7)
            {
                Mali.__mali_nb_pp_cores         ++;
                Mali.__mali_nb_mmu_cores        ++;
                Mali.__mali_phys_addr_pp[6]     = __mali450_phys_addr_pp6 | __mali_core_phys_base_addr;
                Mali.__mali_phys_addr_mmu[7]    = __mali450_phys_addr_mmu_pp6 | __mali_core_phys_base_addr;
            }
            if (nb_pp >= 8)
            {
                Mali.__mali_nb_pp_cores         ++;
                Mali.__mali_nb_mmu_cores        ++;
                Mali.__mali_phys_addr_pp[7]     = __mali450_phys_addr_pp7 | __mali_core_phys_base_addr;
                Mali.__mali_phys_addr_mmu[8]    = __mali450_phys_addr_mmu_pp7 | __mali_core_phys_base_addr;
            }
        }
    }

    else {
        printf ("Error: bad value of mali_core\n");
    }
}


void do_usleep(unsigned long sleep_time)
{
//    usleep(sleep_time);
	  struct timespec t;
	  t.tv_sec = 0;
	  t.tv_nsec = 1000 * sleep_time;

	  if(nanosleep(&t, NULL) == -1) {
		  DPRINTF(" ** could not sleep for %lu\n ns, interrupted", sleep_time * 1000);
	  }
}


void irq_cb_func(unsigned long coretype, unsigned long rawstat_value)
{
    DPRINTF("  ** coretype: %ld, rawstat: %08lx\n", coretype, rawstat_value);
}


volatile void *do_get_mem_area(unsigned long phys_addr, unsigned long area_size)
{
   unsigned char *mmap_buff;

    mmap_buff = (unsigned char *) mmap((void*) NULL, area_size+MALI_MEM_PAGESIZE, PROT_READ|PROT_WRITE, MAP_SHARED,
                                        __mem_fd, (off_t) phys_addr & ~(MALI_MEM_PAGESIZE-1));

    mmap_buff = (unsigned char *) ((unsigned long)mmap_buff + (phys_addr & (MALI_MEM_PAGESIZE-1)));

    DPRINTF("  MMAP: phys_addr: %08lx, size: %lx\n", phys_addr, area_size);

    if ((void *) mmap_buff == (void *) -1)
    {
        printf("Unable to mmap region %08lx - %08lx, aborting...\n", phys_addr, phys_addr+area_size);
        exit(1);
    }

    return (volatile void *) mmap_buff;
}


unsigned long ret_coretype(unsigned long regaddr, unsigned long* core_type, unsigned long* core_num)
{
    unsigned long msb = (regaddr & 0xffff0000)>>16;
    switch (msb)
    {
        case 0x0000:
            *core_type  = MALI_CORE_TYPE_GP;
            *core_num   = 0;
            break;

        case 0x0100:
            *core_type  = MALI_CORE_TYPE_L2;
            *core_num   = 0;
            break;

        case 0x0101:
            *core_type  = MALI_CORE_TYPE_L2;
            *core_num   = 1;
            break;

        case 0x0102:
            *core_type  = MALI_CORE_TYPE_L2;
            *core_num   = 2;
            break;

        case 0x1000:
            *core_type  = MALI_CORE_TYPE_PP;
            *core_num   = 0;
            break;

        case 0x1001:
            *core_type  = MALI_CORE_TYPE_PP;
            *core_num   = 1;
            break;

        case 0x1002:
            *core_type  = MALI_CORE_TYPE_PP;
            *core_num   = 2;
            break;

        case 0x1003:
            *core_type  = MALI_CORE_TYPE_PP;
            *core_num   = 3;
            break;

        case 0x1004:
            *core_type  = MALI_CORE_TYPE_PP;
            *core_num   = 4;
            break;

        case 0x1005:
            *core_type  = MALI_CORE_TYPE_PP;
            *core_num   = 5;
            break;

        case 0x1006:
            *core_type  = MALI_CORE_TYPE_PP;
            *core_num   = 6;
            break;

        case 0x1007:
            *core_type  = MALI_CORE_TYPE_PP;
            *core_num   = 7;
            break;

        case 0x0200:
            // MMU GP (only MMU for Mali-200)
            *core_type  = MALI_CORE_TYPE_MMU;
                *core_num   = 0;

        case 0x1200:
            // MMU PP0
            *core_type  = MALI_CORE_TYPE_MMU;
            *core_num   = 1;
            break;

        case 0x1201:
            // MMU PP1
            *core_type  = MALI_CORE_TYPE_MMU;
            *core_num   = 2;
            break;

        case 0x1202:
            // MMU PP2
            *core_type  = MALI_CORE_TYPE_MMU;
            *core_num   = 3;
            break;

        case 0x1203:
            // MMU PP3
            *core_type  = MALI_CORE_TYPE_MMU;
            *core_num   = 4;
            break;

        case 0x1204:
            // MMU PP4
            *core_type  = MALI_CORE_TYPE_MMU;
            *core_num   = 5;
            break;

        case 0x1205:
            // MMU PP5
            *core_type  = MALI_CORE_TYPE_MMU;
            *core_num   = 6;
            break;

        case 0x1206:
            // MMU PP6
            *core_type  = MALI_CORE_TYPE_MMU;
            *core_num   = 7;
            break;

        case 0x1207:
            // MMU PP7
            *core_type  = MALI_CORE_TYPE_MMU;
            *core_num   = 8;
            break;

        case 0x8000:
        case 0x8001:
        case 0x8002:
            *core_type  = MALI_ORIGINAL_REG_MAP;
            *core_num   = 0;
            break;

        default:
            assert( ! "Unknown coretype \n");
        break;
    }

    return MALI_ERROR_NO_ERROR;
}


unsigned long ret_regnum(unsigned long raw_regaddr, unsigned long core_type)
{
//    return raw_regaddr & 0x00FF7FFF; /* Masks out the coretype-selector-bits */
    if (core_type == MALI_ORIGINAL_REG_MAP)
        return raw_regaddr & 0x0003FFFF;
    else
        return raw_regaddr & 0x0000FFFF; /* Masks out the coretype-selector-bits */
}


mali_error_code _backend_read_reg(unsigned long addr_reg, unsigned long *value_read)
{
    unsigned long core_type;
    unsigned long core_num;
    unsigned long regnum;

    ret_coretype(addr_reg, &core_type, &core_num);
    regnum = ret_regnum(addr_reg, core_type);
    mali_readreg(core_type, core_num, regnum, value_read);
    return MALI_ERROR_NO_ERROR;
}


mali_error_code _backend_write_reg(unsigned long addr_reg, unsigned long value_write)
{
    unsigned long core_type;
    unsigned long core_num;
    unsigned long regnum;

    ret_coretype(addr_reg, &core_type, &core_num);
    regnum = ret_regnum(addr_reg, core_type);
    mali_writereg(core_type, core_num, regnum, value_write);

    return MALI_ERROR_NO_ERROR;
}


mali_error_code _backend_memory_read_word(unsigned long mem_addr, unsigned long *value_read)
{
    mali_read_mali_mem(mem_addr, sizeof(unsigned long), (void *) value_read);

    return MALI_ERROR_NO_ERROR;
}



/**
 */
mali_error_code _backend_memory_write_word(unsigned long mem_addr, unsigned long value)
{
    mali_load_data(mem_addr, sizeof(unsigned long), (void*) &value);
    return MALI_ERROR_NO_ERROR;
}



mali_error_code _backend_compare_mem(unsigned long original_mem_addr, unsigned long new_mem_addr, unsigned long mem_length, int *result)
{
    *result = mali_mem_compare_mali_regions(original_mem_addr, new_mem_addr, mem_length);
    return MALI_ERROR_NO_ERROR;
}


mali_error_code _backend_memset(unsigned long mem_addr, unsigned long mem_length, unsigned int fill_value)
{
    mali_mem_set_region(mem_addr, mem_length, fill_value);
    return MALI_ERROR_NO_ERROR;
}


mali_error_code _backend_reset_cores(unsigned int remap)
{
    /* Reset cores... */

    unsigned long core_num;
     if (Mali.__mali_nb_l2_caches)
      {
          for (core_num = 0; core_num < Mali.__mali_nb_l2_caches; core_num++)
          {
            // L2 - clears the cache
              mali_writereg(MALI_CORE_TYPE_L2, core_num, MALI_L2_REG_CMD, 0x1);
          }
      }

    mali_writereg(MALI_CORE_TYPE_GP, 0, MALI_GP_REG_CMD, 0x20);
    mali_writereg(MALI_CORE_TYPE_GP, 0, MALI_GP_REG_INT_CLEAR, 0x1FFF);

    for (core_num = 0; core_num < Mali.__mali_nb_pp_cores; core_num++)
    {
	   
	//mask out reset_done bit from irq status
        mali_writereg(MALI_CORE_TYPE_PP, core_num, MALI_PP_REG_MGMT_INT_MASK, 0x0FFF);
	//soft reset
        mali_writereg(MALI_CORE_TYPE_PP, core_num, MALI_PP_REG_MGMT_CTRL, 0x20);
    }

	//reset mmu's	
	for (core_num = 0; core_num < Mali.__mali_nb_mmu_cores; core_num++) {
            mali_writereg(MALI_CORE_TYPE_MMU, core_num, MALI_MMU_REG_CMD_REG, 6); /* Reset MMU */
			mali_writereg(MALI_CORE_TYPE_MMU, core_num, MALI_MMU_REG_IRQ_CLEAR, 0x3);
	}
	if (remap)
    {
        set_phys_addr_mali_mmu_table(__mali_phys_addr_mmu_table);
        set_mmu_table(0);
        // Enables the MMU(s)
        for (core_num = 0; core_num < Mali.__mali_nb_mmu_cores; core_num++)
            configure_mmu(core_num);
    }
    else 
	{
        // the MMU is disabled
        // To use it, it must be explicitely written in the config.txt file
        for (core_num = 0; core_num < Mali.__mali_nb_mmu_cores; core_num++) {
            mali_writereg(MALI_CORE_TYPE_MMU, core_num, MALI_MMU_REG_CMD_REG, 1); /* Disable MMU */
		}
	}

    return MALI_ERROR_NO_ERROR;
}


mali_error_code _backend_flush()
{
    return MALI_ERROR_NO_ERROR;
}


mali_error_code _backend_read_config(char *filename)
{
    return MALI_ERROR_NO_ERROR;
}


mali_error_code _backend_init(char *mali_core, unsigned char nb_pp, unsigned char pmu, unsigned long remap)
{
    unsigned long core_num;

    if ((__mem_fd = open(LINUX_DEV_MEM, O_RDWR|O_SYNC)) < 0)
    {
        printf("Unable to open %s\n", LINUX_DEV_MEM);
        exit(1);
    }

    // Set the attributes of the core under test
    initialize_mali_core(mali_core, nb_pp);
    printf("Mali core: %s\n", mali_core);

    if (!strncasecmp(mali_core, "mali200", 7))
	{
		mali_design = M200;
	}
    else if (!strncasecmp(mali_core, "mali300", 7))
	{
		mali_design = M300;
	}
    else if (!strncasecmp(mali_core, "mali400", 7))
	{
		mali_design = M400;
        printf("Number of Pixel Processors: %d\n", nb_pp);
	}
    else if (!strncasecmp(mali_core, "mali450", 7))
	{
		mali_design = M450;
        printf("Number of Pixel Processors: %d\n", nb_pp);
	}
    if (pmu)
        printf("PMU enabled (-p).\n");
    if (remap)
        printf("Remap option enabled (-r), the config.txt file uses virtual addresses.\n");

    enable_pmu(pmu);

    /*  Map needed functionality into library: */
    set_func_get_mem_area( (get_mem_area_func) do_get_mem_area );
    set_func_usleep( (usleep_func) do_usleep );
    set_func_irq_callback( (irq_callback_func) irq_cb_func );


    /* Set correct addresses */
    set_phys_addr_mali_mem( __mali_phys_addr_mem );
    set_mali_mem_info( __mali_mem_size, MALI_MEM_PAGESIZE);

    set_phys_addr_core_regs_gp(0, Mali.__mali_phys_addr_gp);

    set_phys_addr_mali(Mali.__mali_phys_addr);

     if (Mali.__mali_nb_l2_caches)
    {
        for (core_num = 0; core_num < Mali.__mali_nb_l2_caches; core_num ++)
        {
            set_phys_addr_core_regs_l2(core_num, Mali.__mali_phys_addr_l2[core_num]);
        }
    }

    for (core_num = 0; core_num < Mali.__mali_nb_pp_cores; core_num ++)
    {
        set_phys_addr_core_regs_pp(core_num, Mali.__mali_phys_addr_pp[core_num]);
    }

    for (core_num = 0; core_num < Mali.__mali_nb_mmu_cores; core_num ++)
    {
        set_phys_addr_core_regs_mmu(core_num, Mali.__mali_phys_addr_mmu[core_num]);
    }

    // Use MMU - page table made by tb_util
    if (remap)
    {
        set_phys_addr_mali_mmu_table(__mali_phys_addr_mmu_table);
        set_mmu_table(0);
        // Enables the MMU(s)
        for (core_num = 0; core_num < Mali.__mali_nb_mmu_cores; core_num++)
            configure_mmu(core_num);
    }
    else
        // the MMU is disabled
        // To use it, it must be explicitely written in the config.txt file
        for (core_num = 0; core_num < Mali.__mali_nb_mmu_cores; core_num++)
            mali_writereg(MALI_CORE_TYPE_MMU, core_num, MALI_MMU_REG_CMD_REG, 1); /* Disable MMU */


    return MALI_ERROR_NO_ERROR;
}


mali_error_code _backend_close()
{
    close(__mem_fd);
    return MALI_ERROR_NO_ERROR;
}


mali_error_code _backend_wait_cycles(unsigned long num_cycles)
{
    mali_wait_cycles(num_cycles);

    return MALI_ERROR_NO_ERROR;
}

mali_error_code _backend_wait_irq()
{
    mali_wait_irq_by_intstat(3*1000, 0);  /* 3000ms timeout, check all cores for IRQ */
    return MALI_ERROR_NO_ERROR;
}

mali_error_code _backend_wait_irqmask(unsigned long irq_mask, unsigned long core_mask)
{
    mali_wait_irqmask(3*1000, irq_mask, core_mask);  /* 3000ms timeout */

    return MALI_ERROR_NO_ERROR;
}

