//----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
// (C) COPYRIGHT 2006 ARM Limited.
// ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
// Checked In : $Date: 2008-09-25 15:04:59 +0200 (Thu, 25 Sep 2008) $
// Revision : $Revision: 66744 $
//
//----------------------------------------------------------------------------

#include <stdlib.h>

#include "backend.h"

mali_error_code _backend_read_reg(unsigned long addr_reg, unsigned long *value_read)
{
    *value_read = rand();
    return MALI_ERROR_NO_ERROR;
}

mali_error_code _backend_write_reg(unsigned long addr_reg, unsigned long value_write)
{
    return MALI_ERROR_NO_ERROR;
}

mali_error_code _backend_memory_read_word(unsigned long mem_addr, unsigned long *value_read)
{
    *value_read = rand();
    return MALI_ERROR_NO_ERROR;
}

mali_error_code _backend_memory_write_word(unsigned long mem_addr, unsigned long value)
{
    return MALI_ERROR_NO_ERROR;
}

mali_error_code _backend_compare_mem(unsigned long original_mem_addr, unsigned long new_mem_addr, unsigned long mem_length, int *res
ult)
{
    return MALI_ERROR_NO_ERROR;
}

mali_error_code _backend_memset(unsigned long mem_addr, unsigned long mem_length, unsigned int fill_value)
{
    return MALI_ERROR_NO_ERROR;
}

mali_error_code _backend_reset_cores()
{
    return MALI_ERROR_NO_ERROR;
}

mali_error_code _backend_flush()
{
    return MALI_ERROR_NO_ERROR;
}

mali_error_code _backend_read_config(char *filename)
{
    return MALI_ERROR_NO_ERROR;
}

mali_error_code _backend_init(unsigned long use_mmu)
{
    return MALI_ERROR_NO_ERROR;
}

mali_error_code _backend_close()
{
    return MALI_ERROR_NO_ERROR;
}

mali_error_code _backend_wait_cycles(unsigned long num_cycles)
{
    return MALI_ERROR_NO_ERROR;
}

mali_error_code _backend_wait_irq()
{
    return MALI_ERROR_NO_ERROR;
}

mali_error_code _backend_wait_irqmask(unsigned long irq_mask, unsigned long core_mask)
{
    return MALI_ERROR_NO_ERROR;
}

