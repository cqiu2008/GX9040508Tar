//----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
// (C) COPYRIGHT 2006 ARM Limited.
// ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
// Checked In : $Date: 2012-06-06 09:59:08 +0200 (Wed, 06 Jun 2012) $
// Revision : $Revision: 131200 $
//
//----------------------------------------------------------------------------

#include "tb_util.h"

#ifndef __BACKEND_H
#define __BACKEND_H


#define	MALI_MEM_PHYS_ADDR	0x70000000
#define MALI_MEM_SIZE		257*1024*1024
// MALI_MMU_TABLE_ADDR must be comprised in the range (MALI_MEM_PHYS_ADDR : MALI_MEM_PHYS_ADDR + MALI_MEM_SIZE)
#define	MALI_MMU_TABLE_ADDR	0x7ff00000

#define M200 0
#define M300 1
#define M400 2
#define M450 1

/* */
mali_error_code _backend_read_reg(unsigned long addr_reg, unsigned long *value_read);
mali_error_code _backend_write_reg(unsigned long addr_reg, unsigned long value_write);
mali_error_code _backend_memory_read_word(unsigned long addr, unsigned long *value_read);
mali_error_code _backend_memory_write_word(unsigned long addr, unsigned long value);
mali_error_code _backend_compare_mem(unsigned long original_mem_addr, unsigned long new_mem_addr, unsigned long mem_length, int *result);
mali_error_code _backend_memset(unsigned long mem_addr, unsigned long mem_length, unsigned int fill_value);
mali_error_code _backend_reset_cores(unsigned int remap);
mali_error_code _backend_flush();
mali_error_code _backend_read_config(char *filename);
mali_error_code _backend_init(char *mali_core, unsigned char nb_pp, unsigned char pmu, unsigned long remap);
mali_error_code _backend_close();
mali_error_code _backend_wait_cycles(unsigned long num_cycles);
mali_error_code _backend_wait_irq();
mali_error_code _backend_wait_irqmask(unsigned long irq_mask, unsigned long core_mask);


#endif //__BACKEND_H

