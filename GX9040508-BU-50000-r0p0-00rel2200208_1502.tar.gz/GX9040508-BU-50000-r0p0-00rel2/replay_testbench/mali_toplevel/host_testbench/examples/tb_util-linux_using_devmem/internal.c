//----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
// (C) COPYRIGHT 2007 ARM Limited.
// ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
// Checked In : $Date: 2012-06-05 15:18:54 +0200 (Tue, 05 Jun 2012) $
// Revision : $Revision: 131145 $
//
//----------------------------------------------------------------------------

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <ctype.h>

#include "tb_util.h"
#include "internal.h"


/**
 * Internal helper-function to parse next argument as an integer.
 */
mali_error_code _internal_parse_arg_int(
            char*buf_in, 
            char**buf_out, 
            unsigned long *val_out, 
            unsigned int base, 
            unsigned int align_mask)
{
    char *buf;
    unsigned long read_val, read_aligned, mask_check;


    mask_check = align_mask;
    while (mask_check & 1) 
    {
        mask_check >>= 1;
    }
    /* Checking that align_mask is legal */
    if ( mask_check || align_mask>128)
    {   
        fprintf(stderr, "! Err: %s(): align_mask: %#x is not a valid align_mask!\n", __FUNCTION__, align_mask);
        return MALI_ERROR_FUNCTION_FAILED;
    }

    /* Checking that buf_in is not zeropointer*/
    buf = buf_in;
    if ( !buf )
    {   
        fprintf(stderr, "! Err: %s(): buf is NULL pointer\n", __FUNCTION__);
        return MALI_ERROR_FUNCTION_FAILED;
    }

    /* Checking that val_out is not zeropointer*/
    if ( !val_out )
    {   
        fprintf(stderr, "! Err: %s(): val_out is NULL pointer\n", __FUNCTION__);
        return MALI_ERROR_FUNCTION_FAILED;
    }

    /* Reading the found hexval */
    read_val = (unsigned long) strtoll(buf, &buf, base);

    /* Masking if necessary, and warn if value is align_masked */
    read_aligned = read_val&(~align_mask);
    if (read_aligned != read_val)
    {   
        fprintf(stderr, "! Warning: %s(): parsed val: %#lx is aligned to: %lx according align_mask: %x\n",
                __FUNCTION__, read_val, read_aligned, align_mask);
    }
    *val_out = read_aligned;

    if (buf_out) 
    {
        *buf_out = buf;
    }

    return MALI_ERROR_NO_ERROR;
}


/**
 * Internal helper-function to parse next argument as an string.
 */
mali_error_code _internal_parse_arg_str(char*buf_in, char**buf_out, char **val_out)
{
    char *buf, *tmp;
    unsigned int arg_start;

    /* Checking that buf_in is not zeropointer*/
    buf = buf_in;
    if ( !buf )
    {   
        fprintf(stderr, "! Err: %s(): buf is NULL pointer\n", __FUNCTION__);
        return MALI_ERROR_FUNCTION_FAILED;
    }

    /* Skip any whitespace at the beginning */
    arg_start = 0;
    while (isspace(*buf))
    {
        buf++;
        arg_start++;
    }
    *val_out = buf;

    /* Find where next argument starts */
    tmp = index(buf, ' ');
    if (tmp != NULL)
    {
        buf = tmp;
        buf++;
        tmp[0] = '\0';
    }

    if (buf_out) 
    {
        *buf_out = buf;
    }

    return MALI_ERROR_NO_ERROR;
}

/**
 * Internal helper-function to check for redirection to file.
 */
mali_error_code _internal_parse_arg_redirect(char *buf_in, char **buf_out, char **filename_out, int *append)
{
    char *tmp_flags;
    mali_error_code err;

    // Default to append    
    *append = 1;

    err = _internal_parse_arg_str(buf_in, buf_out, &tmp_flags);
    if (strcmp(tmp_flags, ">") == 0) 
    {
        *append = 0;
    } else {
        *append = 1;
    }
    err = _internal_parse_arg_str(*buf_out, buf_out, filename_out);

    return MALI_ERROR_NO_ERROR;
}

/**
 * Internal helper-function to write out a line in memory dump format:
 * 0000A010: 000000.. ........ 01234567 89ABCDEF
 *
 * The line will be written to buf_out, and mask is used to mask out
 * bytes that should be left untouched.
 */
int _internal_dump_write_line(char *buf_in, char **buf_out, unsigned long mem_addr, unsigned long *values, unsigned long mask)
{
    int len;
    len = 0;

    len += sprintf(buf_in+len, "%08lx: ", mem_addr & 0xFFFFFFF0);
    for (int word = 0; word < 4; word++)
    {
        for (int byte = 4; byte > 0; byte--)
        {
            if (mask & (1 << ((word*4)+(byte-1))))
            {
                len += sprintf(buf_in+len, "%02lx", (values[word] & (0xFF << (8*(byte-1)))) >> (8*(byte-1)) );
            } else {
                len += sprintf(buf_in+len, "..");
            }
        }
        if (word < 3)
            len  += sprintf(buf_in+len, " ");
    }
    len += sprintf(buf_in+len, "\n");

    return len;
}

/**
 * Internal helper-function to parse a line read from a memory dump file.
 */
mali_error_code _internal_parse_dump_line(char *line, unsigned long *mem_addr, unsigned long *words, unsigned long *mask)
{
    char *buf;
    mali_error_code err;
    unsigned long value;
    unsigned long tmpmask;
    char *str_value;
    char tmpbyte[3] = {0,0,0};


    buf = line;
    value = 0;
    tmpmask = 0;

    /* Extract memory address for given line. */
    err = _internal_parse_arg_int(buf, &buf, &value, 16, 0);
    if (err != MALI_ERROR_NO_ERROR)
    {
        fprintf(stderr, "Error %s(): Unable to find memory address at start of line, aborting.\n", __FUNCTION__);
        return err;
    }
    buf++;  /* Skip : */
    buf++;  /* Skip space */
    *mem_addr = value;

    for (int word = 0; word < 4; word++)
    {
        err = _internal_parse_arg_str(buf, &buf, &str_value);
        if (err != MALI_ERROR_NO_ERROR)
        {
            fprintf(stderr, "Error %s(): Unable to parse word at %08lx, aborting.\n", __FUNCTION__, value+(word*4));
            return err;
        }
        value = 0;
        for (int byte = 0; byte<4; byte++)
        {
            if (!(strncmp(&str_value[(3-byte)*2], "..", 2) == 0) &&
                !(strncasecmp(&str_value[(3-byte)*2], "xx", 2) == 0) )
            {
                strncpy(tmpbyte, &str_value[(3-byte)*2], 2);
                value += strtol(tmpbyte, NULL, 16) << (byte*8);
                tmpmask |= 1<<((word*4)+byte);
            }
        }
        words[word] = value;
    }
    *mask = tmpmask;

    return MALI_ERROR_NO_ERROR; 
}

