//----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
// (C) COPYRIGHT 2006-2007 ARM Limited.
// ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
// Checked In : $Date: 2012-06-08 14:05:57 +0200 (Fri, 08 Jun 2012) $
// Revision : $Revision: 131396 $
//
//----------------------------------------------------------------------------

#include <stdio.h>
#include <stdlib.h>
#include <strings.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <ctype.h> /* isalnum(int c).. */

#include "tb_util.h"
#include "internal.h"
#include "backend.h"

#define TIMEOUT_DEFAULT_VAL 1001
int timeoutval=TIMEOUT_DEFAULT_VAL;
volatile int irq_counter_mali=0;
volatile int waitfor_irq_counter_mali=0;

unsigned int mali_mem_start_addr = MALI_MEM_PHYS_ADDR;
// Set 'remap' to 1 to remap the virtual address 0x0 containted in the config.txt
// files to the physical address of the Mali memory
unsigned int remap = 0;

int debug_print = 0;


cmd_function cmd_exec;

cmd_function cmd_buslog;
cmd_function cmd_check_reg;
cmd_function cmd_clear_mem;
cmd_function cmd_compare_mem;
cmd_function cmd_compare_reg;
cmd_function cmd_dump_mem;
cmd_function cmd_dump_reg;
cmd_function cmd_inject_read_error;
cmd_function cmd_inject_write_error;
cmd_function cmd_load_mem;
cmd_function cmd_load_reg;
cmd_function cmd_quit;
cmd_function cmd_readlatency;
cmd_function cmd_reset;
cmd_function cmd_timeout;
cmd_function cmd_wait;
cmd_function cmd_writelatency;
cmd_function cmd_writeln;
cmd_function cmd_writereg;


typedef struct name_function{
    char * name;
    cmd_function * function;
} name_function;

#define COMMAND_GEN(NAME)  { #NAME, cmd_ ##NAME }
#define CMD_LIST_SIZE 19
name_function cmd_list[CMD_LIST_SIZE] =
{
    COMMAND_GEN(buslog),
    COMMAND_GEN(check_reg),
    COMMAND_GEN(clear_mem),
    COMMAND_GEN(compare_mem),
    COMMAND_GEN(compare_reg),
    COMMAND_GEN(dump_mem),
    COMMAND_GEN(dump_reg),
    COMMAND_GEN(inject_read_error),
    COMMAND_GEN(inject_write_error),
    COMMAND_GEN(load_mem),
    COMMAND_GEN(load_reg),
    COMMAND_GEN(quit),
    COMMAND_GEN(readlatency),
    COMMAND_GEN(reset),
    COMMAND_GEN(timeout),
    COMMAND_GEN(wait),
    COMMAND_GEN(writelatency),
    COMMAND_GEN(writeln),
    COMMAND_GEN(writereg),
};


void closing()
{
//    fclose(mali_file);
}

void close_err()
{
    printf("Closing due to an error\n");
    closing();
    exit(1);
}


void init(char *mali_core, unsigned char nb_pp, unsigned char pmu, unsigned int remap)
{
    //mali_register tmp_mali;
    /*Registering signal handler */
    //(void) signal(SIGUSR2,handle_gp_interrupt);
    //(void) signal(SIGUSR1,handle_pp_interrupt);

    /* Opens the mp device file */
    //if (! (mali_file= fopen(MALI_MP_FILE_NAME, "r+")) ){
    //    fprintf(stderr, "! Error: Could not open the media processor device file\n");
    //    close_err();
    //}
    //ioctl( fileno(mali_file), MALI_IOC_SET_SIGNAL_ME, (unsigned long)getpid());
    //ioctl( fileno(mali_file), MALI_MP_IOC_GET_LAST_IRQ_RAWSTAT, &tmp_mali);
    //ioctl( fileno(mali_file), MALI_MP_IOC_ENABLE_SIGNALS );
    _backend_init(mali_core, nb_pp, pmu, remap);
}


/**
 * Helper-function for the following commands:
 * - cmd_compare_mem
 * - cmd_dump_mem
 */
mali_error_code _do_mem_dump(char *filename, int append, int close_file, unsigned long mem_addr_from, unsigned long mem_addr_to)
{
    mali_error_code ret_value;
    FILE *file_dump;
    unsigned long mem_addr_current;
    unsigned long mem_addr_diff;
    unsigned long outword[4];
    unsigned long mask;

    /* Set defaults */
    file_dump = stdout;
    mask = 0;
    for (int i = 0; i < 4; i++)
    {
        outword[i] = 0;
    }


    /* Check if we're supposed to redirect to file, setup is we are. */
    if (strlen(filename) > 0)
    {
        if (append)
            file_dump = fopen(filename, "a");
        else
            file_dump = fopen(filename, "w");

        close_file = 1;
        if (file_dump == NULL)
        {
            PRINTERR("Error unable to open file %s for writing.\n", filename);
            return MALI_ERROR_FUNCTION_FAILED;
        }
    }

    /* Dump actual memory */
    /* NOTE! This part can probably be optimized later to read larger */
    /* chunks of memory, currently it's just reading one 32bit word at a time. */
    mem_addr_current = mem_addr_from;
    while (mem_addr_current < mem_addr_to)
    {
        unsigned long wordnr;
        char print_buf_start[128];
        char *print_buf;

        wordnr = (mem_addr_current>>2)&3;
        mem_addr_diff = mem_addr_to - mem_addr_current;
        if (mem_addr_diff > 3)
        {
            for (int i=0; i < 4; i++)
                mask |= 1<<((mem_addr_current+i)&0xf);
        } else {
            /* Less than four bytes (32 bits) left to care about */
            for (int i=0; i < mem_addr_diff; i++)
                mask |= 1<<((mem_addr_current+i)&0xf);
        }

        /* Read out whole, aligned, words */
        ret_value = _backend_memory_read_word(mem_addr_current&0xFFFFFFFC, &outword[wordnr]);
        if (ret_value != MALI_ERROR_NO_ERROR)
        {
            PRINTERR("Error while reading from memory, error code: %d\n", ret_value);
            return MALI_ERROR_FUNCTION_FAILED;
        }

        /* Print out */
        if ( (wordnr==3) || (((mem_addr_current&0xFFFFFFFC)+4) >= mem_addr_to) )
        {
            print_buf = print_buf_start;
            if (remap)
            	// using physical addresses
                _internal_dump_write_line(print_buf, &print_buf, mem_addr_current, &outword[0], mask);
            else
            	// using virtual addresse => let's add the base Mali memory physical address
                _internal_dump_write_line(print_buf, &print_buf, mem_addr_current + mali_mem_start_addr, &outword[0], mask);

            if ((file_dump != stdout) || (debug_print))
                fprintf(file_dump, print_buf);
            mask = 0;
        }

        /* Aligned */
        mem_addr_current = (mem_addr_current&0xFFFFFFFC)+4;
    }


    if (close_file)
    {
        fclose(file_dump);
    }

    return MALI_ERROR_NO_ERROR;
}


/**
 * Command:     buslog <value>
 * Description: This command enables the buslog in the testbench, and
 *              since this is a testbench-related feature it's not
 *              available on FPGA-platforms.
 */
mali_error_code cmd_buslog(char * buf)
{
    IPRINTF("*** BUSLOG not available. Params: %s\n", buf);
    return 0;
}

/**
 * Command:     check_reg <hexaddr> <op> <hexvalue> [ >|>> <file>]
 * Description: Compares value of register at <hexaddr> to <hexvalue>
 *              with <op>. <op> can be '<','>' or '='. Writes
 *              'TRUE' or 'FALSE' to <file> (STDOUT if not specified).
 */
mali_error_code cmd_check_reg(char * buf)
{
    mali_error_code ret_value;
    unsigned long addr_reg;
    unsigned long value_reg_check;
    unsigned long value_reg_read;
    unsigned int comp;
    unsigned int close_file;
    char *operand, *filename;
    FILE *file_dump;
    int append;

    /* default is output to STDOUT */
    file_dump = stdout;
    close_file = 0;
    append = 1;

    ret_value = _internal_parse_arg_int(buf, &buf, &addr_reg, 16, 0);
    if (ret_value != MALI_ERROR_NO_ERROR)
    {
        PRINTERR("Error code: %d\n", ret_value);
        return ret_value;
    }

    ret_value = _internal_parse_arg_str(buf, &buf, &operand);
    if (ret_value != MALI_ERROR_NO_ERROR)
    {
        PRINTERR("Error code: %d\n", ret_value);
        return ret_value;
    }

    ret_value = _internal_parse_arg_int(buf, &buf, &value_reg_check, 16, 0);
    if (ret_value != MALI_ERROR_NO_ERROR)
    {
        PRINTERR("Error reading argument, error code: %d.\n", ret_value);
        return ret_value;
    }

    ret_value = _internal_parse_arg_redirect(buf, &buf, &filename, &append);
    if (ret_value != MALI_ERROR_NO_ERROR)
    {
        PRINTERR("Error reading redirect-argument, error code: %d.\n", ret_value);
        return ret_value;
    }

    ret_value = _backend_read_reg(addr_reg, &value_reg_read);
    if (ret_value != MALI_ERROR_NO_ERROR)
    {
        PRINTERR("Error reading register-value, error code: %d.\n", ret_value);
        return ret_value;
    }

    if (strlen(filename) > 0)
    {
        if (append)
            file_dump = fopen(filename, "a");
        else
            file_dump = fopen(filename, "w");

        close_file = 1;
        if (file_dump == NULL)
        {
            PRINTERR("Error unable to open file %s for writing.\n", filename);
            return MALI_ERROR_NO_ERROR;
        }
    }

    if (strstr(operand, "<") != NULL)
    {
        comp = value_reg_read < value_reg_check;
    } else if (strstr(operand, ">") != NULL)
    {
        comp = value_reg_read > value_reg_check;
    } else if (strstr(operand, "=") != NULL)
    {
        comp = value_reg_read = value_reg_check;
    } else if (strstr(operand, ">=") != NULL)
    {
        comp = value_reg_read >= value_reg_check;
    } else if (strstr(operand, "<=") != NULL)
    {
        comp = value_reg_read <= value_reg_check;
    } else if (strstr(operand, "!=") != NULL)
    {
        comp = value_reg_read != value_reg_check;
    } else
    {
        if (close_file)
        {
            fclose(file_dump);
        }
         return MALI_ERROR_FUNCTION_FAILED;
    }

    if (file_dump != stdout)
        fprintf(file_dump, "%s\n", comp ? _INTERNAL_STR_TRUE : _INTERNAL_STR_FALSE);
    if (close_file)
    {
        fclose(file_dump);
    }
    IPRINTF("CHECK_REG addr:%04lx op:\"%s\" ref:%08lx read:%08lx: %s\n",
            addr_reg, operand, value_reg_check, value_reg_read, comp ? _INTERNAL_STR_TRUE : _INTERNAL_STR_FALSE);
    return MALI_ERROR_NO_ERROR;
}

/**
 * Command:     clear_mem <start_hexaddr> <end_hexaddr> [<hexval>=0]
 * Description: Clears the memory, starting from start_hexaddr ending
 *              with end_hexaddr-1.  The memory is cleared with hexval
 *              which defaults to 0 if not set.
 */
mali_error_code cmd_clear_mem(char * buf)
{
    mali_error_code ret_value;
    unsigned long addr_start;
    unsigned long addr_end;
    unsigned long fill_value;

    /* Set default values */
    fill_value = 0;
    addr_start = 0;
    addr_end = 0;

    ret_value = _internal_parse_arg_int(buf, &buf, &addr_start, 16, 0);
    if (ret_value != MALI_ERROR_NO_ERROR)
    {
        PRINTERR("Failed to read start_hexaddr, error code: %d\n", ret_value);
        return MALI_ERROR_FUNCTION_FAILED;
    }
    if (!remap)
    {
		// using physical addresses
        if (! (addr_start >= mali_mem_start_addr) )
        {
            PRINTERR("start_hexaddr is not inside the range of malimemory, aborting.\n");
            return MALI_ERROR_FUNCTION_FAILED;
        }
        addr_start = addr_start - mali_mem_start_addr;
    }

    ret_value = _internal_parse_arg_int(buf, &buf, &addr_end, 16, 0);
    if (ret_value != MALI_ERROR_NO_ERROR)
    {
        PRINTERR("Failed to read end_hexaddr, error code: %d\n", ret_value);
        return MALI_ERROR_FUNCTION_FAILED;
    }
    if (!remap)
    {
        if (! (addr_end >= mali_mem_start_addr) )
        {
            PRINTERR("end_hexaddr is not inside the range of malimemory, aborting.\n");
            return MALI_ERROR_FUNCTION_FAILED;
        }
        addr_end = addr_end - mali_mem_start_addr;
    }

    ret_value = _internal_parse_arg_int(buf, &buf, &fill_value, 16, 0);
    if (ret_value != MALI_ERROR_NO_ERROR)
    {
        PRINTERR("Failed to read hexval, error code: %u\n", ret_value);
        return MALI_ERROR_FUNCTION_FAILED;
    }

    if (remap)
    {
		// using physical addresses
        IPRINTF("CLEAR_MEM start_addr:%04lx end_addr:%04lx fillvalue:%lx\n",
                addr_start, addr_end, fill_value);
    } else {
		// using addresses relative to the physical Mali memory base address
        IPRINTF("CLEAR_MEM start_addr:%04lx end_addr:%04lx fillvalue:%lx\n",
                mali_mem_start_addr + addr_start, mali_mem_start_addr + addr_end, fill_value);
    }

    /* Fill memory with value  */
    _backend_memset(addr_start, addr_end - addr_start, fill_value);

    return MALI_ERROR_NO_ERROR;
}


/**
 * Command:     compare_mem <hexaddr0, original> <hexaddr1, new> <length, hex> [ > | >> <file> ]
 * Description: Compares two areas of memory, original and new, if they are equal.
 *              Writes the complete new area to <file> (stdout if not specified).
 */
mali_error_code cmd_compare_mem(char * buf)
{
    mali_error_code ret_value;
    unsigned long original_addr;
    unsigned long new_addr;
    unsigned long mem_length;
    char *filename;
    FILE *file_dump;
    int append;
    int close_file;
    int compare_result;

    /* Set default values */
    file_dump = stdout;
    close_file = 0;
    append = 1;

    /* Parse arguments */
    ret_value = _internal_parse_arg_int(buf, &buf, &original_addr, 16, 0);
    if (ret_value != MALI_ERROR_NO_ERROR)
    {
        PRINTERR("Error reading hexaddr0, error code: %d\n", ret_value);
        return ret_value;
    }
    if (! remap)
    {
        if (! (original_addr >= mali_mem_start_addr) )
        {
            PRINTERR("Error; original_addr not inside malimemory, aborting.\n");
            return MALI_ERROR_FUNCTION_FAILED;
        }
        original_addr = original_addr - mali_mem_start_addr;
    }

    ret_value = _internal_parse_arg_int(buf, &buf, &new_addr, 16, 0);
    if (ret_value != MALI_ERROR_NO_ERROR)
    {
        PRINTERR("Error reading hexaddr1, error code: %d\n", ret_value);
        return ret_value;
    }
    if (! remap)
    {
        if (! (new_addr >= mali_mem_start_addr) )
        {
            PRINTERR("Error; new_addr not inside malimemory, aborting.\n");
            return MALI_ERROR_FUNCTION_FAILED;
        }
        new_addr = new_addr - mali_mem_start_addr;
    }

    ret_value = _internal_parse_arg_int(buf, &buf, &mem_length, 16, 0);
    if (ret_value != MALI_ERROR_NO_ERROR)
    {
        PRINTERR("Error reading mem_length, error_code: %d\n", ret_value);
        return ret_value;
    }

    ret_value = _internal_parse_arg_redirect(buf, &buf, &filename, &append);
    if (ret_value != MALI_ERROR_NO_ERROR)
    {
        PRINTERR("Error reading redirect-argument, error code: %d\n", ret_value);
        return ret_value;
    }

    /* Do the compare of memory-regions */
    ret_value = _backend_compare_mem(original_addr, new_addr, mem_length, &compare_result);
    if (ret_value != MALI_ERROR_NO_ERROR)
    {
        PRINTERR("Error doing memory compare, error code: %d\n", ret_value);
        return ret_value;
    }

    /* If result is equal, don't do anything about the content. */
    if (compare_result != 0)
    {
        ret_value = _do_mem_dump(filename, append, close_file, new_addr, new_addr+mem_length);
        if (ret_value != MALI_ERROR_NO_ERROR)
        {
            PRINTERR("Error while dumping memory to file / stdout, error code: %d.\n", ret_value);
            return ret_value;
        }
    }

    if (remap)
    {
        IPRINTF("COMPARE_MEM original_addr:%04lx new_addr:%08lx length:%04lx: %d\n",
                original_addr, new_addr, mem_length, compare_result);
    } else {
        IPRINTF("COMPARE_MEM original_addr:%04lx new_addr:%08lx length:%04lx: %d\n",
                mali_mem_start_addr + original_addr, mali_mem_start_addr + new_addr, mem_length, compare_result);
    }

    return MALI_ERROR_NO_ERROR;
}

/**
 * Command:     compare_reg <hexaddr0> <hexaddr1> [ >|>> <file> ]
 * Description: Compares two registers to check if they are equal.
 *              Writes TRUE or FALSE to <file> (stdout if not specified).
 */
mali_error_code cmd_compare_reg(char * buf)
{
    mali_error_code ret_value;
    unsigned long addr_0;
    unsigned long addr_1;
    unsigned long value_reg_0;
    unsigned long value_reg_1;
    char *filename;
    FILE *file_dump;
    int append;
    int close_file;
    int comp;

    /* Set default values */
    file_dump = stdout;
    close_file = 0;
    append = 1;

    /* Parse arguments */
    ret_value = _internal_parse_arg_int(buf, &buf, &addr_0, 16, 0);
    if (ret_value != MALI_ERROR_NO_ERROR)
    {
        PRINTERR("Error reading hexaddr_0, error code: %d\n", ret_value);
        return ret_value;
    }

    ret_value = _internal_parse_arg_int(buf, &buf, &addr_1, 16, 0);
    if (ret_value != MALI_ERROR_NO_ERROR)
    {
        PRINTERR("Error reading hexaddr_1, error code: %d.\n", ret_value);
        return ret_value;
    }

    ret_value = _internal_parse_arg_redirect(buf, &buf, &filename, &append);
    if (ret_value != MALI_ERROR_NO_ERROR)
    {
        PRINTERR("Error reading redirect-argument, error code: %d.\n", ret_value);
        return ret_value;
    }

    /* Read values from hardware */
    ret_value = _backend_read_reg(addr_0, &value_reg_0);
    if (ret_value != MALI_ERROR_NO_ERROR)
    {
        PRINTERR("Error reading register-value from reg0 (%04lx), error code: %d.\n", addr_0, ret_value);
        return ret_value;
    }

    ret_value = _backend_read_reg(addr_1, &value_reg_1);
    if (ret_value != MALI_ERROR_NO_ERROR)
    {
        PRINTERR("Error reading register-value from reg1 (%04lx), error code: %d.\n", addr_1, ret_value);
        return ret_value;
    }

    /* Check if we're supposed to redirect to file, setup if we are. */
    if (strlen(filename) > 0)
    {
        if (append)
            file_dump = fopen(filename, "a");
        else
            file_dump = fopen(filename, "w");

        close_file = 1;
        if (file_dump == NULL)
        {
            PRINTERR("Error unable to open file %s for writing.\n", filename);
            return MALI_ERROR_NO_ERROR;
        }
    }

    comp = value_reg_0 == value_reg_1;
    if (file_dump != stdout)
        fprintf(file_dump, "%s\n", comp ? _INTERNAL_STR_TRUE : _INTERNAL_STR_FALSE);
    if (close_file)
    {
        fclose(file_dump);
    }
    IPRINTF("COMPARE_REG addr_0:%04lx read:%08lx addr_1:%04lx read:%08lx: %s\n",
            addr_0, value_reg_0, addr_1, value_reg_1, comp ? _INTERNAL_STR_TRUE : _INTERNAL_STR_FALSE);

    return MALI_ERROR_NO_ERROR;
}

/**
 * Command:     dump_mem <from_hexaddr> <to_hexaddr> [>|>> <file>]
 * Description: Dumps memory. From address is inclusive, to
 *              address is exclusive. Both support byte alignments.
 *              Dump goes to stdout, or can be redirected to or
 *              appended to a file.
 */
mali_error_code cmd_dump_mem(char * buf)
{
    mali_error_code ret_value;
    unsigned long mem_addr_from;
    unsigned long mem_addr_to;
    char *filename;
    FILE *file_dump;
    int append;
    int close_file;

    /* Set default values */
    file_dump = stdout;
    close_file = 0;
    append = 1;

    /* Parse arguments */
    ret_value = _internal_parse_arg_int(buf, &buf, &mem_addr_from, 16, 0);
    if (ret_value != MALI_ERROR_NO_ERROR)
    {
        PRINTERR("Error reading mem_addr_from, error code: %d\n", ret_value);
        return ret_value;
    }
    if (!remap)
    {
        if (! (mem_addr_from >= mali_mem_start_addr) )
        {
            PRINTERR("Error; mem_addr_from not in malimemory, aborting.\n");
            return MALI_ERROR_FUNCTION_FAILED;
        }
        mem_addr_from = mem_addr_from - mali_mem_start_addr;
    }

    ret_value = _internal_parse_arg_int(buf, &buf, &mem_addr_to, 16, 0);
    if (ret_value != MALI_ERROR_NO_ERROR)
    {
        PRINTERR("Error reading mem_addr_to, error code: %d.\n", ret_value);
        return ret_value;
    }
    if (!remap)
    {
		// using physical addresses
        if (! (mem_addr_to >= mali_mem_start_addr) )
        {
            PRINTERR("Error; mem_addr_to not in malimemory, aborting.\n");
            return MALI_ERROR_FUNCTION_FAILED;
        }
        mem_addr_to = mem_addr_to - mali_mem_start_addr;
    }

    ret_value = _internal_parse_arg_redirect(buf, &buf, &filename, &append);
    if (ret_value != MALI_ERROR_NO_ERROR)
    {
        PRINTERR("Error reading redirect-argument, error code: %d.\n", ret_value);
        return ret_value;
    }

    /* Status-log prinout */
    if (remap)
    {
        IPRINTF("DUMP_MEM addr_from:%04lx addr_to:%04lx\n",
                mem_addr_from, mem_addr_to);
    } else {
        IPRINTF("DUMP_MEM addr_from:%04lx addr_to:%04lx\n",
                mali_mem_start_addr + mem_addr_from, mali_mem_start_addr + mem_addr_to);
    }

    /* This is shared by cmd_compare_mem */
    ret_value = _do_mem_dump(filename, append, close_file, mem_addr_from, mem_addr_to);
    if (ret_value != MALI_ERROR_NO_ERROR)
    {
        PRINTERR("Error while dumping memory to file / stdout, error code: %d.\n", ret_value);
        return ret_value;
    }


    return MALI_ERROR_NO_ERROR;
}


/**
 * Command:     dump_reg <from_hexaddr> <to_hexaddr> [>|>> <file>]
 * Description: Dumps register values. From address is inclusive, to
 *              address is exclusive. Both support byte alignments.
 *              Dump goes to stdout, or can be redirected to or
 *              appended to a file.
 */
mali_error_code cmd_dump_reg(char * buf)
{
    mali_error_code ret_value;
    unsigned long reg_addr_from;
    unsigned long reg_addr_to;
    unsigned long reg_addr_current;
    unsigned long reg_addr_diff;
    unsigned long outword[4];
    unsigned long mask;
    char *filename;
    FILE *file_dump;
    int append;
    int close_file;

    /* Set default values */
    file_dump = stdout;
    close_file = 0;
    append = 1;
    mask = 0;
    for (int i = 0; i < 4; i++)
    {
        outword[i] = 0;
    }

    /* Parse arguments */
    ret_value = _internal_parse_arg_int(buf, &buf, &reg_addr_from, 16, 0);
    if (ret_value != MALI_ERROR_NO_ERROR)
    {
        PRINTERR("Error reading reg_addr_from, error code: %d\n", ret_value);
        return ret_value;
    }

    ret_value = _internal_parse_arg_int(buf, &buf, &reg_addr_to, 16, 0);
    if (ret_value != MALI_ERROR_NO_ERROR)
    {
        PRINTERR("Error reading reg_addr_to, error code: %d.\n", ret_value);
        return ret_value;
    }

    ret_value = _internal_parse_arg_redirect(buf, &buf, &filename, &append);
    if (ret_value != MALI_ERROR_NO_ERROR)
    {
        PRINTERR("Error reading redirect-argument, error code: %d.\n", ret_value);
        return ret_value;
    }

    /* Status-log prinout */
    IPRINTF("DUMP_REG addr_from:%04lx addr_to:%04lx\n",
            reg_addr_from, reg_addr_to);

    /* Check if we're supposed to redirect to file, setup is we are. */
    if (strlen(filename) > 0)
    {
        if (append)
            file_dump = fopen(filename, "a");
        else
            file_dump = fopen(filename, "w");

        close_file = 1;
        if (file_dump == NULL)
        {
            PRINTERR("Error unable to open file %s for writing.\n", filename);
            return MALI_ERROR_FUNCTION_FAILED;
        }
    }

    /* Dump actual registers */
    /* NOTE!  This code currently allows for byte-selection of registers, it */
    /* shouldn't, as registers are always 32 bits. */
    reg_addr_current = reg_addr_from;
    while (reg_addr_current < reg_addr_to)
    {
        unsigned int wordnr;
        char print_buf_start[128];
        char *print_buf;

        wordnr = (reg_addr_current>>2)&3;
        reg_addr_diff = reg_addr_to - reg_addr_current;
        if (reg_addr_diff > 3)
        {
            for (int i=0; i < 4; i++)
                mask |= 1<<((reg_addr_current+i)&0xf);
        } else {
            /* Less than four bytes (32 bits) left to care about */
            for (int i=0; i < reg_addr_diff; i++)
                mask |= 1<<((reg_addr_current+i)&0xf);
        }

        /* Read out whole, aligned, words */
        ret_value = _backend_read_reg(reg_addr_current&0xFFFFFFFC, &outword[wordnr]);
        if (ret_value != MALI_ERROR_NO_ERROR)
        {
            PRINTERR("Error while reading from register, error code: %d\n", ret_value);
            return MALI_ERROR_FUNCTION_FAILED;
        }

        /* Print out */
        if ( (wordnr==3) || (((reg_addr_current&0xFFFFFFFC)+4) >= reg_addr_to) )
        {
            print_buf = print_buf_start;
            _internal_dump_write_line(print_buf, &print_buf, reg_addr_current, &outword[0], mask);
            fprintf(file_dump, print_buf);
            mask = 0;
        }

        /* Aligned */
        reg_addr_current = (reg_addr_current&0xFFFFFFFC)+4;
    }


    if (close_file)
    {
        fclose(file_dump);
    }

    return MALI_ERROR_NO_ERROR;
}

/**
 * Command:     inject_read_error
 * Description: Makes the memorymodel in the testbench return ERROR on
 *              a read access, since this is a testbench-related
 *              feature it's not available on FPGA-platforms.
 */
mali_error_code cmd_inject_read_error(char * buf)
{
    IPRINTF("*** INJECT_READ_ERROR not available on platform.\n");
    return MALI_ERROR_NO_ERROR;
}

/**
 * Command:     inject_write_error
 * Description: Makes the memorymodel in the testbench return ERROR on
 *              a write access, since this is a testbench-related
 *              feature it's not available on FPGA-platforms.
 */
mali_error_code cmd_inject_write_error(char * buf)
{
    IPRINTF("*** INJECT_WRITE_ERROR not available on platform.\n");
    return MALI_ERROR_NO_ERROR;
}

/**
 * Command:     load_mem <file> [<hex_address_offset>]
 * Description: Loads a memory dump from file.
 *              Optionally, the file may be loaded at an offset
 *              from the address stored in the file.
 */
mali_error_code cmd_load_mem(char * buf)
{
    mali_error_code ret_value;
    unsigned long mem_offset;
    unsigned long mem_cur_address;
    unsigned long mem_value;
    unsigned long inword[4];
    unsigned long mask;
    unsigned long cur_mask;
    unsigned long expanded_mask;
    unsigned long read_elements;
    char *filename;
#define READ_BUFFER_SIZE    4096
    char read_buffer[READ_BUFFER_SIZE];
    char *read_ptr;
    char *nxt_ptr;
    char *parse_ptr;
    char tmps[READ_BUFFER_SIZE];
    FILE *file_dump;
    unsigned int line_no;
    unsigned int buf_start;

    /* Set default values */
    mask = 0;
    mem_offset = 0;
    line_no = 0;
    for (int i = 0; i < 4; i++)
    {
        inword[i] = 0;
    }

    /* Parse arguments */
    ret_value = _internal_parse_arg_str(buf, &buf, &filename);
    if (ret_value != MALI_ERROR_NO_ERROR)
    {
        PRINTERR("Error reading filename, error code: %d\n", ret_value);
        return ret_value;
    }

    ret_value = _internal_parse_arg_int(buf, &buf, &mem_offset, 16, 0);
    if (ret_value != MALI_ERROR_NO_ERROR)
    {
        PRINTERR("Error reading address_offset, error code: %d.\n", ret_value);
        return ret_value;
    }

    /* Status-log prinout */
    IPRINTF("LOAD_MEM filename:%s address_offset:%04lx\n",
            filename, mem_offset);

    file_dump =  fopen(filename, "r");
    if (file_dump == NULL)
    {
        PRINTERR("Error unable to open file %s for reading.\n", filename);
        return MALI_ERROR_FUNCTION_FAILED;
    }

    /* Read file and write to memory */
    memset(read_buffer, 0, READ_BUFFER_SIZE);
    nxt_ptr = NULL;
    read_ptr = NULL;
    buf_start = 0;

    while (1)
    {
        if (feof(file_dump))
        {
            /* We've reached eof, break out... */
            break;
        }

        read_elements = fread(&read_buffer[buf_start], sizeof(char), (READ_BUFFER_SIZE-1)-buf_start, file_dump);
        if (read_elements > 0)
        {
            if (read_elements < READ_BUFFER_SIZE-2-buf_start)
            {
                /* Add newline to end of buffer, just to make things easy... */
                read_buffer[read_elements+buf_start] = '\n';
                read_buffer[read_elements+buf_start+1] = '\0';
            } else {
                /* Add a \0 to make this work */
                read_buffer[READ_BUFFER_SIZE-1] = '\0';
            }

            nxt_ptr = read_buffer;

            while (nxt_ptr != NULL)
            {
                read_ptr = nxt_ptr;
                /* Prepare next buffer */
                nxt_ptr = index(nxt_ptr, '\n');
                if (nxt_ptr == NULL)
                {
                    /* No more newline, add last parts of buffer to next readin */
                    buf_start = strlen(read_ptr);

                    strncpy(read_buffer, read_ptr, buf_start);
                    read_buffer[buf_start] = '\0';
                    break;
                }
                *nxt_ptr = '\0';
                nxt_ptr++;
                line_no++;

                /* Now get down to business and start parsing the data in read_ptr */
                if ( (strlen(read_ptr) < 2) || (read_ptr[0] == '#') )
                {
                    /* skip empty/commented lines... */
                    continue;
                }

                parse_ptr = read_ptr;
                strncpy(tmps, (char *) &read_ptr[10], 35);

                /* Parse line */
                ret_value = _internal_parse_dump_line(parse_ptr, &mem_cur_address, &inword[0], &mask);
                if (ret_value != MALI_ERROR_NO_ERROR)
                {
                    PRINTERR("Error parsing dump_line, error code: %d.\n", ret_value);
                    return ret_value;
                }
                mem_cur_address += mem_offset;

                if (!remap)
                {
					// using physical addresses
                    if (! (mem_cur_address >= mali_mem_start_addr) )
                    {
                        printf("*** %s\n", read_ptr);
                        PRINTERR("Error; mem_cur_address (%08lx) on line #%d not in malimemory (%08d), aborting.\n", mem_cur_address, line_no, mali_mem_start_addr);
                        return MALI_ERROR_FUNCTION_FAILED;
                    }
                    // substract the Mali base address to switch to relative addresses
                    mem_cur_address = mem_cur_address - mali_mem_start_addr;
                }

                /* Do any (if any, that is) read, modify before we write it all */
                if (debug_print)
                    fprintf(stdout, "%08lx: %s  => ", mem_cur_address, tmps);
                for (int cur_word = 0; cur_word < 4; cur_word++)
                {
                    cur_mask = (mask & (0xf << (cur_word*4))) >> (cur_word*4);
                    if (cur_mask < 0xf)
                    {
                        /* We need to read and modify. */
                        _backend_memory_read_word(mem_cur_address + (cur_word*4), &mem_value);
                        expanded_mask = 0;
                        for (int cur_byte = 0; cur_byte < 4; cur_byte++)
                            expanded_mask += (cur_mask & 1<<cur_byte) ? (0xff << (cur_byte*8)) : 0x00;
                        inword[cur_word] |= mem_value & ~expanded_mask;
                    }
                    if (debug_print)
                        fprintf(stdout, " %08lx", inword[cur_word]);
                    _backend_memory_write_word(mem_cur_address + (cur_word*4), inword[cur_word]);
                }
                if (debug_print)
                    fprintf(stdout, "\n");
            }
        }
    }
    fclose(file_dump);

    return MALI_ERROR_NO_ERROR;
}



/**
 * Command:     load_reg <file> [<hex_address_offset>]
 * Description: Loads a register dump from file.
 *              Optionally, the file may be loaded at an offset
 *              from the address stored in the file.
 */
mali_error_code cmd_load_reg(char * buf)
{
    mali_error_code ret_value;
    unsigned long reg_offset;
    unsigned long reg_cur_address;
    unsigned long inword[4];
    unsigned long mask;
    unsigned long cur_mask;
    char *filename;
    char read_buffer[4096];
    char *read_ptr;
    char tmps[4096];
    FILE *file_dump;

    /* Set default values */
    mask = 0;
    reg_offset = 0;
    for (int i = 0; i < 4; i++)
    {
        inword[i] = 0;
    }

    /* Parse arguments */
    ret_value = _internal_parse_arg_str(buf, &buf, &filename);
    if (ret_value != MALI_ERROR_NO_ERROR)
    {
        PRINTERR("Error reading filename, error code: %d\n", ret_value);
        return ret_value;
    }

    ret_value = _internal_parse_arg_int(buf, &buf, &reg_offset, 16, 0);
    if (ret_value != MALI_ERROR_NO_ERROR)
    {
        PRINTERR("Error reading reg_address_offset, error code: %d.\n", ret_value);
        return ret_value;
    }

    /* Status-log prinout */
    IPRINTF("LOAD_REG filename:%s reg_offset:%04lx\n",
            filename, reg_offset);

    file_dump =  fopen(filename, "r");
    if (file_dump == NULL)
    {
        PRINTERR("Error unable to open file %s for reading.\n", filename);
        return MALI_ERROR_FUNCTION_FAILED;
    }

    /* Read file and write to memory */
    while (1)
    {
        if (fgets(read_buffer, 4096, file_dump) == NULL)
        {
            /* We've reached eof, break out... */
            break;
        }
        if ( (strlen(read_buffer) < 2) ||
             (read_buffer[0] == '#') )
        {
            /* Skip empty/commented lines... */
            continue;
        }
        read_ptr = read_buffer;
        strncpy(tmps, (char *) &read_buffer[10], 35);

        /* Parse line */
        ret_value = _internal_parse_dump_line(read_ptr, &reg_cur_address, &inword[0], &mask);
        if (ret_value != MALI_ERROR_NO_ERROR)
        {
            PRINTERR("Error parsing dump_line, error code: %d.\n", ret_value);
            return ret_value;
        }
        reg_cur_address += reg_offset;

        /* Only write registers with a mask of 0xf, */
        /* no read/modify/write on registers.       */
        if (debug_print)
            fprintf(stdout, "%08lx: %s  => ", reg_cur_address, tmps);
        for (int cur_word = 0; cur_word < 4; cur_word++)
        {
            cur_mask = (mask & (0xf << (cur_word*4))) >> (cur_word*4);
            if (cur_mask == 0xf)
            {
                if (debug_print)
                    fprintf(stdout, " %08lx", inword[cur_word]);
                _backend_write_reg(reg_cur_address + (cur_word*4), inword[cur_word]);
            } else {
                if (debug_print)
                    fprintf(stdout, " skipping");
            }
        }
        if (debug_print)
            fprintf(stdout, "\n");
    }
    fclose(file_dump);

    return MALI_ERROR_NO_ERROR;
}

/**
 * Command:     quit
 * Description: quits the program / parser.
 */
mali_error_code cmd_quit(char * buf)
{
    IPRINTF("QUIT\n");
    closing();
    exit(0);
    return MALI_ERROR_NO_ERROR;
}

/**
 * Command:     readlatency <decvalue>
 * Description: Changes number of cycles between read access is
 *              accepted till data is returned to <decvalue>
 */
mali_error_code cmd_readlatency(char * buf)
{
    IPRINTF("*** READLATENCY not available on platform.\n");
    return MALI_ERROR_NO_ERROR;
}

/**
 * Command:     reset
 * Description: Asserts the nRESET signal for several cycles.
 *              May have side effects like loading of an MMU
 *              page table.
 */
mali_error_code cmd_reset(char * buf)
{
    IPRINTF("RESET core(s)\n");
    return _backend_reset_cores(remap);
}

/**
 * Command:     timeout <decvalue>
 * Description: Sets the max simulation timeout limit to <decvalue>
 *              clock cycles.
 */
mali_error_code  cmd_timeout(char *buf)
{
    mali_error_code ret_value;
    unsigned long new_value;

    ret_value = _internal_parse_arg_int(buf, &buf, &new_value, 10, 0);
    if (ret_value != MALI_ERROR_NO_ERROR)
    {
        PRINTERR("Error parsing timeout-value, error code: %d.\n", ret_value);
        return ret_value;
    }

    if (new_value)
    {
        timeoutval = new_value;
    }

    IPRINTF("TIMEOUT value set to %u\n", timeoutval);
    return MALI_ERROR_NO_ERROR;
}

/**
 * Command:     wait [posedge|negedge] irq
 *              wait [posedge|negedge] clk <decvalue>
 *              wait irq <mask> [<value>]
 * Description: Stalls script execution waiting for the given event. The
 *              event can be a positive or negatie edge of any irq, a
 *              <decvalue> number of clock cycles, or a specific
 *              interrupt mask value
 *              - The "wait irq" command uses a 32-bit interrupt
 *                vector defined as:
 *                - [31:24] Others (Currently [24] is MMU)
 *                - [23:16] Geometry processors 7-0
 *                - [15: 0] Pixels processors 15-0
 *              - irq <mask> waits until the masked interrupt vector
 *                is non-zero.
 *              - irq <mask> <value> waits until the masked interrupts
 *                equals the specified value.
 */
mali_error_code cmd_wait(char * buf)
{
    mali_error_code ret_value;
    char *strarg_1, *strarg_2;
    unsigned long irq_mask, core_mask;
    unsigned long clk_value;
    unsigned int edge_triggered;

    /* defaults */
    irq_mask = 0;
    core_mask = 0;
    clk_value = 0;
    edge_triggered = 0;

    ret_value = _internal_parse_arg_str(buf, &buf, &strarg_1);
    if (ret_value != MALI_ERROR_NO_ERROR)
    {
        PRINTERR("Error parsing first argument of wait-command, error code: %d.\n", ret_value);
        return ret_value;
    }

    if ((strcasecmp(strarg_1, "posedge")==0) ||
        (strcasecmp(strarg_1, "negedge")==0))
    {
        /* wait posedge/negedge irq/clk will be caught inside here. */
        edge_triggered = 1;

        /* Trigger-edge specified, read string arg */
        ret_value = _internal_parse_arg_str(buf, &buf, &strarg_2);
        if (ret_value != MALI_ERROR_NO_ERROR)
        {
            PRINTERR("Error parsing trigger-type argument (should be irq or clk), error code: %d.\n", ret_value);
            return ret_value;
        }

        /* Only clk will have this argument, just try to read it anyway. */
        ret_value = _internal_parse_arg_int(buf, &buf, &clk_value, 10, 0);
        if (ret_value != MALI_ERROR_NO_ERROR)
        {
            PRINTERR("Error parsing decvalue for clock cycles, error code: %d.\n", ret_value);
            return ret_value;
        }

    } else if (strcasecmp(strarg_1, "clk")==0)
    {
        /* wait clk will be caught inside here. */

        /* Try to read clock cycles */
        ret_value = _internal_parse_arg_int(buf, &buf, &clk_value, 10, 0);
        if (ret_value != MALI_ERROR_NO_ERROR)
        {
            PRINTERR("Error parsing decvalue for clock cycles, error code: %d.\n", ret_value);
            return ret_value;
        }

    } else if (strcasecmp(strarg_1, "irq")==0)
    {
        /* wait irq / wait irq <mask> [<value>] will be caught inside here. */

        ret_value = _internal_parse_arg_int(buf, &buf, &irq_mask, 16, 0);
        if (ret_value != MALI_ERROR_NO_ERROR)
        {
            PRINTERR("Error parsing irq_mask, error code: %d.\n", ret_value);
            return ret_value;
        }

        ret_value = _internal_parse_arg_int(buf, &buf, &core_mask, 16, 0);
        if (ret_value != MALI_ERROR_NO_ERROR)
        {
            PRINTERR("Error parsing core_mask, error code: %d.\n", ret_value);
            return ret_value;
        }
    }

    if (edge_triggered)
    {
        if (clk_value)
        {
            /* wait [pos/neg]edge clk <decvalue> */
            IPRINTF("WAIT %s clk %lu\n", strarg_1, clk_value);
            _backend_wait_cycles(clk_value);
        } else
        {
            /* wait [pos/neg]edge irq */
            IPRINTF("WAIT %s irq\n", strarg_1);
            _backend_wait_irq();
        }
    } else if (clk_value)
    {
        /* wait clk <decvalue> */
        IPRINTF("WAIT clk %lu\n", clk_value);
        _backend_wait_cycles(clk_value);
    } else if (!irq_mask)
    {
        /* wait irq */
        IPRINTF("WAIT irq\n");
        _backend_wait_irq();
    } else if (irq_mask)
    {
        if (!core_mask)
        {
            /* wait irq <mask> */
            IPRINTF("WAIT irq mask:%08lx\n", irq_mask);
            _backend_wait_irqmask( irq_mask, 0 );  // No specific core select, wait for any core
        } else
        {
            /* wait irq <mask> <value> */
            IPRINTF("WAIT irq mask:%08lx value:%08lx\n", irq_mask, core_mask);
            _backend_wait_irqmask( irq_mask, core_mask );
        }
    } else
    {
        PRINTERR("Undefined wait-statement, this could be a bug.\n");
        return MALI_ERROR_FUNCTION_FAILED;
    }

    return MALI_ERROR_NO_ERROR;
}

/**
 * Command:     writelatency <decvalue>
 * Description: Changes number of cycles between write data valid
 *              on the bus till data is accepted to <decvalue>.
 */
mali_error_code cmd_writelatency(char * buf)
{
    IPRINTF("*** WRITELATENCY not available on platform.\n");
    return MALI_ERROR_NO_ERROR;
}

/**
 * Command:     writelen [text]
 * Description: Writes [text] to STDOUT.
 */
mali_error_code cmd_writeln(char * buf)
{
    fprintf(stdout, "  %s\n", buf);
    IPRINTF("WRITELN %s\n", buf);
    return MALI_ERROR_NO_ERROR;
}

/**
 * Command:     writereg <hexaddr> <hexvalue>
 * Description: Writes <hexvalue> to a register at <hexaddr>.
 *              Side effects may occur.
 */
mali_error_code cmd_writereg(char * buf)
{
    mali_error_code ret_value;
    unsigned long reg_addr;
    unsigned long reg_value;

    /* Parse arguments */
    ret_value = _internal_parse_arg_int(buf, &buf, &reg_addr, 16, 0);
    if (ret_value != MALI_ERROR_NO_ERROR)
    {
        PRINTERR("Error reading reg_addr, error code: %d\n", ret_value);
        return ret_value;
    }

    ret_value = _internal_parse_arg_int(buf, &buf, &reg_value, 16, 0);
    if (ret_value != MALI_ERROR_NO_ERROR)
    {
        PRINTERR("Error reading reg_value, error code: %d.\n", ret_value);
        return ret_value;
    }

    /* Status-log printout */
    IPRINTF("WRITEREG reg_addr:%04lx reg_value:%08lx\n",
            reg_addr, reg_value);

    ret_value = _backend_write_reg(reg_addr, reg_value);
    if (ret_value != MALI_ERROR_NO_ERROR)
    {
        PRINTERR("Error writing value to register, error code: %d.\n", ret_value);
    }

    return MALI_ERROR_NO_ERROR;
}

/**
 * Reads config.txt (or a file with same syntax).
 */
mali_error_code cmd_read_configtxt(char *filename)
{
    FILE * config_file;
    char parse_txt[4096];
    char *parse_current;
    while( isspace(*filename)) filename++;
    IPRINTF("Executing commands in \"%s\"\n",filename);

    config_file = fopen(filename, "r");
    if (!config_file)
    {
        printf("! Could not find the input file.\n");
        print_help();
        return MALI_ERROR_FUNCTION_FAILED;
    }

    while (1)
    {
        if ( !fgets(parse_txt, 4096, config_file) )
        {
            break;
        }
        parse_current = parse_txt;
        while (isspace(*parse_current))  parse_current++;
        if (strlen(parse_current) == 0)
        {
            continue;
        }
        cmd_exec(parse_current);
        _backend_flush();
    }
    fclose(config_file);
    return MALI_ERROR_NO_ERROR;
}



/**
 * Execute-function responsible of dispatching
 * call to correct cmd_-function
 */
mali_error_code cmd_exec(char * cmd)
{
    int i;
    int len;
    char *param;

    while(isspace(*cmd)) cmd++;
    if (*cmd=='#') return 0;
    while(1)
    {
        param = strpbrk(cmd, "\t\r\n\"\';");
        if(!param) break;
        *param = ' ';
    }
    /*strcspn(cmd, " .,=;:\0\t\r\n");*/

    for (i=0; i< CMD_LIST_SIZE; i++)
    {
        len = strlen(cmd_list[i].name);
        if (! strncasecmp(cmd_list[i].name,cmd,len) )
        {
            if ( isgraph(*(cmd+len)) ) continue;
            param = cmd+len;
            while( isspace(*param) ) param++;

            DPRINTF("  Running cmd: \"%s\", with param: \"%s\"\n", cmd_list[i].name, param);
            return cmd_list[i].function(param);
        }
    }

    printf("!!!  Command not found:  %s\n", cmd);
    return MALI_ERROR_FUNCTION_FAILED;
}


void print_help()
{
    printf("  ***********************************************************)\n");
    printf("  *  Test Bench Util (tb_util)                              *)\n");
    printf("  *                                                         *)\n");
    printf("  *                                                         *)\n");
    printf("  *  A program that can control Mali PP+GP through the      *)\n");
    printf("  *  command line, or a file with a command list.           *)\n");
    printf("  *                                                         *)\n");
    printf("  *  This program will execute                              *)\n");
    printf("  *  commands found in the file \"config.txt\" in the       *)\n");
    printf("  *  current directory.                                     *)\n");
    printf("  *                                                         *)\n");
    printf("  *  The type of the Mali core used MUST be specified with  *)\n");
    printf("  *  the option:                                            *)\n");
    printf("  *    -c <mali_core> (<mali_core> = mali200, mali300       *)\n");
    printf("  *    mali400 or mali450.                                  *)\n");
    printf("  *  If <mali_core> = mali400, then the number of Pixel     *)\n");
    printf("  *  Processors must be provided with -nb_pp <n>,           *)\n");
    printf("  *  (1 <= <n> <= 4)                                        *)\n");
    printf("  *  If <mali_core> = mali450, then the number of Pixel     *)\n");
    printf("  *  Processors must be provided with -nb_pp <n>,           *)\n");
    printf("  *  (1 <= <n> <= 8)                                        *)\n");
    printf("  *                                                         *)\n");
    printf("  *  For mali300, mali400 or mali450 the -p switch will     *)\n");
    printf("  *  enable PMU support.                                    *)\n");
    printf("  *                                                         *)\n");
    printf("  *  If you write -d,--d or \"debug\" on the cmd line, the  *)\n");
    printf("  *  program will show some additional debug info.          *)\n");
    printf("  *                                                         *)\n");
    printf("  *  To execute an other cmd list file than \"config.txt\"  *)\n");
    printf("  *  type -f --f or \"file\" and the file name.             *)\n");
    printf("  *                                                         *)\n");
    printf("  *  To use the program with virtual addresses starting     *)\n");
    printf("  *  from 0x0 and allow the program to set up the MMU table *)\n");
    printf("  *  and configure the MMU(s), type -r.                     *)\n");
    printf("  *  The address 0x0 will then be remapped to the Mali      *)\n");
    printf("  *  memory physical base address.                          *)\n");
    printf("  *                                                         *)\n");
    printf("  *  Text after a \"#\" will not be parsed. All nrs are hex.*)\n");
    printf("  *  All commands are case insensitive.                     *)\n");
    printf("  *                                                         *)\n");
    printf("  *  Valid commmands are:                                   *)\n");
    printf("  *   buslog <value>                                        *)\n");
    printf("  *   check_reg <hexaddr> <op> <hexvalue> [ >|>> <file>]    *)\n");
    printf("  *   clear_mem <start_hexaddr> <end_hexaddr> [<hexval>=0]  *)\n");
    printf("  *   compare_mem <origaddr0> <newaddr1> <len> [>|>> <file>]*)\n");
    printf("  *   compare_reg <hexaddr0> <hexaddr1> [ >|>> <file> ]     *)\n");
    printf("  *   dump_mem <from_hexaddr> <to_hexaddr> [>|>> <file>]    *)\n");
    printf("  *   dump_reg <from_hexaddr> <to_hexaddr> [>|>> <file>]    *)\n");
    printf("  *   inject_read_error                                     *)\n");
    printf("  *   inject_write_error                                    *)\n");
    printf("  *   load_mem <file> [<hex_address_offset>]                *)\n");
    printf("  *   load_reg <file> [<hex_address_offset>]                *)\n");
    printf("  *   quit                                                  *)\n");
    printf("  *   readlatency <decvalue>                                *)\n");
    printf("  *   reset                                                 *)\n");
    printf("  *   timeout [timeunits]                                   *)\n");
    printf("  *   wait [posedge|negedge] irq                            *)\n");
    printf("  *   wait [posedge|negedge] clk <decvalue>                 *)\n");
    printf("  *   wait irq <mask> [<value>]                             *)\n");
    printf("  *   writelatency <decvalue>                               *)\n");
    printf("  *   writeln [text]                                        *)\n");
    printf("  *   writereg <hexaddr> <hexvalue>                         *)\n");
    printf("  ***********************************************************)\n");
    printf("\n");
}


int main(int argc, char** argv)
{
    char config_txt[1024];
    char backend_config[1024];
    char mali_core[8];
    unsigned char nb_pp = 1;
    unsigned char pmu = 0;
    mali_error_code ret_value;
    
    /* initialize to empty string */
    memset(config_txt, 0, 1024);


    /* initialize to empty string */
    config_txt[0] = '\0';
	

    if (argc> 1)
    {
        for (int cur_arg = 1; cur_arg < argc; )
        {
            // strncasecmp(str1,str2,len)
            // Compare str1 and str2 the length of charactors. if is equal, then return 0.
            if (!strncasecmp(argv[cur_arg], "-c", 2) ||
                !strncasecmp(argv[cur_arg], "--c", 3) ||
                !strncasecmp(argv[cur_arg], "core", 4))
            {
                strncpy(mali_core, argv[cur_arg+1], 8);
                cur_arg += 2;
                continue;
            }

            if (!strncasecmp(argv[cur_arg], "-nb_pp", 2) ||
                !strncasecmp(argv[cur_arg], "--nb_pp", 3) ||
                !strncasecmp(argv[cur_arg], "nb_pp", 4))
            {
                // strtoll(str1), return the integer of the string "str1"
                nb_pp = (unsigned char) strtoll(argv[cur_arg+1], NULL, 10);
                cur_arg += 2;
                continue;
            }

            if (!strncasecmp(argv[cur_arg], "-h", 2) ||
                !strncasecmp(argv[cur_arg], "--h", 3) ||
                !strncasecmp(argv[cur_arg], "help", 4))
            {
                print_help();
                exit(0);
            }

            if (!strncasecmp(argv[cur_arg], "-p", 2) ||
                !strncasecmp(argv[cur_arg], "--p", 3) ||
                !strncasecmp(argv[cur_arg], "pmu", 3))
            {
                pmu = 1;
                cur_arg++;
                continue;
            }


            if (!strncasecmp(argv[cur_arg], "-d", 2) ||
                !strncasecmp(argv[cur_arg], "--d", 3) ||
                !strncasecmp(argv[cur_arg], "debug", 5) )
            {
                printf("Debug enabled\n");
                debug_print = 1;
                cur_arg++;
                continue;
            }

            if (!strncasecmp(argv[cur_arg], "-r", 2) ||
                !strncasecmp(argv[cur_arg], "--r", 3) ||
                !strncasecmp(argv[cur_arg], "remap", 5))
            {
		            mali_mem_start_addr = 0;
                remap = 1;
                cur_arg ++;
                continue;
            }

            if (!strncasecmp(argv[cur_arg], "-f", 2) ||
                !strncasecmp(argv[cur_arg], "--f", 3) ||
                !strncasecmp(argv[cur_arg], "file", 4))
            {
                strncpy(config_txt, argv[cur_arg+1], 1024);
                cur_arg += 2;
                continue;
            }

            if (!strncasecmp(argv[cur_arg], "-b", 2) ||
                !strncasecmp(argv[cur_arg], "--b", 3) ||
                !strncasecmp(argv[cur_arg], "backend_config", 14))
            {
                strncpy(backend_config, argv[cur_arg+1], 1024);
                cur_arg += 2;
                continue;
            }

            cur_arg++;
        }
    }

    if (strncasecmp(mali_core, "mali200", 7) && strncasecmp(mali_core, "mali400", 7) && strncasecmp(mali_core, "mali450", 7) && strncasecmp(mali_core, "mali300", 7)) {
		PRINTERR("Please provide the Mali core type with -c.\n");
		return 0;
	}

     if (!strncasecmp(mali_core, "mali200", 7) && pmu) {
                PRINTERR("Mali200 doesn't have PMU support. Please remove the PMU switch.\n");
                return 0;
        }


    if ((!strncasecmp(mali_core, "mali400", 7)) && nb_pp < 1 && nb_pp > 4) {
		PRINTERR("Please provide the number of Pixel Processors used with -nb_pp (1 <= n <= 4).\n");
		return 0;
	}

    if ((!strncasecmp(mali_core, "mali450", 7)) && nb_pp < 1 && nb_pp > 8) {
		PRINTERR("Please provide the number of Pixel Processors used with -nb_pp (1 <= n <= 8).\n");
		return 0;
	}

    init(mali_core, nb_pp, pmu, remap);

    if (strlen(backend_config)>0)
    {
        ret_value = _backend_read_config(backend_config);
        if (ret_value != MALI_ERROR_NO_ERROR)
        {
            PRINTERR("Backend returned error while parsing it's config file, error code: %d.\n", ret_value);
            return ret_value;
        }
    }

    if (strlen(config_txt)==0)
    {
	    cmd_read_configtxt("config.txt");
    } else {
	    cmd_read_configtxt(config_txt);
    }

    closing();
    return 0;
}

