//----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
// (C) COPYRIGHT 2006 ARM Limited.
// ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
// Checked In : $Date: 2012-06-05 15:18:54 +0200 (Tue, 05 Jun 2012) $
// Revision : $Revision: 131145 $
//
//----------------------------------------------------------------------------

#ifndef __TB_UTIL_H
#define __TB_UTIL_H

/* Typedefs */
/**
 */
typedef enum mali_error_code
{
    MALI_ERROR_NO_ERROR           =  0,
    MALI_ERROR_OUT_OF_MEMORY      = -1,
    MALI_ERROR_FUNCTION_FAILED    = -2,
    MALI_ERROR_NOTHING_TO_DO      = -3,
} mali_error_code;

/**
 */
typedef mali_error_code cmd_function(char* buf);


/* Functions inside tb_util.c */
void print_help();

extern int debug_print;


/* Select if you want debug output or not */
#define DPRINTF(...) do{if(debug_print) printf(__VA_ARGS__);}while(0)
#define IPRINTF(...) do{printf("  "__VA_ARGS__);}while(0)
/*#define DPRINTF(A, ...)*/
#define PRINTERR(...)  printf( "ERR: %s(): line:%d " , __FUNCTION__, __LINE__); printf(" " __VA_ARGS__) ; printf("\n")
// #define PRINTERR(...)  printf( "ERR: %s(): line:%d " __VA_ARGS__ "\n", __FUNCTION__, __LINE__)


#define IF_ERR_PRINT_AND_GOTO_FUNCTION_END(...) \
    if ( err != MALI_ERROR_NO_ERROR){\
        PRINTERR(__VA_ARGS__);\
        goto function_end;\
    }\



#endif

