#ifndef RGB565TOBMP_HPP_
#define RGB565TOBMP_HPP_

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
 
#define BI_BITFIELDS 0x3

int Rgb565ConvertBmp(char *buf,int width,int height, const char *filename);

#endif
