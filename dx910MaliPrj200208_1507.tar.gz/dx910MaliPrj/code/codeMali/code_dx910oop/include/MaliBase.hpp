#ifndef MALI_BASE_HPP
#define MALI_BASE_HPP

#include <string.h>
#include <stdlib.h>
#include <iostream>
#include "mali_inline.h"
#define USING_MALI450 1

using namespace std;

#define SCREENSIZE_X        16
#define SCREENSIZE_Y        16
#define RSW_SHADER_ADDR_V1 	0x46000
#define RSW_SHADER_ADDR_V2 	0x46100
#define REG_ADDR_PREFIX		0x80016000
#define W_VALUE             0x003E0000  /* 24bit floating point == 1 */
#define Z_VALUE             0x4000      /* 16bit linear - somewhere in the middle */

#define M200_FRAME_REG_REND_LIST_ADDR_V 	0x00047000
#define M200_FRAME_REG_REND_RSW_BASE_V  	0x00000040
#define M200_FRAME_REG_REND_VERTEX_BASE_V 	0x000440c0
#define M200_WB0_REG_TARGET_ADDR_V  		0x00004060
#define TILE_LIST_VIRTAL_ADDR_V  			0x00050000
#define SLAVE_TILE_LIST_ADDR_V 				0x00047000

//#define MALI_STATIC_INLINE static __inline__
//#define MALI_STATIC_INLINE inline
//#define MALI_STATIC_FORCE_INLINE MALI_STATIC_INLINE

typedef unsigned long	mali_bool;
typedef unsigned char	u8;
typedef signed char	s8;
typedef unsigned short	u16;
typedef signed short	s16;
typedef unsigned int	u32;
typedef signed int	s32;
typedef unsigned long long	u64;
typedef signed long long	s64;


/**
 * Type definition of mali_addr to u32
 */
typedef u32 mali_addr;
typedef u32 cpu_addr;

typedef cpu_addr mali_mem_type ;
typedef cpu_addr* mali_mem_handle;

// typedef struct mali_mem_type
// {
//         //mali_addr mali_address; /**< The Mali seen address of this block. Valid if cpu_address is set*/
//         //void * cpu_address;     /**< The CPU  seen address of this block */
//         cpu_addr* cpu_address;     /**< The CPU  seen address of this block */
// } mali_mem_type, *mali_mem_handle;

typedef enum pp_test_framework_shader
{
    PPTF_SHADER_SIMPLE,
    PPTF_SHADER_HEAVY
} pp_test_framework_shader;

typedef struct pp_test_framework
{
    mali_mem_handle     rsw_list;
    mali_mem_handle     dummy_shader;
    mali_mem_handle     color_shader;
    mali_mem_handle     polygon_list;
    mali_mem_handle     vdb_list[12];
    u16                 *fb_correct[12];
    u32                 number_of_framebuffers;
    u32                 framebuffer_size;
    mali_mem_handle 	framebuffer;
    u16 triangle_color;
    u16 background_color;
} pp_test_framework;

typedef struct pp_test_framework * pp_test_framework_handle;
typedef u32 mali_vdb[16];
typedef u32 m200_rsw[16];
typedef u64 mali_pp_cmd;

/**
 * Type definitions needed for using MaliPP
 */
#define MALLOC_FUNC malloc
#define MALLOC(a) MALLOC_FUNC((a))

/**
 *	Flag a cast as a (potentially complex) value conversion, usually of a numerical type.
 */
#define MALI_STATIC_CAST(type) (type)

/**
 *	Fundamental error macro. Reports an error code. This is abstracted to allow us to
 *	easily switch to a different error reporting method if we want, and also to allow
 *	us to search for error returns easily.
 *
 *	Note no closing semicolon - this is supplied in typical usage:
 *
 *	MALI_ERROR(MALI_ERROR_OUT_OF_MEMORY);
 */
#define MALI_ERROR(error_code) return (error_code)
#define MALI_CHECK(condition, error_code) do { if(!(condition)) MALI_ERROR(error_code); } while(0)
#define MALI_CHECK_NON_NULL(pointer, error_code) MALI_CHECK( ((pointer)!=NULL), (error_code) )
#define MALI_CHECK_GOTO(condition, label) do { if(!(condition)) goto label; } while(0)

pp_test_framework_handle pp_test_framework_context_allocate();

// typedef enum mali_err_code
// {
//     MALI_ERR_NO_ERROR           =  0,
//     MALI_ERR_OUT_OF_MEMORY      = -1,
//     MALI_ERR_FUNCTION_FAILED    = -2,
//     MALI_ERR_EARLY_OUT          = -3,
// #if MALI_TEST_API
//     MALI_ERR_CHECK_ERROR		    = -4,
// #endif
//     MALI_ERR_TIMEOUT            = -5
// } mali_err_code;

/**
 *	Fundamental error macro. Reports an error code. This is abstracted to allow us to
 *	easily switch to a different error reporting method if we want, and also to allow
 *	us to search for error returns easily.
 *
 *	Note no closing semicolon - this is supplied in typical usage:
 *
 *	MALI_ERROR(MALI_ERROR_OUT_OF_MEMORY);
 */
#define MALI_ERROR(error_code) return (error_code)

/**
 *	Basic error macro, to indicate success.
 *	Note no closing semicolon - this is supplied in typical usage:
 *
 *	MALI_SUCCESS;
 */
#define MALI_SUCCESS MALI_ERROR(MALI_ERR_NO_ERROR)

// /**
//  * mali_bus_usage tells what mali cores is allowed to do
//  * to the memory. It is a bit pattern with fields:
//  */
// typedef enum mali_mem_usage_flag
// {
//         MALI_PP_READ   = (1<<0),
//         MALI_PP_WRITE  = (1<<1),
//         MALI_GP_READ   = (1<<2),
//         MALI_GP_WRITE  = (1<<3),
//         MALI_CPU_READ  = (1<<4),
//         MALI_CPU_WRITE = (1<<5),
//         MALI_GP_L2_ALLOC   = (1<<6),  /** GP allocate mali L2 cache lines */
// }mali_mem_usage_flag;

void _mali_mem_write(
        mali_mem_handle to_mali,
        u32 to_offset,
        const void* from,
        u32 size);

void * _mali_sys_memset(void * ptr, u32 value, u32 num);

/**
 * Read data from mali memory into CPU/host memory.
 * @param to Pointer to CPU/host memory to write to
 * @param from_mali The Mali memory block to read from
 * @param from_offset Offset in Mali memory to start read from
 * @param size Number of bytes to read
 */
MALI_STATIC_FORCE_INLINE void _mali_mem_read(
        u32* to,
        mali_mem_handle from_mali,
        u32 from_offset)
{
   //cout<<"from_mali"<<hex<<*from_mali<<endl;
   *to = *(from_mali+from_offset);
   //_mali_base_arch_mem_read(to, (mali_mem*)from_mali, from_offset, size);
}

/**
 * Get the address as seen by mali for mem + offset
 * @param mem The memory handle to return the memory address of
 * @param offset Relative offset inside the buffer
 * @return A Mali memory address
 */
MALI_STATIC_FORCE_INLINE mali_mem_handle _mali_mem_mali_addr_get(mali_mem_handle mem, u32 offset)
{
    if (!mem){
        cout<<"_mali_mem_mali_addr_get Error"<<endl;
        return NULL;
    }else{
      return (mem + offset);
    }
}

#endif
