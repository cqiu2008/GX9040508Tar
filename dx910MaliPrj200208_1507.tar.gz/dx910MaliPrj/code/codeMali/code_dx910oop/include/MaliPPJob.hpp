#ifndef MALI_PP_JOB_HPP_ 
#define MALI_PP_JOB_HPP_ 

#include <string>
#include <string.h>
#include "MaliBase.hpp"
#include "mali_rsw.h"
#include "mali_render_regs.h"
#include "mali200_core.h"
#include "base/mali_types.h"
#include "base/pp/mali_pp_handle.h"

#define MALI_DUMP_ENABLE 1

//#include <stdio.h>

//typedef int MaliPPJobd;
//typedef unsigned int Amount;
//typedef int Amount;
typedef unsigned char Amount;
//using namespace std;

/**
 * Defintion of the base context type
 */
//typedef struct mali_base_ctx_type * mali_base_ctx_handle;

static u32 test_dummy_shader[] =
{
    0x00020425,
    0x0000000C,
    0x01E007CF,
    0xB0000000,
    0x000005F5
};

static u32 test_blue_color_shader[] =
{
    0x00020425,
    0x0000050C,
    0x000007CF,
    0x000001E0,
    0x00000400,
};

static u32 test_heavy_color_shader[] = /* 50x50 iterations per fragment */
{
    0x023a3006,
    0x2000000c,
    0x600307cf,
    0x000003e4,
    0x00000000,
    0x00000000,
    0x021a3807,
    0xbe470030,
    0x8800039c,
    0x202421f3,
    0x00000001,
    0x00000000,
    0x00000000,
    0x02501003,
    0x00000e72,
    0x000007ce,
    0x023b3c0a,
    0x03ff0002,
    0x00418801,
    0x211c80d0,
    0x40eb9e47,
    0x070008e6,
    0xa000001c,
    0x03ffffff,
    0x00000a48,
    0x17800780,
    0x022b2007,
    0x00463106,
    0x0000e030,
    0xffffec00,
    0x0052403f,
    0x0000003c,
    0x00000000,
    0x00021025,
    0x0b90850c,
    0x03c0000f,
    0x00000000,
    0x00000000
};

// /**
//  * Definition of the job priority type.
//  * Jobs with a higher priority will be executed before jobs with lower,
//  * even if the low ones are added first.
//  */
// typedef enum mali_job_priority
// {
//     MALI_JOB_PRI_HIGH,
//     MALI_JOB_PRI_NORMAL,
//     MALI_JOB_PRI_LOW,
//     MALI_JOB_PRI_COUNT
// } mali_job_priority;

/**
 * Definition of pp job state type.
 *
 * Used to indicate in which state a pp job is in.
 *
 * We have these states:
 * 	Pool: A job descriptor which is not currently in use
 * 	Building: A job which the user can modify and start
 * 	Running: Currently running on the hw
 * 	Postprocessing Pending: Waiting for for post processing after hw run
 * 	Callback: Running a user registered callback as part of post processing
 * 	Memory cleanup: Cleaning memory registered for auto cleanup during postprocessing.
 *
 * A job retrieved through the new_job interface originates in the Building state.
 * A job can only be modified through our public API if it's in the Building state.
 * When the user calls start on the job it switches to Queued or Running state,
 * blocking any changes to the job afterwards.
 * The other states are used to track a job's status through post processing, to
 * ease debugging / error tracking.
 *
 * Acceptable transitions between states are:
 * 	Pool: to Building
 * 	Building: to Running
 * 	Running: to Postprocessing Pending
 * 	Postprocessing Pending: to Callback
 * 	In Callback: to Memory Cleanup
 * 	Memory Cleanup: To Pool
 *
 * These rules are enforced in the public accessible functions.
 * Therefore, a user can only call i.e. free on a job which
 * is in the building state.
 * If the job has been started, a free will be denied/reported.
 * Starting of a job which has already been started
 * will also be denied/reported.
 */

typedef enum mali_pp_job_state
{
    MALI_PP_JOB_POOL                    = 0x01, /* unused, will be used by the pool system */
    MALI_PP_JOB_BUILDING                = 0x02,
    MALI_PP_JOB_RUNNING                 = 0x04,
    MALI_PP_JOB_POSTPROCESS_PENDING     = 0x05,
    MALI_PP_JOB_CALLBACK                = 0x06,
    MALI_PP_JOB_MEMORY_CLEANUP          = 0x07,
    MALI_PP_JOB_SYNCING                 = 0x08,
    MALI_PP_JOB_WAKEUP                  = 0x09
} mali_pp_job_state;

typedef struct mali_base_stream
{
    u32 fd;
} mali_base_stream;

/**
 * Definition of the fence object type
 *
 * This wraps sync object fence file descriptor.
 */
typedef s32 mali_fence_handle;


/**
 * Definition of the stream object type
 */
typedef struct mali_base_stream * mali_stream_handle;


/**
 * Type definition for frame_id. All gp-jobs from the same frame builder
 * should have the same frame_id. If two succeeding jobs have the same
 * frame_id, the plbu does not need to flush the pointer cache between
 * these jobs, and the vs or plbu cmd processor can skip some cmds
 * in the start.
 */
typedef u32 mali_base_frame_id;

typedef struct mali_pp_registers
{
#if defined(USING_MALI450) || defined(USING_MALI400)
    mali_reg_value	frame_regs[M400_FRAME_REG_TILEBUFFER_BITS - M200_FRAME_REG_REND_LIST_ADDR + 1];
#elif defined(USING_MALI200)
    mali_reg_value	frame_regs[M200_FRAME_REG_TIEBREAK_MODE - M200_FRAME_REG_REND_LIST_ADDR + 1];
#else
#error "no supported mali core defined"
#endif
    mali_reg_value  frame_regs_addr_stack[_MALI_PP_MAX_SUB_JOBS - 1];
    mali_reg_value  frame_regs_addr_frame[_MALI_PP_MAX_SUB_JOBS - 1];
    mali_reg_value	wb0_regs[M200_WB0_REG_GLOBAL_TEST_CMP_FUNC - M200_WB0_REG_SOURCE_SELECT + 1];
    mali_reg_value	wb1_regs[M200_WB1_REG_GLOBAL_TEST_CMP_FUNC - M200_WB1_REG_SOURCE_SELECT + 1];
    mali_reg_value	wb2_regs[M200_WB2_REG_GLOBAL_TEST_CMP_FUNC - M200_WB2_REG_SOURCE_SELECT + 1];
} mali_pp_registers;

typedef struct mali_dump_job_info
{
    mali_bool             is_pp_job;
    u32                   frame_nr;
    u32                   job_nr;
    //mali_base_wait_handle inline_waiter;
    //mali_sync_handle      dump_sync;

    mali_bool           disable_dump;
    mali_bool           crash_dump_enable;
    mali_bool           pre_run_dump_enable;
    mali_bool           post_run_dump_enable;
    mali_bool           pre_run_dump_done;
    mali_bool           post_run_dump_done;
    char                last_mem_dump_file_name[512];
} mali_dump_job_info ;

typedef struct mali_pp_job
{
    mali_job_priority               priority;
    mali_pp_job_state               state;

    //mali_base_ctx_handle            ctx;
    mali_stream_handle              stream;
    mali_fence_handle               pre_fence;
    mali_fence_handle               empty_fence; /**< Empty sync fence that will be used for this job */
    //mali_cb_pp                      callback;
    //void                           *callback_argument;
    //mali_base_wait_handle           wait_handle;
    //mali_mem_handle                 freelist;
    //mali_sync_handle                sync;
    mali_base_frame_id              frame_id;

    u32                             num_cores;
    mali_pp_registers               registers;

    mali_bool                       barrier;

#if MALI_INSTRUMENTED
    mali_base_instrumented_pp_context perf_ctx;
#endif /* MALI_INSTRUMENTED */

    mali_base_frame_builder_id		frame_builder_id;
    mali_base_flush_id				flush_id;

#ifdef MALI_DUMP_ENABLE
    mali_dump_job_info dump_info;
#endif /* MALI_DUMP_ENABLE */

#if defined(USING_MALI450)
    m450_pp_job_frame_info info;
#endif /* defined(USING_MALI450) */

#if defined(MALI_USE_DMA_BUF) && defined(DMA_BUF_ON_DEMAND)
    u32 num_memory_cookies;
    u32 *memory_cookies;
#endif

} mali_pp_job;

typedef enum mali_dump_core_type
{
    MALI_DUMP_PP,
    MALI_DUMP_GP
}mali_dump_core_type;


struct MaliPPJob{

    MaliPPJob(u32 num_fbs,u32 num_polys,pp_test_framework_shader shader);
    virtual ~MaliPPJob();

//Variance
    pp_test_framework * pptf;
    bool printMali(const mali_mem_type *handle,const char *fileName,const u32 len);
    FILE *outFile;
    mali_pp_job* job;

bool _mali_pp_job_start(mali_job_priority priority, mali_fence_handle *fence);

private:
    pp_test_framework_handle pp_test_framework_context_allocate(u32 num_fbs, u32 num_polys, pp_test_framework_shader shader);
    mali_err_code pp_util_internal__alloate_frame_buffer(pp_test_framework * pptf,u32 num_fbs);
    mali_err_code pp_util_internal__alloate_vdb_arrays(pp_test_framework * pptf);
    mali_err_code pp_util_internal__allocate_dummy_shader(pp_test_framework * pptf);
    mali_err_code pp_util_internal__allocate_color_shader(pp_test_framework * pptf,pp_test_framework_shader shader);
    mali_err_code pp_util_internal__write_dummy_rsw(pp_test_framework * pptf,u32 rsw_index);
    mali_err_code pp_util_internal__write_drawing_rsw(pp_test_framework * pptf,u32 rsw_index);
    mali_err_code pp_util_internal__writing_tile_list(pp_test_framework * pptf,u32 num_polys);
    mali_err_code pp_util_internal__create_reference_frame_buffers(pp_test_framework * pptf);
    mali_pp_job* pp_test_framework_stream_job_create(pp_test_framework_handle pptf_h, u32 job_array_index);
};

#endif
