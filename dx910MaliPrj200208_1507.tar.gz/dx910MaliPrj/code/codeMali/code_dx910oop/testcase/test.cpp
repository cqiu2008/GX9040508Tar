#include "MaliPPJob.hpp"
#include "rgb565ToBmp.hpp"

int main()
{
    bool rtnValue=0;
    Amount n1=1;
    Amount num_polys=1;
    MaliPPJob maliPP1 = MaliPPJob(n1,num_polys,PPTF_SHADER_SIMPLE);
    //MaliPPJob maliPP1 = MaliPPJob(n1,num_polys,PPTF_SHADER_HEAVY);

    cout<<"job_start return = "<< maliPP1._mali_pp_job_start(MALI_JOB_PRI_HIGH, NULL)<<endl;

    for(int i=0;i<n1;i++){
        printf("maliPP1.pt1[%4d]=%4x\n",i,maliPP1.pptf->framebuffer_size);
    }
    rtnValue |= maliPP1.printMali(maliPP1.pptf->framebuffer,"framebuffer.log",maliPP1.pptf->framebuffer_size);
    for(int i=0;i<12;i++){
        char fileName[100];
        sprintf(fileName,"vdb_list%d.log",i);
        //rtnValue |= maliPP1.printMali(maliPP1.pptf->vdb_list[i],fileName,sizeof(mali_vdb)*64);
        rtnValue |= maliPP1.printMali(maliPP1.pptf->vdb_list[i],fileName,sizeof(mali_vdb));
    }
    rtnValue |= maliPP1.printMali(maliPP1.pptf->dummy_shader,"dummy_shader.log",sizeof(test_dummy_shader));
    rtnValue |= maliPP1.printMali(maliPP1.pptf->color_shader,"color_shader.log",sizeof(test_blue_color_shader));
    rtnValue |= maliPP1.printMali(maliPP1.pptf->rsw_list,"rsw.log",sizeof(m200_rsw)*2);
    rtnValue |= maliPP1.printMali(maliPP1.pptf->polygon_list,"polygon_list.log",sizeof(mali_pp_cmd)*(num_polys+2));
    cout<<"pptf->framebuffer_size in test.cpp ="<<maliPP1.pptf->framebuffer_size<<endl;
    for(int i=0;i<12;i++){
        char fileName[100];
        sprintf(fileName,"reference_frame%d.log",i);
        rtnValue |= maliPP1.printMali((mali_mem_type *)maliPP1.pptf->fb_correct[i],fileName,maliPP1.pptf->framebuffer_size);
        sprintf(fileName,"reference_frame%d.bmp",i);
        rtnValue |= Rgb565ConvertBmp((char *)maliPP1.pptf->fb_correct[i],SCREENSIZE_X,SCREENSIZE_Y,fileName);
    }
    cout<<"rtnValue="<<rtnValue<<endl;
    return rtnValue;
}
