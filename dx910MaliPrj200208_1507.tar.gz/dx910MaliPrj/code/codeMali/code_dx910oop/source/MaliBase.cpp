#include "MaliBase.hpp"

/**
 * Sets the first num bytes of the block of memory pointed to by ptr to the specified value
 * @param ptr Pointer to the block of memory to fill.
 * @param value Value to be set, passed as u32 big  block is filled with unsigned char conversion.
 * @param num Number of bytes to be set to the value.
 */
void * _mali_sys_memset(void * ptr, u32 value, u32 num)
{
    return memset(ptr, value, num);
}
void _mali_mem_write(
        mali_mem_handle to_mali,
        u32 to_offset,
        const void* from,
        u32 size)
{
    memcpy((to_mali+to_offset),from,size);
}



// /**
//  * Read data from mali memory into CPU/host memory.
//  * @param to Pointer to CPU/host memory to write to
//  * @param from_mali The Mali memory block to read from
//  * @param from_offset Offset in Mali memory to start read from
//  * @param size Number of bytes to read
//  */
// MALI_STATIC_FORCE_INLINE void _mali_mem_read(
//         void* to,
//         mali_mem_handle from_mali,
//         u32 from_offset,
//         u32 size)
// {
//    to = (from_mali+from_offset);
//    //_mali_base_arch_mem_read(to, (mali_mem*)from_mali, from_offset, size);
// }
