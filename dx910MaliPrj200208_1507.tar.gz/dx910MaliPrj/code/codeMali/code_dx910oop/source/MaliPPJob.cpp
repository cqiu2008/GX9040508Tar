#include "MaliPPJob.hpp"
#include <iostream>
#include "base/mali_byteorder.h"
#include "mali_pp_cmd.h"
#include "base/hostlib/direct/base/mali_runtime.h"

using namespace std;
//#define RSW_SHADER_ADDR_V1 0x46000
//#define RSW_SHADER_ADDR_V2 0x460ff

typedef enum mali_mgmt_reg_addr
{
    MGMT_REG_CTRL_MGMT			= 0x100C,
    MGMT_REG_IRQ_MASK			= 0x1028
} mali_mgmt_reg_addr;

#define MGMT_REG_CTRL_MGMT_CMD_START_RENDER (1<<6)
#define MGMT_REG_CTRL_MGMT_IRQ_MASK_ALL     0x1ff


// static u32 test_dummy_shader[] =
// {
//     0x00020425,
//     0x0000000C,
//     0x01E007CF,
//     0xB0000000,
//     0x000005F5
// };
//
// static u32 test_blue_color_shader[] =
// {
//     0x00020425,
//     0x0000050C,
//     0x000007CF,
//     0x000001E0,
//     0x00000400,
// };

//MaliPPJob::MaliPPJob(const std::string carNameIn,const Amount n1,const Amount n2):carName(carNameIn){
MaliPPJob::MaliPPJob(u32 num_fbs,u32 num_polys,pp_test_framework_shader shader){
    pptf = pp_test_framework_context_allocate(num_fbs,num_polys,shader);
    job = pp_test_framework_stream_job_create(pptf,0);
    //void _mali_pp_job_start(ppjob, MALI_JOB_PRI_HIGH, NULL);
}


pp_test_framework_handle MaliPPJob::pp_test_framework_context_allocate(u32 num_fbs, u32 num_polys, pp_test_framework_shader shader)
{
    /* Allocating the framework struct - Returning NULL on error */
    pp_test_framework_handle pptf = (pp_test_framework* ) MALLOC(sizeof(*pptf));
    /* Memsetting to Zero */
    memset(pptf,0,sizeof(*pptf));
    //cout<<"pptf.size"<<sizeof(*pptf)<<endl;
    this->printMali((mali_mem_type *)pptf,"S1pptf.log",sizeof(*pptf));

    //mali_err_code pp_util_internal__alloate_frame_buffer(num_fbs);
    /* Allocating frame buffer */
    MALI_CHECK_GOTO( MALI_ERR_NO_ERROR==pp_util_internal__alloate_frame_buffer(pptf,num_fbs), function_failed);

    /* Creating 12 VDB arrays */
    MALI_CHECK_GOTO( MALI_ERR_NO_ERROR==pp_util_internal__alloate_vdb_arrays(pptf), function_failed);

    ///* Allocating dummy shader */
    MALI_CHECK_GOTO( MALI_ERR_NO_ERROR==pp_util_internal__allocate_dummy_shader(pptf), function_failed);

    ///* Allocating the color shader */
    MALI_CHECK_GOTO( MALI_ERR_NO_ERROR==pp_util_internal__allocate_color_shader(pptf,shader), function_failed);

    ///* Allocating RSW list with 2 elements */
    //pptf->rsw_list = _mali_mem_alloc(ctxh, sizeof(m200_rsw)*2, 0, MALI_PP_READ );
    pptf->rsw_list = (mali_mem_type *)MALLOC(sizeof(m200_rsw)*2);
    cout<<"sizeof(m200_rsw)*2="<<sizeof(m200_rsw)*2<<endl;
    MALI_CHECK_GOTO(NULL!=pptf->rsw_list, function_failed);

    ///* Allocating and setting dummy rsw */
    MALI_CHECK_GOTO( MALI_ERR_NO_ERROR==pp_util_internal__write_dummy_rsw(pptf,0), function_failed);

    ///* Allocating and setting drawing rsw */
    MALI_CHECK_GOTO( MALI_ERR_NO_ERROR==pp_util_internal__write_drawing_rsw(pptf,1), function_failed);

    ///* Allocating Polygon (Tile) list with number of triangles + 2 elements (begin and end tile)*/
    //pptf->polygon_list = 	_mali_mem_alloc(ctxh, sizeof(mali_pp_cmd)*(num_polys+2), 0, MALI_PP_READ | MALI_PP_WRITE);
    pptf->polygon_list = (mali_mem_type *)MALLOC(sizeof(mali_pp_cmd)*(num_polys+2));
    MALI_CHECK_GOTO(NULL!=pptf->polygon_list, function_failed);

    ///* Writing PP Tile list */
    MALI_CHECK_GOTO( MALI_ERR_NO_ERROR==pp_util_internal__writing_tile_list(pptf,num_polys), function_failed);

    ///* Creating the 12 refernece images */
    MALI_CHECK_GOTO( MALI_ERR_NO_ERROR==pp_util_internal__create_reference_frame_buffers(pptf), function_failed);

    ///* SUCCESS */
    std::cout<<"MaliPPJob Create Successfull"<<std::endl;
    return pptf;

function_failed:
    std::cout<<"MaliPPJob Create Error"<<std::endl;
    return NULL;
}

mali_err_code MaliPPJob::pp_util_internal__alloate_frame_buffer(pp_test_framework * pptf,u32 num_fbs)
{
    u32 framebuffer_size_total;
    pptf->number_of_framebuffers = num_fbs;
    pptf->framebuffer_size       = SCREENSIZE_X * SCREENSIZE_Y * sizeof(u16);
    framebuffer_size_total = pptf->number_of_framebuffers * pptf->framebuffer_size;
    pptf->framebuffer = (mali_mem_type *) MALLOC(sizeof(mali_mem_handle) * framebuffer_size_total);
    memset(pptf->framebuffer,0x1f,framebuffer_size_total);
    //MALI_CHECK_NON_NULL(pptf->framebuffer, MALI_ERR_OUT_OF_MEMORY);
    //mapped_for_memset = _mali_mem_ptr_map_area( pptf->framebuffer, 0, framebuffer_size_total, 0, MALI_MEM_PTR_WRITABLE);
    //MALI_CHECK_NON_NULL(mapped_for_memset, MALI_ERR_OUT_OF_MEMORY);
    //_mali_sys_memset(mapped_for_memset, 0x1f ,framebuffer_size_total);
    //_mali_mem_ptr_unmap_area(pptf->framebuffer);
    MALI_SUCCESS;
}

mali_err_code MaliPPJob::pp_util_internal__alloate_vdb_arrays(pp_test_framework * pptf)
{
    int loop;
    float	x_coords[3];
    float	y_coords[3];
    float	*current_vb_part;
    u32		vertex;
    for(loop = 0; loop <12; loop++)
    {
        x_coords[0] = 1.f;
        y_coords[0] = 1.f;
        x_coords[1] = (float)(SCREENSIZE_X-1-(loop%12));
        y_coords[1] = 1.f;
        x_coords[2] = 1.f;
        y_coords[2] = (float)(SCREENSIZE_Y-1-(loop%12));

        pptf->vdb_list[loop] = (mali_mem_type *) MALLOC( sizeof(mali_vdb)*64);
        cout<<"sizeof(mali_vdb)="<<sizeof(mali_vdb)<<endl;
        current_vb_part = (float *) pptf->vdb_list[loop];

        //pptf->vdb_list[loop] = _mali_mem_alloc(ctxh, sizeof(mali_vdb)*64, 0, MALI_PP_READ | MALI_PP_WRITE);
        //MALI_CHECK_NON_NULL(pptf->vdb_list[loop], MALI_ERR_OUT_OF_MEMORY);
        //orig = (float *)_mali_mem_ptr_map_area( pptf->vdb_list[loop], 0, sizeof(pptf->vdb_list), 0, MALI_MEM_PTR_WRITABLE);
        //current_vb_part = orig;
        //MALI_CHECK_NON_NULL(current_vb_part , MALI_ERR_OUT_OF_MEMORY);
        for (vertex = 0; vertex < 3; vertex++)
        {
            *current_vb_part++ = x_coords[vertex];
            *current_vb_part++ = y_coords[vertex];
            *current_vb_part++ = 0.5f;
            *current_vb_part++ = 0.5f;
        }
        //_mali_byteorder_swap_endian(orig, 3*4*sizeof(float), 8);
        //_mali_mem_ptr_unmap_area( pptf->vdb_list[loop]);
    }
    MALI_SUCCESS;
}

mali_err_code MaliPPJob::pp_util_internal__allocate_dummy_shader(pp_test_framework * pptf)
{
    void * shader_bin = test_dummy_shader;
    u32 size = sizeof(test_dummy_shader);
    pptf->dummy_shader = (mali_mem_type*) MALLOC(size);
    _mali_mem_write(pptf->dummy_shader, 0, shader_bin, size);
    //MALI_CHECK_NON_NULL(pptf->dummy_shader, MALI_ERR_OUT_OF_MEMORY);
    MALI_SUCCESS;
}

mali_err_code MaliPPJob::pp_util_internal__allocate_color_shader(pp_test_framework * pptf,pp_test_framework_shader shader)
{
    void * shader_bin;
    u32 size;

    //MALI_DEBUG_ASSERT_POINTER(pptf);
    //MALI_DEBUG_ASSERT(pptf->color_shader==NULL, ("Error"));

    switch (shader)
    {
        case PPTF_SHADER_SIMPLE:
            shader_bin = test_blue_color_shader;
            size = sizeof(test_blue_color_shader);
            pptf->triangle_color   = 0x001f;
            pptf->background_color = 0x07e0;
            break;
        case PPTF_SHADER_HEAVY:
            shader_bin = test_heavy_color_shader;
            size = sizeof(test_heavy_color_shader);
            pptf->triangle_color   = 0xFFE0;
            pptf->background_color = 0x07e0;
            break;
        default:
            cout<<"MALI_DEBUG_ASSERT ERROR"<<endl;
            //MALI_DEBUG_ASSERT(0==1, ("Error"));
            return MALI_ERR_FUNCTION_FAILED;
    }

    //pptf->color_shader = _mali_mem_alloc(ctxh, size, 0 , MALI_PP_READ | MALI_PP_WRITE);
    pptf->color_shader = (mali_mem_type *)MALLOC(size);
    //if(MALI_NO_HANDLE == pptf->color_shader) return MALI_ERR_OUT_OF_MEMORY;

    _mali_mem_write(pptf->color_shader, 0, shader_bin, size);
    return MALI_ERR_NO_ERROR;
}

/* setting up dummy rsw */
mali_err_code MaliPPJob::pp_util_internal__write_dummy_rsw(pp_test_framework * pptf,u32 rsw_index)
{
    u32 len_first_instr;
    u32	addr;
    u32 shader_first_word;
    m200_rsw rsw_tmp;

    _mali_sys_memset(&rsw_tmp,0, sizeof(m200_rsw));

    //MALI_DEBUG_ASSERT_POINTER(pptf->dummy_shader);

    /* Getting the instruction length of the first shader instruction.
    Is set in the RSW at the end of the function. */
    //_mali_mem_read(&shader_first_word, pptf->dummy_shader, 0, 4);
    _mali_mem_read(&shader_first_word, pptf->dummy_shader, 0);
    len_first_instr = shader_first_word & 0x1f;
    cout<<"len_first_instr="<<len_first_instr<<endl;

    //addr = _mali_mem_mali_addr_get(pptf->dummy_shader, 0);
    //cout<<"addr="<<addr<<endl;
    addr = RSW_SHADER_ADDR_V1 ;

    // /* Writing to the rsw_tmp */
    __m200_rsw_encode(&rsw_tmp, M200_RSW_MULTISAMPLE_WRITE_MASK, 0xf );
    __m200_rsw_encode(&rsw_tmp, M200_RSW_MULTISAMPLE_GRID_ENABLE, 0 );
    __m200_rsw_encode(&rsw_tmp, M200_RSW_SHADER_ADDRESS, addr);
    __m200_rsw_encode(&rsw_tmp, M200_RSW_HINT_NO_SHADER_PRESENT, 0 );
     /* See P00086 5.1 The header which says 4:0 == 1st instruction word length, this needs
     to be encoded into the dummy program */
    __m200_rsw_encode(&rsw_tmp, M200_RSW_FIRST_SHADER_INSTRUCTION_LENGTH, (u32)len_first_instr );

    // /* Writing the generated tmp_rsw on stack to the array of rsws in mali memory at position rsw_index */
    _mali_mem_write(pptf->rsw_list, rsw_index*sizeof(m200_rsw), rsw_tmp, sizeof(m200_rsw));
    bool rtnValue=0;
    //rtnValue |= this->printMali(pptf->rsw_list,"rsw_dummy.log",sizeof(m200_rsw)*2);
    return MALI_ERR_NO_ERROR;
}

mali_err_code MaliPPJob::pp_util_internal__write_drawing_rsw(pp_test_framework * pptf,u32 rsw_index)
{
    u32 len_first_instr;
    u32	addr;
    u32 shader_first_word;
    m200_rsw rsw_tmp;

    /* Shader must be set up prior to calling this function */
    //MALI_DEBUG_ASSERT(pptf->color_shader!=NULL, ("Error"));

    /* Getting the instruction length of the first shader instruction.
    Is set in the RSW at the end of the function. */
    //_mali_mem_read(&shader_first_word, pptf->color_shader, 0, 4);
    _mali_mem_read(&shader_first_word, pptf->color_shader, 0);
    len_first_instr = shader_first_word & 0x1f;
    //addr = _mali_mem_mali_addr_get(pptf->color_shader, 0);
    addr = RSW_SHADER_ADDR_V2 ;

    _mali_sys_memset(&rsw_tmp,0, sizeof(m200_rsw));

    /* Writing to the rsw_tmp */
    __m200_rsw_encode(&rsw_tmp,  M200_RSW_ABGR_WRITE_MASK,          0xf);
    __m200_rsw_encode(&rsw_tmp,  M200_RSW_MULTISAMPLE_GRID_ENABLE,  0x01);
    __m200_rsw_encode(&rsw_tmp,  M200_RSW_SAMPLE_0_REGISTER_SELECT, 0x0 );
    __m200_rsw_encode(&rsw_tmp,  M200_RSW_SAMPLE_1_REGISTER_SELECT, 0x0 );
    __m200_rsw_encode(&rsw_tmp,  M200_RSW_SAMPLE_2_REGISTER_SELECT, 0x0 );
    __m200_rsw_encode(&rsw_tmp,  M200_RSW_SAMPLE_3_REGISTER_SELECT, 0x0 );

    /* set some sensible RSW defaults */
    __m200_rsw_encode(&rsw_tmp, M200_RSW_MULTISAMPLE_WRITE_MASK,        0xf );

    /* stencil test settings, front & back */
    __m200_rsw_encode(&rsw_tmp, M200_RSW_STENCIL_FRONT_WRITE_MASK,      0xff);
    __m200_rsw_encode(&rsw_tmp, M200_RSW_STENCIL_FRONT_REF_VALUE,       0x0);
    __m200_rsw_encode(&rsw_tmp, M200_RSW_STENCIL_FRONT_OP_MASK,         0xff);
    __m200_rsw_encode(&rsw_tmp, M200_RSW_STENCIL_FRONT_COMPARE_FUNC,    M200_TEST_ALWAYS_SUCCEED);
    __m200_rsw_encode(&rsw_tmp, M200_RSW_STENCIL_FRONT_OP_IF_SFAIL,     M200_STENCIL_OP_KEEP_CURRENT);
    __m200_rsw_encode(&rsw_tmp, M200_RSW_STENCIL_FRONT_OP_IF_ZFAIL,     M200_STENCIL_OP_KEEP_CURRENT);
    __m200_rsw_encode(&rsw_tmp, M200_RSW_STENCIL_FRONT_OP_IF_ZPASS,     M200_STENCIL_OP_KEEP_CURRENT);
    /*  __mt200_rsw_encode( ctx, MT200_RSW_STENCIL_FRONT_VALUE_REGISTER,    0xf); *//* get ref value from RSW */

    __m200_rsw_encode(&rsw_tmp, M200_RSW_STENCIL_BACK_WRITE_MASK,       0xff);
    __m200_rsw_encode(&rsw_tmp, M200_RSW_STENCIL_BACK_REF_VALUE,        0x0);
    __m200_rsw_encode(&rsw_tmp, M200_RSW_STENCIL_BACK_OP_MASK,          0xff);
    __m200_rsw_encode(&rsw_tmp, M200_RSW_STENCIL_BACK_COMPARE_FUNC,     M200_TEST_ALWAYS_SUCCEED);
    __m200_rsw_encode(&rsw_tmp, M200_RSW_STENCIL_BACK_OP_IF_SFAIL,      M200_STENCIL_OP_KEEP_CURRENT);
    __m200_rsw_encode(&rsw_tmp, M200_RSW_STENCIL_BACK_OP_IF_ZFAIL,      M200_STENCIL_OP_KEEP_CURRENT);
    __m200_rsw_encode(&rsw_tmp, M200_RSW_STENCIL_BACK_OP_IF_ZPASS,      M200_STENCIL_OP_KEEP_CURRENT);
    /*  __mt200_rsw_encode( ctx, MT200_RSW_STENCIL_BACK_VALUE_REGISTER, 0xf); *//* get ref value from RSW */

    /* alpha test */
    __m200_rsw_encode(&rsw_tmp, M200_RSW_ALPHA_TEST_FUNC,               M200_TEST_ALWAYS_SUCCEED);

    /* framebuffer blending: S * 1 + D * 0 */
    __m200_rsw_encode(&rsw_tmp, M200_RSW_RGB_BLEND_FUNC,                M200_BLEND_CsS_pCdD );
    __m200_rsw_encode(&rsw_tmp, M200_RSW_RGB_S_SOURCE_SELECT,           M200_SOURCE_0 );
    __m200_rsw_encode(&rsw_tmp, M200_RSW_RGB_S_SOURCE_1_M_X,            1);
    __m200_rsw_encode(&rsw_tmp, M200_RSW_RGB_S_SOURCE_ALPHA_EXPAND,     0);
    __m200_rsw_encode(&rsw_tmp, M200_RSW_RGB_D_SOURCE_SELECT,           M200_SOURCE_0 );
    __m200_rsw_encode(&rsw_tmp, M200_RSW_RGB_D_SOURCE_1_M_X,            0);
    __m200_rsw_encode(&rsw_tmp, M200_RSW_RGB_D_SOURCE_ALPHA_EXPAND,     0);

    __m200_rsw_encode(&rsw_tmp, M200_RSW_ALPHA_BLEND_FUNC,              M200_BLEND_CsS_pCdD );
    __m200_rsw_encode(&rsw_tmp, M200_RSW_ALPHA_S_SOURCE_SELECT,         M200_SOURCE_0 );
    __m200_rsw_encode(&rsw_tmp, M200_RSW_ALPHA_S_SOURCE_1_M_X,          1);
    __m200_rsw_encode(&rsw_tmp, M200_RSW_ALPHA_D_SOURCE_SELECT,         M200_SOURCE_0 );
    __m200_rsw_encode(&rsw_tmp, M200_RSW_ALPHA_D_SOURCE_1_M_X,          0);

    /* depth test */
    /*  __mt200_rsw_encode( ctx, MT200_RSW_Z_VALUE_REGISTER,        0xf );  */      /* use fixed-function z */
    __m200_rsw_encode(&rsw_tmp, M200_RSW_Z_COMPARE_FUNC,                M200_TEST_ALWAYS_SUCCEED);
    __m200_rsw_encode(&rsw_tmp, M200_RSW_Z_WRITE_MASK,                  0x0);
    __m200_rsw_encode(&rsw_tmp, M200_RSW_Z_NEAR_BOUND,                  0x0 );
    __m200_rsw_encode(&rsw_tmp, M200_RSW_Z_FAR_BOUND,                   0xffff );

    /* set all writemasks to allow RGBA writing */
    __m200_rsw_encode(&rsw_tmp, M200_RSW_A_WRITE_MASK,                  1 );
    __m200_rsw_encode(&rsw_tmp, M200_RSW_R_WRITE_MASK,                  1 );
    __m200_rsw_encode(&rsw_tmp, M200_RSW_G_WRITE_MASK,                  1 );
    __m200_rsw_encode(&rsw_tmp, M200_RSW_B_WRITE_MASK,                  1 );

    __m200_rsw_encode(&rsw_tmp, M200_RSW_MULTISAMPLE_WRITE_MASK, 0xf );
    __m200_rsw_encode(&rsw_tmp, M200_RSW_MULTISAMPLE_GRID_ENABLE, 0 );
    __m200_rsw_encode(&rsw_tmp, M200_RSW_SHADER_ADDRESS, addr);
    /*__m200_rsw_encode(rsw_tmp, M200_RSW_HINT_NO_SHADER_PRESENT, 0 );*/
    /* See P00086 5.1 The header which says 4:0 == 1st instruction word length, this needs
    to be encoded into the dummy program */
    __m200_rsw_encode(&rsw_tmp, M200_RSW_FIRST_SHADER_INSTRUCTION_LENGTH, (u32)len_first_instr );

    /* Writing the generated tmp_rsw on stack to the array of rsws in mali memory at position rsw_index */
    //_mali_mem_write(pptf->rsw_list, rsw_index*sizeof(m200_rsw), rsw_tmp, sizeof(m200_rsw));
    _mali_mem_write(pptf->rsw_list, rsw_index*sizeof(m200_rsw)/sizeof(mali_addr), rsw_tmp, sizeof(m200_rsw));

    return MALI_ERR_NO_ERROR;

}

mali_err_code MaliPPJob::pp_util_internal__writing_tile_list(pp_test_framework * pptf,u32 num_polys)
{
    mali_pp_cmd * cur_cmd;
    u32 triangle_counter;
    //cur_cmd = (mali_pp_cmd *)_mali_mem_ptr_map_area( pptf->polygon_list, 0, (num_polys + 2)*sizeof(mali_pp_cmd), 0, MALI_MEM_PTR_READABLE);
    cur_cmd = (mali_pp_cmd *)pptf->polygon_list;

    MALI_CHECK_NON_NULL(cur_cmd , MALI_ERR_OUT_OF_MEMORY);

    MALI_PL_CMD_BEGIN_NEW_TILE(*cur_cmd, 0, 0);
    cur_cmd++;

    /* Drawing num_polys identical triangles on top of eachother */
    triangle_counter = num_polys;
    while(0!=triangle_counter--)
    {
        MALI_PL_PRIMITIVE(*cur_cmd,
                            MALI_PRIMITIVE_TYPE_TRIANGLE,
                            1,  /* rsw-index */
                            0,          /* vertex 0 */
                            1,          /* vertex 1 */
                            2);         /* vertex 2 */
        cur_cmd++;
    }

    MALI_PL_CMD_END_OF_LIST(*cur_cmd);
    cur_cmd++;

    //_mali_mem_ptr_unmap_area(pptf->polygon_list);
    MALI_SUCCESS;
}

mali_err_code MaliPPJob::pp_util_internal__create_reference_frame_buffers(pp_test_framework * pptf)
{
    int i, j, vdb_array_index;
    u16 triangle_color;
    u16 background_color;

    triangle_color   = pptf->triangle_color;
    background_color = pptf->background_color;

    for(vdb_array_index=0;vdb_array_index<12;vdb_array_index++)
    {
        u16 * fb_current;
        fb_current = (u16 *)MALLOC(pptf->framebuffer_size);
        //cout<<"pptf->framebuffer_size in referenct_frame_buffer="<<pptf->framebuffer_size<<endl;
        MALI_CHECK_NON_NULL(fb_current, MALI_ERR_OUT_OF_MEMORY);
        pptf->fb_correct[vdb_array_index] = fb_current;

        for(i = 0; i < SCREENSIZE_Y; i++)
        {
            for(j = 0;j<SCREENSIZE_X; j++)
            {
                if(i<1 || j < 1 || j >((SCREENSIZE_X-(vdb_array_index))-i-1) || j>(SCREENSIZE_X-(vdb_array_index)-1) || i>(SCREENSIZE_Y-(vdb_array_index)-1)) fb_current[j + SCREENSIZE_X*i] = background_color;
                else fb_current[j + SCREENSIZE_X*i] = triangle_color ;
            }
        }
    }
    MALI_SUCCESS;
}

bool MaliPPJob::printMali(const mali_mem_type *handle,const char *fileName,const u32 len){
    this->outFile = fopen(fileName,"w+");
    int *ptr = (int *)handle;
    u32 num = len / sizeof(*ptr);
    for(u32 lp = 0; lp < num; lp++){
        //fprintf(outFile,"%#010x ",(*ptr++));
        if( (0 == lp %4) && (0 != lp) ){
            fprintf(outFile,"\n");
        }
        fprintf(outFile,"%08x ",(*ptr++));
    }
    fprintf(outFile,"\n");
    fclose(this->outFile);
    return 0;
}

void pp_reg_set(mali_pp_registers * registers, mali_reg_id regid, mali_reg_value value)
{
    u32 bank, internal_register_number;
    bank = (regid >> 6) & 0x03FF;
    internal_register_number = regid & 0x003F;

    switch (bank)
    {
        case 0:
            //MALI_DEBUG_ASSERT(regid <= LAST_FRAME_REG, ("Invalid register id %d", regid));
            registers->frame_regs[internal_register_number] = value;
            break;
        case 1:
            //MALI_DEBUG_ASSERT(regid <= M200_WB0_REG_GLOBAL_TEST_CMP_FUNC, ("Invalid register id %d", regid));
            registers->wb0_regs[internal_register_number] = value;
            break;
        case 2:
            //MALI_DEBUG_ASSERT(regid <= M200_WB1_REG_GLOBAL_TEST_CMP_FUNC, ("Invalid register id %d", regid));
            registers->wb1_regs[internal_register_number] = value;
            break;
        case 3:
            //MALI_DEBUG_ASSERT(regid <= M200_WB2_REG_GLOBAL_TEST_CMP_FUNC, ("Invalid register id %d", regid));
            registers->wb2_regs[internal_register_number] = value;
            break;
        default:
            //MALI_DEBUG_ASSERT( MALI_FALSE, ("Invalid register id %d", regid));
            break;
    }
}

void _mali_base_common_pp_job_set_common_render_reg(mali_pp_job* job, mali_reg_id regid, mali_reg_value value)
{
    // job = MALI_REINTERPRET_CAST(mali_pp_job *)job_handle;
    // MALI_DEBUG_ASSERT_POINTER(job);
    // MALI_DEBUG_ASSERT(	MALI_PP_JOB_BUILDING == job->state ||
    //             MALI_PP_JOB_CALLBACK == job->state ||
    //             MALI_PP_JOB_RUNNING == job->state||
    //             MALI_PP_JOB_SYNCING == job->state,
    //             ("Changing a render register on a job which is not in the BUILDING, CALLBACK or SYNCING state is not supported"));

    //if (MALI_PP_JOB_BUILDING == job->state || MALI_PP_JOB_CALLBACK == job->state || MALI_PP_JOB_SYNCING == job->state)
    //{
        pp_reg_set(&job->registers, regid, value);
    //}
}

/**
 * Set a render register value in a job definition
 * @param job Handle to the job to update
 * @param regid ID of register to set
 * @param value value to assign to register
 */
void _mali_pp_job_set_common_render_reg(mali_pp_job* job, mali_reg_id regid, mali_reg_value value)
{
    _mali_base_common_pp_job_set_common_render_reg(job, regid, value);
}

bool pp_util_internal__allocate_job(mali_pp_job *job)
{
    //job = _mali_pp_job_new(ctxh, 1, stream);
    //MALI_CHECK_NON_NULL(job, NULL);

    _mali_pp_job_set_common_render_reg( job, M200_FRAME_REG_FEATURE_ENABLE, 		M200_FEATURE_EARLYZ_DISABLE1 | M200_FEATURE_EARLYZ_DISABLE2);  /* Turn of EARLYZ */
    _mali_pp_job_set_common_render_reg( job, M200_FRAME_REG_Z_CLEAR_VALUE, 			0xFFFFFFFF);
    _mali_pp_job_set_common_render_reg( job, M200_FRAME_REG_STENCIL_CLEAR_VALUE,	0); /* ? */
    /* All buffers are A8_B8_G8_R8, A=max B=0 G=MAX R=0,  GREEN COLOR Output565: 0x07E0 */
    _mali_pp_job_set_common_render_reg( job, M200_FRAME_REG_ABGR_CLEAR_VALUE_0, 	0xFF00FF00);
    _mali_pp_job_set_common_render_reg( job, M200_FRAME_REG_ABGR_CLEAR_VALUE_1, 	0xFF00FF00);
    _mali_pp_job_set_common_render_reg( job, M200_FRAME_REG_ABGR_CLEAR_VALUE_2, 	0xFF00FF00);
    _mali_pp_job_set_common_render_reg( job, M200_FRAME_REG_ABGR_CLEAR_VALUE_3, 	0xFF00FF00);

    #define RGB_565 0
    _mali_pp_job_set_common_render_reg( job, M200_WB0_REG_SOURCE_SELECT,			M200_WBx_SOURCE_ARGB);
    _mali_pp_job_set_common_render_reg( job, M200_WB0_REG_TARGET_PIXEL_FORMAT,		RGB_565);
    _mali_pp_job_set_common_render_reg( job, M200_WB0_REG_TARGET_AA_FORMAT,			M200_WBx_AA_FORMAT_0X);
    _mali_pp_job_set_common_render_reg( job, M200_WB0_REG_TARGET_LAYOUT,			0);
    _mali_pp_job_set_common_render_reg( job, M200_WB0_REG_TARGET_SCANLINE_LENGTH,	(SCREENSIZE_X *2) >> 3);
    _mali_pp_job_set_common_render_reg( job, M200_WB0_REG_TARGET_FLAGS,				0);
    _mali_pp_job_set_common_render_reg( job, M200_WB0_REG_MRT_ENABLE,				0);
    _mali_pp_job_set_common_render_reg( job, M200_WB0_REG_MRT_OFFSET,				0);
    _mali_pp_job_set_common_render_reg( job, M200_WB0_REG_GLOBAL_TEST_ENABLE,		0);
    _mali_pp_job_set_common_render_reg( job, M200_WB0_REG_GLOBAL_TEST_REF_VALUE,	0);
    _mali_pp_job_set_common_render_reg( job, M200_WB0_REG_GLOBAL_TEST_CMP_FUNC,		0);

    return 1;
}


 mali_pp_job* MaliPPJob::pp_test_framework_stream_job_create(pp_test_framework_handle pptf_h, u32 job_array_index)
{
    mali_pp_job* job = (mali_pp_job *)MALLOC(sizeof(mali_pp_job)) ;
    u32	addr;
    pp_test_framework * pptf = MALI_STATIC_CAST(pp_test_framework *)pptf_h;
    cout<<"pptf->framebuffer_size in job_create func"<<pptf->framebuffer_size<<endl;
    cout<<"job_array_index = "<<job_array_index<<endl;

    //MALI_DEBUG_ASSERT_POINTER(pptf);
    //MALI_DEBUG_ASSERT(pptf->number_of_framebuffers>job_array_index, ("Error"));

    bool jobtomake = 0;
    jobtomake = pp_util_internal__allocate_job(job);

    if ( jobtomake != 0)
    {
        //addr = _mali_mem_mali_addr_get(pptf->polygon_list, 0);
        //addr = 0x00047000;
        _mali_pp_job_set_common_render_reg( job, M200_FRAME_REG_REND_LIST_ADDR,	M200_FRAME_REG_REND_LIST_ADDR_V);
        //addr = _mali_mem_mali_addr_get( pptf->rsw_list, 0);
        //addr = 0x00000040;
        _mali_pp_job_set_common_render_reg( job, M200_FRAME_REG_REND_RSW_BASE, 	M200_FRAME_REG_REND_RSW_BASE_V);
        //addr = _mali_mem_mali_addr_get( pptf->vdb_list[job_array_index%12], 0);
        //addr = 0x000440c0;
        _mali_pp_job_set_common_render_reg( job, M200_FRAME_REG_REND_VERTEX_BASE, M200_FRAME_REG_REND_VERTEX_BASE_V);
        //addr = _mali_mem_mali_addr_get( pptf->framebuffer, pptf->framebuffer_size*job_array_index);
        //addr = 0x00004060;
        _mali_pp_job_set_common_render_reg( job, M200_WB0_REG_TARGET_ADDR,	M200_WB0_REG_TARGET_ADDR_V);
        return job;
    }

    /* Not thread safe:
    assert_fail((1!=0), "failed to make job");*/
    return NULL;
}

/**
 * Filling the job->dump_info struct
 */
void _mali_base_common_dump_job_info_fill(mali_dump_core_type core, mali_dump_job_info * info)
{
    //mali_dump_job_info * in_callback_info;

    //if ( MALI_FALSE ==_mali_dump_system_is_enabled(ctx) || MALI_TRUE == info->disable_dump )
    //{
    //    return;
    //}

    sprintf(info->last_mem_dump_file_name,"config.txt");

    //info->last_mem_dump_file_name[0] = 0;
    //info->last_mem_dump_file_name = "dumpLog.log";
    //info->pre_run_dump_done = MALI_FALSE;
    //info->post_run_dump_done = MALI_FALSE;

    info->pre_run_dump_enable = MALI_TRUE;
    info->pre_run_dump_done   = MALI_FALSE;

    if ( MALI_DUMP_GP==core)
    {
        info->is_pp_job = MALI_FALSE;
        //info->job_nr   = gp_job_counter_inc_and_return(ctx);
        info->job_nr   = 0;
    }
    else
    {
        //MALI_DEBUG_ASSERT(MALI_DUMP_PP==core, ("Illegal core type\n"));
        info->is_pp_job = MALI_TRUE;
        //info->job_nr   = pp_job_counter_inc_and_return(ctx);
        info->job_nr   = 1;
    }

    //in_callback_info = job_info_get(ctx);
    //info->inline_waiter  = NULL;

    //if ( NULL != in_callback_info)
    //{
    //    /* We ARE in another job's callback function. Transfering data from this one */
    //    info->frame_nr = in_callback_info->frame_nr;
    //    info->dump_sync = in_callback_info->dump_sync;
    //    if ( NULL != info->dump_sync ) _mali_base_common_sync_handle_register_reference(info->dump_sync);
    //}
    //else
    //{
    //    info->frame_nr = frame_counter_get(ctx);
    //    if ( MALI_FALSE != dump_ctx(ctx)->locker_enabled)
    //    {
    //        mali_base_wait_handle  inline_waiter;

    //        info->dump_sync = _mali_base_common_sync_handle_new(ctx);
    //        if ( MALI_NO_HANDLE!=info->dump_sync  )
    //        {
    //            inline_waiter  = _mali_base_common_sync_handle_get_wait_handle(info->dump_sync);
    //            if ( MALI_NO_HANDLE != inline_waiter  )
    //            {
    //                info->inline_waiter = inline_waiter;
    //                _mali_base_common_sync_handle_register_reference(info->dump_sync);
    //                _mali_base_common_sync_handle_flush(info->dump_sync);
    //            }
    //            else
    //            {
    //                _mali_base_common_sync_handle_flush(info->dump_sync);
    //                info->dump_sync = MALI_NO_HANDLE;
    //            }
    //        }

    //        if(MALI_NO_HANDLE==info->dump_sync ) MALI_DEBUG_ERROR(("Could not allocate dump_sync.\n"));
    //    }
    //}

    //if ( MALI_DUMP_GP==core)
    //{
    //    info->pre_run_dump_enable   = dump_gp_job_is_enabled(ctx, info->frame_nr , info->job_nr);
    //}
    //else
    //{
    //    MALI_DEBUG_ASSERT(MALI_DUMP_PP==core, ("Illegal core type\n"));
    //    info->pre_run_dump_enable   = dump_pp_job_is_enabled(ctx, info->frame_nr , info->job_nr);
    //}

    //info->post_run_dump_enable = MALI_FALSE;
    //if ( MALI_TRUE == info->pre_run_dump_enable )
    //{
    //    if ( MALI_FALSE!=dump_ctx(ctx)->dump_result )
    //    {
    //        info->post_run_dump_enable = MALI_TRUE;
    //    }
    //    info->crash_dump_enable  = MALI_FALSE;
    //}
    //else
    //{
    //    info->crash_dump_enable  = dump_crashed_is_enabled(ctx);
    //}

    //if (_mali_dump_system_verbose_printing_is_enabled(ctx) )
    //{
    //    const char * core_text;
    //    core_text = (MALI_FALSE!=info->is_pp_job) ? "pp" : "gp";
    //    _mali_sys_printf("Mali START Frame number:%4d %s job:%4d\n", info->frame_nr, core_text, info->job_nr);
    //}
}


#if defined(USING_MALI450)
u32 _mali_base_common_dump_mem_m450_master_tile_list_physical_address = 0xcafe0000;
#endif /* defined(USING_MALI450) */


#if defined(USING_MALI450)
static void mali_dump_450_frame_info(FILE *file_regs, m450_pp_job_frame_info *info)
{

    u32 master_tile_list_virtual_address  = TILE_LIST_VIRTAL_ADDR_V;
    fprintf(file_regs, "#\n");

    fprintf(file_regs, "# Register writes for the Mali450 Dynamic Load Balancing Unit\n");
    fprintf(file_regs, "writereg 80014000 %08x # Physical address of DLB unit\n",
                    _mali_base_common_dump_mem_m450_master_tile_list_physical_address | (1<<0));
 //                       PHYSICAL_ADDR_DLB);
//#define PHYSICAL_ADDR_DLB
    fprintf(file_regs, "writereg 80014004 %08x # Virtual  address of DLB unit\n",
                    master_tile_list_virtual_address);

    fprintf(file_regs, "writereg 80014008 %08x # Tile list virtual base address\n",
                        SLAVE_TILE_LIST_ADDR_V );
                    //info->slave_tile_list_mali_address);
    fprintf(file_regs, "writereg 8001400c %08x # Framebuffer dimensions\n",
                    (info->master_x_tiles - 1) | ((info->master_y_tiles-1)<<16));
    fprintf(file_regs, "writereg 80014010 %08x # Tile list configuration\n",
                    info->binning_pow2_x | (info->binning_pow2_y<<16) | (info->size<<28));
    fprintf(file_regs, "writereg 80014014 %08x # Start tile positions\n",
                    0 | (0<<8) | ((info->master_x_tiles-1)<<16) | ((info->master_y_tiles-1)<<24) );
    fprintf(file_regs, "#\n");
}
#endif /* defined(USING_MALI450) */

/**
 * Telling is type PP core and core nr
 * Following spec from intern trondheim wiki site: HW_common_testbench#APB_addressing
*/
u32 get_pp_core_dump_addr_prefix(u32 core_nr)
{
    u32 addr_prefix;

    #define MALI_TESTBENCH_CORE_TYPE_BIT_NR   24
    #define MALI_TESTBENCH_CORE_TYPE_PP       0x10
    #define MALI_TESTBENCH_CORE_NR_BIT_NR     16

    /* Setting this is CORE_TYPE_PP */
    addr_prefix  = MALI_TESTBENCH_CORE_TYPE_PP<<MALI_TESTBENCH_CORE_TYPE_BIT_NR;
    /* Setting this is the given core number */
    addr_prefix |= core_nr<<MALI_TESTBENCH_CORE_NR_BIT_NR;

    return addr_prefix ;
}



static void mali_dump_pp_regs(FILE * file_regs, mali_pp_registers *registers, u32 core_nr)
{
    int i, reg_nr;
    u32 addr_prefix = 0;
    int reg_array_length;

    //addr_prefix = get_pp_core_dump_addr_prefix(core_nr);
    addr_prefix = REG_ADDR_PREFIX ;


    /* Frame registers */
#if defined(USING_MALI400) || defined(USING_MALI450)
    reg_array_length = 23;
#elif defined(USING_MALI200)
    reg_array_length = 20;
#endif

    reg_nr = 0;

    if (0 == core_nr)
    {
        //fprintf(file_regs, "writereg %08x %08x # %s\n", M200_FRAME_REG_REND_LIST_ADDR | addr_prefix, registers->frame_regs[0], mali_dump_get_register_name(reg_nr++));
        fprintf(file_regs, "writereg %08x %08x # %s\n", M200_FRAME_REG_REND_LIST_ADDR | addr_prefix, registers->frame_regs[0], "M200_FRAME_REG_REND_LIST_ADDR");
    }
    else
    {
        //fprintf(file_regs, "writereg %08x %08x # %s\n", M200_FRAME_REG_REND_LIST_ADDR | addr_prefix, registers->frame_regs_addr_frame[core_nr-1], mali_dump_get_register_name(reg_nr++));
        fprintf(file_regs, "writereg %08x %08x # %s\n", M200_FRAME_REG_REND_LIST_ADDR | addr_prefix, registers->frame_regs_addr_frame[core_nr-1], "M200_FRAME_REG_REND_LIST_ADDR");
    }
    for(i = 1; i < 12; i++)
    {
        u32 value, reg_address, core_reg_addr;
        value = registers->frame_regs[i];
        reg_address = M200_FRAME_REG_REND_LIST_ADDR + (i * sizeof(mali_reg_value));
        core_reg_addr = reg_address | addr_prefix ;
        //fprintf(file_regs, "writereg %08x %08x # %s\n", core_reg_addr , value, mali_dump_get_register_name(reg_nr++));
        fprintf(file_regs, "writereg %08x %08x # %s\n", core_reg_addr , value, "mali_dump_get_register_name(reg_nr++)");
    }
    if (0 == core_nr)
    {
        //fprintf(file_regs, "writereg %08x %08x # %s\n", (M200_FRAME_REG_FS_STACK_ADDR * 4) | addr_prefix, registers->frame_regs[12], mali_dump_get_register_name(reg_nr++));
        fprintf(file_regs, "writereg %08x %08x # %s\n", (M200_FRAME_REG_FS_STACK_ADDR * 4) | addr_prefix, registers->frame_regs[12],"M200_FRAME_REG_FS_STACK_ADDR");
    }
    else
    {
        //fprintf(file_regs, "writereg %08x %08x # %s\n", (M200_FRAME_REG_FS_STACK_ADDR * 4) | addr_prefix, registers->frame_regs_addr_stack[core_nr-1], mali_dump_get_register_name(reg_nr++));
        fprintf(file_regs, "writereg %08x %08x # %s\n", (M200_FRAME_REG_FS_STACK_ADDR * 4) | addr_prefix, registers->frame_regs_addr_stack[core_nr-1],"M200_FRAME_REG_FS_STACK_ADDR");
    }
    for(i = 13; i < reg_array_length; i++)
    {
        u32 value, reg_address, core_reg_addr;
        value = registers->frame_regs[i];
        reg_address = M200_FRAME_REG_REND_LIST_ADDR + (i * sizeof(mali_reg_value));
        core_reg_addr = reg_address | addr_prefix ;
        //fprintf(file_regs, "writereg %08x %08x # %s\n", core_reg_addr , value, mali_dump_get_register_name(reg_nr++));
        fprintf(file_regs, "writereg %08x %08x # %s\n", core_reg_addr , value, "end M200_FRAME_REG_REND_LIST_ADDR");
    }


    /* WBx registers */
    reg_array_length = 12;

    for(i = 0; i < reg_array_length; i++)
    {
        u32 value, reg_address, core_reg_addr;
        value = registers->wb0_regs[i];
        reg_address = 0x100 + (i * sizeof(mali_reg_value));
        core_reg_addr = reg_address | addr_prefix ;
        //fprintf(file_regs, "writereg %08x %08x # %s\n", core_reg_addr, value, mali_dump_get_register_name(reg_nr++));
        fprintf(file_regs, "writereg %08x %08x # %s\n", core_reg_addr, value, "wb0_regs0");
    }
    for(i = 0; i < reg_array_length; i++)
    {
        u32 value, reg_address, core_reg_addr;
        value = registers->wb1_regs[i];
        reg_address = 0x200 + (i * sizeof(mali_reg_value));
        core_reg_addr = reg_address | addr_prefix ;
        //fprintf(file_regs, "writereg %08x %08x # %s\n", core_reg_addr, value, mali_dump_get_register_name(reg_nr++));
        fprintf(file_regs, "writereg %08x %08x # %s\n", core_reg_addr, value, "wb1_regs1");
    }
    for(i = 0; i < reg_array_length; i++)
    {
        u32 value, reg_address, core_reg_addr;
        value = registers->wb2_regs[i];
        reg_address = 0x300 + (i * sizeof(mali_reg_value));
        core_reg_addr = reg_address | addr_prefix ;
        //fprintf(file_regs, "writereg %08x %08x # %s\n", core_reg_addr, value, mali_dump_get_register_name(reg_nr++));
        fprintf(file_regs, "writereg %08x %08x # %s\n", core_reg_addr, value, "wb2_regs");
    }

    fprintf(file_regs, "writereg %08x %08x   # Set MGMT_IRQ_MASK_ALL\n",
                      MGMT_REG_IRQ_MASK |addr_prefix , MGMT_REG_CTRL_MGMT_IRQ_MASK_ALL);
    fprintf(file_regs, "writereg %08x %08x   # Set MGMT_CMD_START_RENDER\n",
                      MGMT_REG_CTRL_MGMT|addr_prefix  ,MGMT_REG_CTRL_MGMT_CMD_START_RENDER);
    fprintf(file_regs, "wait posedge irq\n");

    return;
}


/**
* Writes all registers in the job to the dump file, and load command to load the corresponding memory dump.
* This makes it possible to analyze or simulate what the mali core actually did in the job.
*/
void _mali_common_dump_pp_regs(FILE * file_regs, mali_pp_job * job, u32 subjob_nr)
{
    mali_pp_registers *registers;

    if (NULL==file_regs) return;

#if defined(USING_MALI450)
    if (0 == subjob_nr) mali_dump_450_frame_info(file_regs, &job->info);
#endif /* defined(USING_MALI450) */

    fprintf(file_regs, "load_mem DX910_PF02.hex\n");

    registers = &job->registers;

    mali_dump_pp_regs(file_regs, registers, subjob_nr);
    fprintf(file_regs, "dump_mem 00004060 00004260 > DLBxBASIC_00000_fb.hex\n");
    fprintf(file_regs, "dumpRgb565 16 16 00004060 > img16x16.bmp\n");
    fprintf(file_regs, "quit\n");

}

/**
 * Open the opened config.txt file.
 */
void _mali_base_common_dump_file_close(FILE * file)
{
    _mali_sys_fclose(file);
}


/** Doing memory dump before starting if enabled */
void _mali_base_common_dump_pre_start_dump(mali_dump_job_info * dump_info, void * dump_reg_info)
{
    //if ( MALI_TRUE !=  _mali_dump_system_is_enabled(ctx) || MALI_TRUE == dump_info->disable_dump)
    //{
    //    return;
    //}

    if ( (MALI_TRUE == dump_info->pre_run_dump_enable) && (MALI_FALSE==dump_info->pre_run_dump_done) )
    {
        const char * core_text;
        char *file_name_mem;
        int file_name_mem_size;
        mali_err_code err;
        //mali_file *file_regs=NULL;
        u32 subjobs;
        u32 subjob_nr;
        FILE *file_regs = fopen(&dump_info->last_mem_dump_file_name[0],"w+");
        err = MALI_ERR_NO_ERROR ;


        // /* Skip writing to register file if we only do memory profiling.*/
        // if( MALI_FALSE==_mali_dump_system_mem_print_one_liners(ctx))
        // {
        //     file_regs = _mali_base_common_dump_file_open(ctx);
        //     if ( NULL== file_regs)
        //     {
        //         MALI_DEBUG_ERROR(("Mali Dumping: Could not open the register write file.\n"));
        //     }
        // }

        file_name_mem      =      &(dump_info->last_mem_dump_file_name[0]);
        file_name_mem_size = sizeof(dump_info->last_mem_dump_file_name);

        if (MALI_FALSE == dump_info->is_pp_job)
        {
            core_text = "gp";
            subjobs = 1;
        }
        else
        {
            core_text = "pp";
            subjobs = MAX(1, ((mali_pp_job*)dump_reg_info)->num_cores);
        }

        for (subjob_nr = 0; subjob_nr < subjobs; subjob_nr++)
        {
            if ( NULL!=file_regs )
            {
                fprintf(file_regs, "#\n# Dumping Start %s Job nr: %d, subjob %d from Frame nr: %d\n",
                                              core_text, dump_info->job_nr, subjob_nr, dump_info->frame_nr);
                fprintf(file_regs, "reset\n");
            }

            //err = _mali_base_common_dump_mem_all(file_regs, file_name_mem, file_name_mem_size, core_text,
             //                   dump_info->job_nr, "start" , dump_info->frame_nr, dump_info->is_pp_job, subjob_nr);
            if ( NULL!=file_regs )
            {
                if ( MALI_ERR_NO_ERROR == err )
                {
                    if ( MALI_FALSE==dump_info->is_pp_job)
                    {
                        /* Writes all registers in the job to the dump file,
                        and load command to load the corresponding memory dump.*/
                    //    _mali_common_dump_gp_regs(ctx, file_regs, (u32*) dump_reg_info);
                    } else
                    {
                        /* Writes all registers in the job to the dump file,
                        and load command to load the corresponding memory dump.*/
                        _mali_common_dump_pp_regs(file_regs, (mali_pp_job *)dump_reg_info, subjob_nr);
                    }
                    dump_info->pre_run_dump_done = MALI_TRUE;
                }
            }
        }
        _mali_base_common_dump_file_close(file_regs);
    }
}

/** Filling the job->dump_info struct */
void _mali_common_dump_pp_pre_start(mali_pp_job *job)
{
    /* Filling the job->dump_info struct */
    _mali_base_common_dump_job_info_fill(MALI_DUMP_PP, &(job->dump_info) );
}

void _mali_base_common_pp_job_start(mali_pp_job* job, mali_job_priority priority, mali_fence_handle *fence)
{
    //mali_pp_job * job = MALI_REINTERPRET_CAST(mali_pp_job *)job_handle;
    //mali_err_code err;
    //mali_bool no_notification = MALI_FALSE;

    //MALI_DEBUG_ASSERT_POINTER(job);
    //if (NULL == job) return;

    job->priority = priority;

    #ifdef MALI_DUMP_ENABLE
        /* Filling the job->dump_info struct */
        _mali_common_dump_pp_pre_start(job);
    #endif

    /* try to start it right away */
    //MALI_DEBUG_ASSERT(
    //                        (MALI_PP_JOB_BUILDING == job->state || MALI_PP_JOB_CALLBACK == job->state || MALI_PP_JOB_SYNCING == job->state),
    //                        ("Invalid job state transition. Can't end up in %d from %d", MALI_PP_JOB_RUNNING, job->state)
    //                     );
    job->state = MALI_PP_JOB_RUNNING;

#ifdef MALI_DUMP_ENABLE
    _mali_base_common_dump_pre_start_dump(&(job->dump_info), (void*)job);
#endif

// #if !MALI_INSTRUMENTED
//     /* Always use notifications in instrumented mode, since we need to get counters values back! */
//     if (NULL == job->callback && NULL == job->wait_handle && NULL == job->sync)
//     {
//         no_notification = MALI_TRUE;
//     }
// #else
//     no_notification = MALI_FALSE;
// #endif
//     cout<<"no_notification="<<no_notification<<endl;

    //err = _mali_base_arch_pp_start(job, no_notification, fence);

    //switch (err)
    //{
    //    case MALI_ERR_NO_ERROR:
    //        if (MALI_TRUE == no_notification)
    //        {
    //            /* The caller don't want to wait for this job,
    //             * so just do the post processing (including job deletion) right now.
    //             * Pretend it was successful.
    //             */
    //            _mali_base_common_pp_job_run_postprocessing(job, MALI_JOB_STATUS_END_SUCCESS);
    //        }
    //        break;
    //    case MALI_ERR_FUNCTION_FAILED:
    //        /* FALL THROUGH */
    //    default:
    //        _mali_base_common_pp_job_run_postprocessing(job, MALI_JOB_STATUS_END_UNKNOWN_ERR);
    //        break;
    //}
}


/**
 * Queue a PP job for execution by the system.
 *
 * Puts the job onto the queue of jobs to be run.
 * The job's priority will decide where in the queue it will be put.
 *
 * If an empty fence has been attached to the PP job before calling this
 * function that empty fence will be backed by this PP job, and signalled when
 * the PP job is done.
 *
 * If there is no empty fence attached to the job and \a fence is not NULL, a
 * new fence, that will be signalled when the job is complete, will be created
 * and the fence handle will be stored in \a fence.
 *
 * @param job Pointer to the job to put on the execution queue.
 * @param priority Priority of the job
 * @param fence Pointer to mali_fence_handle, output fence if not NULL
 */
bool MaliPPJob::_mali_pp_job_start(mali_job_priority priority, mali_fence_handle *fence)
 {
 #if MALI_INSTRUMENTED
     _mali_base_common_instrumented_pp_job_start(job, priority, fence);
 #else
     _mali_base_common_pp_job_start(this->job, priority, fence);
 #endif /* #if MALI_INSTRUMENTED */
     return 0;
 }

MaliPPJob::~MaliPPJob(){
    free(pptf->framebuffer);
    free (pptf);
}
