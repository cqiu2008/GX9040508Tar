#include <gtest/gtest.h>
#include "Car.hpp"


TEST(TestCase1, Test1)
{
    Amount n1=100;
    Amount n2=200;
    Car car1 = Car("Das auto",n1,n2);
    Car car2 = Car("Benz ",n1,n2);
    for(int i=0;i<n1;i++){
        printf("car1.pt1[%4d]=%4x\n",i,car1.pt1[i]);
        printf("car2.pt1[%4d]=%4x\n",i,car2.pt1[i]);
    }
    EXPECT_EQ(true, 1==1);
}
