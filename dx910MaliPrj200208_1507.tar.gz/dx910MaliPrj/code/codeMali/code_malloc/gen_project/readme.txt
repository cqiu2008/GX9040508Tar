Step1:copy the code_template to the new code_xxx
    For example: cp -rf code_template code_just_test

Step2: please run "./genPrj"
    You will find that all the project folder has been changed.

Step3: You can see the readMe.docx to do something else.

