#ifndef CAR_HPP_ 
#define CAR_HPP_ 

#include <string>
#include <string.h>

typedef int Card;
//typedef unsigned int Amount;
//typedef int Amount;
typedef unsigned char Amount;

class Car{

public:
    Car(const std::string carNameIn,const Amount n1,const Amount n2);
    Amount* pt1;
    Amount* pt2;
    ~Car();
private:
    std::string carName;
};


#endif
