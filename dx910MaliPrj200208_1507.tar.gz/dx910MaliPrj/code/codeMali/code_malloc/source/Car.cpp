#include "Car.hpp"
using namespace std;

Car::Car(const std::string carNameIn,const Amount n1,const Amount n2):carName(carNameIn){
    pt1 = (Amount *)malloc(sizeof(Amount)* n1);
    memset(pt1,0x12,sizeof(Amount)*n1);
    pt2 = (Amount *)malloc(sizeof(Amount)* n2);
    memset(pt2,0xf3,sizeof(Amount)*n1);
}

Car::~Car(){
    free(pt1);
    free(pt2);
}
