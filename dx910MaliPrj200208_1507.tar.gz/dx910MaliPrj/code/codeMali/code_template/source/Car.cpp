#include "Car.hpp"

Car::Car(const std::string carNameIn):carName(carNameIn){}

