#include <gtest/gtest.h>
#include "Car.hpp"


TEST(TestCase1, Test1)
{
    Car car1 = Car("Das auto");
    Car car2 = Car("Benz ");
    EXPECT_EQ(true, 1==1);
}
