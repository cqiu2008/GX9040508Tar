#ifndef CAR_HPP_ 
#define CAR_HPP_ 

#include <string>

typedef int Card;
typedef unsigned int Amount;

class Car{

public:
    Car(const std::string carNameIn);

private:
    std::string carName;
};


#endif
