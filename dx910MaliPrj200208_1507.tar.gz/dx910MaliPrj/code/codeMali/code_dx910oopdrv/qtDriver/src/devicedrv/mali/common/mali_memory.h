/*
 * This confidential and proprietary software may be used only as
 * authorised by a licensing agreement from ARM Limited
 * (C) COPYRIGHT 2008-2013 ARM Limited
 * ALL RIGHTS RESERVED
 * The entire notice above must be reproduced on all authorised
 * copies and copies may only be made to the extent permitted
 * by a licensing agreement from ARM Limited.
 */

#ifndef __MALI_MEMORY_H__
#define __MALI_MEMORY_H__

#include "mali_osk.h"
#include "mali_session.h"

/** @brief Initialize Mali memory subsystem
 *
 * Allocate and initialize internal data structures. Must be called before
 * allocating Mali memory.
 *
 * @return On success _MALI_OSK_ERR_OK, othervise some error code describing the error.
 */
_mali_osk_errcode_t mali_memory_initialize(void);

/** @brief Terminate Mali memory system
 *
 * Clean up and release internal data structures.
 */
void mali_memory_terminate(void);

/** @brief Start new Mali memory session
 *
 * Allocate and prepare session specific memory allocation data data. The
 * session page directory, lock, and descriptor map is set up.
 *
 * @param mali_session_data pointer to the session data structure
 */
_mali_osk_errcode_t mali_memory_session_begin(struct mali_session_data *mali_session_data);

/** @brief Close a Mali memory session
 *
 * Release session specific memory allocation related data.
 *
 * @param mali_session_data pointer to the session data structure
 */
void mali_memory_session_end(struct mali_session_data *mali_session_data);

/** @brief Allocate a page table page
 *
 * Allocate a page for use as a page directory or page table. The page is
 * mapped into kernel space.
 *
 * @return _MALI_OSK_ERR_OK on success, othervise an error code
 * @param table_page GPU pointer to the allocated page
 * @param mapping CPU pointer to the mapping of the allocated page
 */
_mali_osk_errcode_t mali_mmu_get_table_page(u32 *table_page, mali_io_address *mapping);

/** @brief Release a page table page
 *
 * Release a page table page allocated through \a mali_mmu_get_table_page
 *
 * @param pa the GPU address of the page to release
 */
void mali_mmu_release_table_page(u32 pa);


/** @brief Parse resource and prepare the OS memory allocator
 *
 * @param size Maximum size to allocate for Mali GPU.
 * @return _MALI_OSK_ERR_OK on success, otherwise failure.
 */
_mali_osk_errcode_t mali_memory_core_resource_os_memory(u32 size);

/** @brief Parse resource and prepare the dedicated memory allocator
 *
 * @param start Physical start address of dedicated Mali GPU memory.
 * @param size Size of dedicated Mali GPU memory.
 * @return _MALI_OSK_ERR_OK on success, otherwise failure.
 */
_mali_osk_errcode_t mali_memory_core_resource_dedicated_memory(u32 start, u32 size);

mali_allocation_engine mali_mem_get_memory_engine(void);

#endif /* __MALI_MEMORY_H__ */
